import pandas as pd
import warnings
import json
import os
import io
from datetime import datetime
from dfs.modules.metadata.pdf_metadata_gen import MetadataAnalyzer
from dfs.modules.reconciliation.pdf_reconciliation_gen import Reconciliation
from dfs.modules.font.pdf_font_gen import FontAnalysis
from dfs.modules.language.pdf_language_gen import LanguageModel
from dfs.modules.annotation.pdf_annotations_gen import Annotation
from dfs.modules.overlay.pdf_overlay_gen import Overlay
from dfs.modules.logo.pdf_logo_gen import LogoModule
from dfs.modules.extraction.bank_name_extraction_gen import bankname
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import write_to_data_lake, read_from_data_lake
warnings.filterwarnings("ignore")


def excel_to_json(input_file_path, module_name, json_output_dir_name):
    os.makedirs(json_output_dir_name, exist_ok=True)
    json_output_file_name = f"{module_name}.json"
    json_output_file_name = os.path.join(json_output_dir_name, json_output_file_name)
    excel_data = pd.read_excel(input_file_path, sheet_name=module_name, skiprows=1)
    excel_data = excel_data.drop(columns=['Unnamed: 0'], errors='ignore')
    excel_data = excel_data.where(pd.notnull(excel_data), None)
    json_data = {}
    for column in excel_data.columns:
        json_data[column] = excel_data[column].to_dict()

    json_info_bytes = json.dumps(json_data).encode('utf-8')
    write_to_data_lake(json_info_bytes, json_output_file_name)

def error_json(error_info, error_json_file_path):
    error_info_bytes = json.dumps(error_info).encode('utf-8')
    write_to_data_lake(error_info_bytes, error_json_file_path)


def write_to_excel(df_list, fraud_report_file_path):

    excel_bytes_io = io.BytesIO()
    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
        for df in df_list:
            pd.DataFrame(df["df"]).to_excel(writer, sheet_name=df["sheet_name"])

    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, fraud_report_file_path)

def generate_report(excel_df_dict, fraud_report_file_path):
    df_meta = None
    df_metadata = None
    df_font = None
    font_report = None
    df_annot_a = None
    df_annot_b = None
    df_overlay_a = None
    df_overlay_b = None
    mydf1_lang = None
    mydf2_lang = None
    df_logo1 = None
    df_logo2 = None
    df_reconcile1 = None
    df_reconcile2 = None

    for excel_df_name in excel_df_dict.keys():
        
        excel_df = excel_df_dict[excel_df_name]

        if excel_df_name == constants.METADATA_ENTRY_MODULE:
            df_meta, df_metadata = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.FONT_ENTRY_MODULE:
            df_font, font_report = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.ANNOTATION_ENTRY_MODULE:
            df_annot_a, df_annot_b = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.OVERLAY_ENTRY_MODULE:
            df_overlay_a, df_overlay_b = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.LANGUAGE_ENTRY_MODULE:
            mydf1_lang, mydf2_lang = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.LOGO_ENTRY_MODULE:
            df_logo1, df_logo2 = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
        elif excel_df_name == constants.RECONCILIATION_ENTRY_MODULE:
            df_reconcile1, df_reconcile2 = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]

    create_overall_assessment(df_meta, df_metadata, df_font, font_report, df_annot_a, df_annot_b, df_overlay_a, df_overlay_b, mydf1_lang, mydf2_lang, df_logo1, df_logo2, df_reconcile1, df_reconcile2, fraud_report_file_path)

def create_overall_assessment(df_meta, df_metadata, df_font, font_report, df_annot_a, df_annot_b, df_overlay_a, df_overlay_b, mydf1_lang, mydf2_lang, df_logo1, df_logo2, df_reconcile1, df_reconcile2, fraud_report_file_path):
    df_overall = []
    if df_metadata is not None:
        dfm = df_metadata[df_metadata['Flag'] == 1][['Insight','Severity_Level']]
        dfm.insert(0, 'Module', 'Metadata')
        dfm.insert(0, 'Sheet_order', '1')
        dfm.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfm)
    
    
    if font_report is not None:
        dff = font_report[font_report['Font_Anomaly_Flag'] == 1][['Insight_Elaborated','Severity_Level']]
        dff.insert(0, 'Module', 'Font')
        dff.insert(0, 'Sheet_order', '2')
        dff.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dff)
    
    if df_annot_b is not None:
        dfa = df_annot_b[df_annot_b['Annotation_Flag'] == 1][['Insight','Severity_Level']]
        dfa.insert(0, 'Module', 'Annotation')
        dfa.insert(0, 'Sheet_order', '3')
        dfa.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfa)

    if df_overlay_b is not None:    
        dfo = df_overlay_b[df_overlay_b['Flag'] == 1][['Insight','Severity_Level']]
        dfo.insert(0, 'Module', 'Overlay')
        dfo.insert(0, 'Sheet_order', '4')
        dfo.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfo)
    
    if mydf1_lang is not None:
        dfLa = mydf1_lang[mydf1_lang['Flag'] == 1][['Insight','Severity_Level']]
        dfLa.insert(0, 'Module', 'Language')
        dfLa.insert(0, 'Sheet_order', '5')
        dfLa.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfLa)
    
    if df_logo2 is not None:
        try:
            dfl = df_logo2[df_logo2['Flag'] == 1][['Insight','Severity_Level']]
        except:
            dfl = pd.DataFrame(columns = ['Insight','Severity_Level'])
        dfl.insert(0, 'Module', 'Logo')
        dfl.insert(0, 'Sheet_order', '6')
        dfl.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfl)
    
    if df_reconcile2 is not None:
        dfr = df_reconcile2[df_reconcile2['Flag'] == 1][['Insight','Severity_Level']]
        dfr.insert(0, 'Module', 'Reconciliation')
        dfr.insert(0, 'Sheet_order', '7')
        dfr.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfr)
    
    if len(df_overall) == 1:
        df_overall = pd.concat(df_overall)
        df_overall.rename(columns={'Insight': 'Alerts', 'Severity_Level': 'Severity'}, inplace=True)
        df_overall = df_overall[['Module', 'Alerts', 'Severity']]
        df_overall.reset_index(drop=True, inplace=True)   
        
        severity_mapping = {'LOW': 1, 'MEDIUM': 2, 'HIGH': 3}
        df_overall['Severity_Num'] = df_overall['Severity'].map(severity_mapping)
        highest_severity_num = df_overall['Severity_Num'].max()
        highest_severity = [key for key, value in severity_mapping.items() if value == highest_severity_num][0]
        overall_assessment = pd.DataFrame({
            'Module': ['Overall'],
            'Alerts': ['Overall Assessment'],
            'Severity': [highest_severity]
        })
        df_overall = pd.concat([df_overall, overall_assessment], ignore_index=True)
        df_overall.drop(columns=['Severity_Num'], inplace=True)
    else:
        df_overall_1 = df_overall
        df_overall = pd.concat(df_overall,ignore_index=True)
        df_overall = df_overall.groupby(['Sheet_order','Module','Alerts','Severity']).size().reset_index(name='#Occurances')
        df_overall.drop('Sheet_order', axis=1, inplace=True)
        df_overall_copy = pd.concat(df_overall_1, ignore_index=True)
        df_overall_high_med_low_count = df_overall_copy.groupby(['Severity']).size().reset_index(name='#Occurances')

        try:
            high_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'HIGH']['#Occurances'].values[0]   
        except:
            high_count_value = 0

        try:
            low_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'LOW']['#Occurances'].values[0]
        except:
            low_count_value = 0

        try:
            medium_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'MEDIUM']['#Occurances'].values[0]
        except:
            medium_count_value = 0

        severity_score = high_count_value*150+medium_count_value*50+low_count_value*10

        if severity_score > 1000:

            overall_assessment_value = "HIGH"

        elif severity_score > 500 and severity_score < 1000:
            overall_assessment_value = "MEDIUM"
        else :
            overall_assessment_value = "LOW"

        df_overall.loc[len(df_overall.index)] = ['Overall', 'Overall Assessment', overall_assessment_value, df_overall['#Occurances'].sum()]

        #fixing Sr_no
    def serial_number(df):
        if df is not None:
            df.index.name = 'Sr_no'
            df.reset_index(drop=False, inplace=True)    
            df['Sr_no'] = df.index + 1
            df.set_index('Sr_no', inplace=True)

    dataframes = [{"df":df_meta, "sheet_name":'1A. Metadata_Raw_Output'}, 
                {"df":df_metadata, "sheet_name":'1B. Metadata_Report'},
                {"df":df_font, "sheet_name":'2A. Font_Raw_Output'},
                {"df":font_report, "sheet_name":'2B. Font_Report'},
                {"df": df_annot_a, "sheet_name":'3A.Annotation_Raw_Output'},
                {"df": df_annot_b, "sheet_name":'3B.Annotation_Report'},
                {"df": df_overlay_a, "sheet_name":'4A.Overlay_Raw_Output'},
                {"df": df_overlay_b, "sheet_name":'4B.Overlay_Report'},
                {"df": mydf2_lang, "sheet_name":'5A.Language_Raw_Output'},
                {"df": mydf1_lang, "sheet_name":'5B.Language_Report'},
                {"df": df_logo1, "sheet_name":'6A.Logo_Raw_Output'},
                {"df": df_logo2, "sheet_name":'6B.Logo_Report'},
                {"df": df_reconcile1, "sheet_name":'7A.Reconciliation_Raw_Output'},
                {"df": df_reconcile2, "sheet_name":'7B.Reconciliation_Report'},
                {"df":df_overall, "sheet_name":'Overall Assessment'},
                ]

    dataframes = [d for d in dataframes if d["df"] is not None]

    for df in dataframes:
        serial_number(df["df"])

    write_to_excel(dataframes, fraud_report_file_path)
    formatting_excel(fraud_report_file_path)

def run_single_module(module_name,  *args):

    module_functions = {
        constants.BANKNAME_MODULE_GEN: bankname,
        constants.METADATA_MAIN_MODULE_GEN: MetadataAnalyzer.metadata_main,
        constants.METADATA_RULES_MODULE_GEN: MetadataAnalyzer.metadata_rules,
        constants.LOGO_MAIN_MODULE_GEN: LogoModule.main_logo,
        constants.LOGO_REPORT_MODULE_GEN: LogoModule.return_final_report,
        constants.LOGO_HIGHLIGHT_MODULE_GEN: LogoModule.save_highlighted_pdf,
        constants.FONT_MAIN_MODULE_GEN: FontAnalysis.font_analysis,
        constants.FONT_REPORT_MODULE_GEN: FontAnalysis.calculate_final_report_insight,
        constants.FONT_HIGHLIGHT_MODULE_GEN: FontAnalysis.highlight_pdf,
        constants.ANNOTATION_MAIN_MODULE_GEN: Annotation.annotation_main,
        constants.ANNOTATION_REPORT_MODULE_GEN: Annotation.return_final_report,
        constants.ANNOTATION_HIGHLIGHT_MODULE_GEN: Annotation.draw_pdf,
        constants.OVERLAY_MAIN_MODULE_GEN: Overlay.OverlapMain,
        constants.OVERLAY_REPORT_MODULE_GEN: Overlay.return_final_report,
        constants.OVERLAY_HIGHLIGHT_MODULE_GEN: Overlay.draw_pdf,
        constants.LANGUAGE_MAIN_MODULE_GEN: LanguageModel.spelling_module,
        constants.LANGUAGE_HIGHLIGHT_MODULE_GEN: LanguageModel.highlight,
        constants.RECONCILIATION_MAIN_MODULE_GEN: Reconciliation.reconcile_demo_2,
        constants.RECONCILIATION_REPORT_MODULE_GEN: Reconciliation.create_excel,
        constants.RECONCILIATION_HIGHLIGHT_MODULE_GEN: Reconciliation.Highlighting_doc,
        constants.CREATE_EXCEL_FILE: write_to_excel,
        constants.EXCEL_TO_JSON_PDF_GEN: excel_to_json,
        constants.CREATE_OVERALL_ASSESSMENT_PDF_GEN: create_overall_assessment,
        constants.GENERATE_REPORT: generate_report,
        constants.CREATE_ERROR_REPORT: error_json

    }

    if module_name in module_functions:
        return module_functions[module_name](*args)
    else:
        return ModuleNotFoundError(
            f"Function 'your_function_name' not found in module '{module_name}'")

def formatting_excel(excel_file_Path):
    xls = pd.ExcelFile(excel_file_Path)
    sheet_names = xls.sheet_names
    current_date = datetime.today()
    # Format the date
    formatted_date = current_date.strftime("%d-%b-%Y")
    i = 1
    excel_bytes_io = io.BytesIO()

    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as excel_writer:

        for sheet in sheet_names:
            df = pd.read_excel(excel_file_Path, sheet_name=sheet)
            df.to_excel(excel_writer, sheet_name='Sheet'+str(i), index=False, startrow=1, startcol=1)
            excel_writer.sheets['Sheet'+str(i)].name = sheet  # Rename to 'MySheet'

            workbook  = excel_writer.book
            worksheet1 = excel_writer.sheets['Sheet'+str(i)]
            worksheet1.hide_gridlines(2)

            bold_format = workbook.add_format({'bold': True})
            header_format1 = workbook.add_format({'border': 1, 'bg_color': '#FB4E0B', 'font_color': 'white'})

            for col_num, value in enumerate(df.columns.values):
                worksheet1.write(1, col_num+1, value, header_format1)
                max_len = max(df[value].astype(str).map(len).max(), len(value))
                if pd.isna(max_len):
                    max_len = len(value)
                worksheet1.set_column(0, 0, 2)
                if sheet == 'Overall Assessment':
                    worksheet1.write(0, 1, f"Date of Processing - {formatted_date}",bold_format)
                    worksheet1.set_column(1, 2, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, width = max_len + 2)
                    worksheet1.set_column(2,2, width = 14, cell_format=bold_format)
                else:
                    worksheet1.set_column(1, 1, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, max_len + 2)  # Add some padding

            # Define cell format for thick border
            light_border_format = workbook.add_format({'border': 1})  # 1 denotes thin border

            # Apply thick border to enclose the entire table
            num_rows, num_cols = df.shape
            border_range = f'B2:{chr(64 + num_cols+1)}{num_rows + 2}'  # Include header row
            try:
                worksheet1.conditional_format(border_range, {'type': 'blanks', 'format': light_border_format})
                worksheet1.conditional_format(border_range, {'type': 'no_blanks', 'format': light_border_format})
            except:
                pass

            i = i + 1

    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, excel_file_Path)

def generate_report(df_dict, final_report_insight, fraud_report_file_path, alerts_json_file_path, json_output_dir):
    final_insight = final_report_insight.to_dict(orient='records')
    json_data = json.dumps(final_insight)
    write_to_data_lake(json_data.encode('utf-8'), alerts_json_file_path)
    
    excel_bytes_io = io.BytesIO()
    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
        for k in df_dict.keys():
            df = df_dict[k]
            tab_name = df['tab_name'].iloc[0]
            excel_to_json(df['tabs_df'], tab_name, json_output_dir)
            for i in range(len(df)):
                df['tabs_df'].loc[i].to_excel(writer, sheet_name=df['tab_name'].loc[i], index=False)
    
    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, fraud_report_file_path)
        

def run_all_modules(input_file_path, fraud_report_file_path, reconciliation_output_pdf_path,
                    font_output_pdf_path, language_module_output_pdf_path, annotations_output_pdf_path, image_annotations_dir,
                    element_overlap_output_pdf_path, image_overlap_dir, logo_output_pdf_path,
                    image_logo_dir, alerts_json_file_path, error_json_file_path, json_output_dir, reconcile_image_dir, image_language_dir):

    os.makedirs(os.path.dirname(fraud_report_file_path), exist_ok=True)
    os.makedirs(json_output_dir, exist_ok=True)
    os.makedirs(image_logo_dir, exist_ok=True)
    os.makedirs(image_overlap_dir, exist_ok=True)
    os.makedirs(image_language_dir, exist_ok=True)
    os.makedirs(os.path.dirname(logo_output_pdf_path), exist_ok=True)
    prompt = 'What bank is this?'

    final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
    input_next_module = input_file_path

    bank_name = bankname(input_next_module, prompt)

    metadata, bank_name, df_meta = MetadataAnalyzer.metadata_main(
        input_next_module, bank_name)
    
    df_logo1, df_logo2, pdf_highlighting_coordinates_logo = LogoModule.main_logo(
        input_next_module, bank_name, image_logo_dir)
    
    df_font, df2_font_seg = FontAnalysis.font_analysis(input_next_module, bank_name)
    pdf_highlighting_coordinates_annot, df_annot = Annotation.annotation_main(
        input_next_module, image_annotations_dir)
    a1_overlay, pdf_highlighting_coordinates_overlay = Overlay.OverlapMain(
        input_next_module, image_overlap_dir, bank_name)
    
    try:
        reconcile_output_list = Reconciliation.reconcile_demo_2(
            input_next_module, reconcile_image_dir)
    except:
        pass
    final_report_insight_7, bbox_lang, page_num_lang, mydf1_lang, mydf2_lang, language_error_list = LanguageModel.spelling_module(
        input_next_module, image_language_dir)

    # BLOCK 2
    LogoModule.save_highlighted_pdf(
        input_next_module, logo_output_pdf_path, pdf_highlighting_coordinates_logo)

    FontAnalysis.highlight_pdf(logo_output_pdf_path, df_font, font_output_pdf_path)

    Annotation.draw_pdf(
        font_output_pdf_path, pdf_highlighting_coordinates_annot, annotations_output_pdf_path)

    Overlay.draw_pdf(annotations_output_pdf_path, pdf_highlighting_coordinates_overlay,
                     element_overlap_output_pdf_path)
    try:
        Reconciliation.Highlighting_doc(
            element_overlap_output_pdf_path, *reconcile_output_list, reconciliation_output_pdf_path)
    except:
        reconciliation_output_pdf_path = element_overlap_output_pdf_path
        pass
        
    LanguageModel.highlight(reconciliation_output_pdf_path, bbox_lang,
                            page_num_lang, 2, language_module_output_pdf_path)

    
    # BLOCK 3

    df_metadata, final_report_insight_1, meta_error_list = MetadataAnalyzer.metadata_rules(
        metadata, final_report_insight)
    
    final_report_insight_2, logo_error_list = LogoModule.return_final_report(
        df_logo2, final_report_insight)
    
    df_font, font_report, final_report_insight_3, font_error_list = FontAnalysis.calculate_final_report_insight(
        df2_font_seg, final_report_insight, bank_name)
    
    df_annot_a, df_annot_b, final_report_insight_4, annotation_error_list = Annotation.return_final_report(
        df_annot, final_report_insight)

    df_overlay_a, df_overlay_b, final_report_insight_5, overlay_error_list = Overlay.return_final_report(
            a1_overlay, final_report_insight)

    try:
        final_report_insight_6, df_reconcile1, df_reconcile2, reconciliation_error_list = Reconciliation.create_excel(
            *reconcile_output_list)
    except:
        final_report_insight_6 = pd.DataFrame(columns = ['Module', 'Alerts', 'Severity'])
        df_reconcile1 = pd.DataFrame(columns = ['Reconciliation', 'Value'])
        df_reconcile2 = pd.DataFrame(columns = ['Rule', 'Flag', 'Severity_Level', 'Insight'])
        reconciliation_error_list = []

    # final_report_insight = pd.concat([final_report_insight_1, final_report_insight_2, final_report_insight_3,
    #                                   final_report_insight_4, final_report_insight_5, final_report_insight_6, final_report_insight_7])


    error_info = {}
    error_info[constants.METADATA_ENTRY_MODULE] = meta_error_list
    error_info[constants.LOGO_ENTRY_MODULE] = logo_error_list
    error_info[constants.FONT_ENTRY_MODULE] = font_error_list
    error_info[constants.ANNOTATION_ENTRY_MODULE] = annotation_error_list
    error_info[constants.OVERLAY_ENTRY_MODULE] = overlay_error_list
    error_info[constants.LANGUAGE_ENTRY_MODULE] = language_error_list
    error_info[constants.RECONCILIATION_ENTRY_MODULE] = reconciliation_error_list

    error_json(error_info, error_json_file_path)
    create_overall_assessment(df_meta, df_metadata, df_font, font_report, df_annot_a, df_annot_b, df_overlay_a, df_overlay_b, mydf1_lang, mydf2_lang, df_logo1, df_logo2, df_reconcile1, df_reconcile2, fraud_report_file_path)
    excel_to_json(fraud_report_file_path, 'Overall Assessment', json_output_dir)


def main(input_file_path, output_base_dir, strategy="sequential"):
    image_output_dir = 'images'
    pdf_outputs = 'pdf_files'
    df_output_dir = 'excel_files'
    fraud_report_file_path = os.path.join(
        output_base_dir, df_output_dir, "fraud_report_file_path.xlsx")
    reconciliation_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "reconciliation_output.pdf")
    font_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "font_output.pdf")
    language_module_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "language_output.pdf")
    annotations_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "annotations_output.pdf")
    image_annotations_dir = os.path.join(
        output_base_dir, image_output_dir, "annotations")
    element_overlap_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "element_overlap_output.pdf")
    element_overlap_output_csv_path = os.path.join(
        output_base_dir, df_output_dir, "element_overlap_output.csv")
    image_overlap_dir = os.path.join(
        output_base_dir, image_output_dir, "overlap")
    logo_output_pdf_path = os.path.join(
        output_base_dir, pdf_outputs, "logo_output.pdf")
    image_logo_dir = os.path.join(output_base_dir, image_output_dir, "logo")
    image_language_dir = os.path.join(
        output_base_dir, image_output_dir, "language")
    reconcile_image_dir = os.path.join(
        output_base_dir, image_output_dir, "reconciliation")

    json_output_dir = os.path.join(output_base_dir, "json_outputs")
    alerts_json_file_path = os.path.join(
        json_output_dir, "fraud_report_file_path.json")
    error_json_file_path = os.path.join(json_output_dir, "errors.json")

    run_all_modules(input_file_path, fraud_report_file_path, reconciliation_output_pdf_path,
                    font_output_pdf_path, language_module_output_pdf_path, annotations_output_pdf_path, image_annotations_dir,
                    element_overlap_output_pdf_path, image_overlap_dir, logo_output_pdf_path,
                    image_logo_dir, alerts_json_file_path, error_json_file_path, json_output_dir, reconcile_image_dir, image_language_dir)
