import pandas as pd
import warnings
import json
import os
import io
import fitz
import tempfile
import time
from pdf2image import convert_from_bytes, convert_from_path
import numpy as np
from datetime import datetime
from PIL import Image
from dfs.modules.metadata.pdf_metadata_non_gen import MetadataAnalyzer
from dfs.modules.reconciliation.pdf_reconciliation_non_gen import Reconciliation 
from dfs.modules.font.pdf_font_non_gen import FontAnalysis
from dfs.modules.font.image_font_multi_processing import FontAnalysis as FontAnalysisImg
from dfs.modules.language.pdf_language_non_gen import LanguageModel 
from dfs.modules.annotation.pdf_annotations_non_gen import Annotation
from dfs.modules.overlay.pdf_overlay_non_gen import Overlay
from dfs.modules.overlay.image_overlay_multi_processing import Overlay as OverlayImg
from dfs.modules.logo.pdf_logo_non_gen import LogoModule
from dfs.modules.highlight.pdf_highlight import HighlightModule
from dfs.modules.highlight.image_highlight import HighlightModule as HighlightModuleImg
from dfs.core.image_non_gen import create_overall_assessment as create_overall_assessment_img
from dfs.modules.extraction.bank_name_extraction_non_gen import bankname
from dfs.commons import constants
from dfs.commons.ioutils.parallelize import Parallelize
from dfs.commons.ioutils.datastore_utils import write_to_data_lake, read_from_data_lake

from datastore.s3.client import S3Client
from datastore.base_classes.base_data_store import BaseDataStore
import logging

logger = logging.getLogger(__name__)

warnings.filterwarnings("ignore")

# def is_pdf_digital(pdf_file_path):
#     is_pdf_digital = False
#     Font_style = []
#     df_final = pd.DataFrame(columns = ['file_type'])
#     doc = read_from_data_lake(pdf_file_path)
#     first_page = doc[0]
#     text = first_page.get_text()
#     font_style = []

#     for page in doc:
#         blocks = page.get_text("dict")["blocks"]
#         for block in blocks:
#             try:
#                 for line in block["lines"]:
#                     for elements in line['spans']:
#                         font_style.append(elements['font'])
#             except: 
#                 pass
#     Font_style.append(list(set(font_style)))
#     font_style_list = list(set(font_style))
    
#     word_count = len(text.split())

#     if word_count <=50 or 'Unnamed-T3' in font_style_list: 
#         is_pdf_digital = False
#         file = "Scanned PDF"
#     elif word_count > 50:
#         is_pdf_digital = True
#         file = "Digital PDF" 

#     return is_pdf_digital

def is_pdf_digital(pdf_path):
    is_pdf_digital = False
    pdf_document = read_from_data_lake(pdf_path)
    has_text = False
    has_images = False
    
    first_page = pdf_document.load_page(0)
    page_rect = first_page.rect
    word_count = 0
        
    text = first_page.get_text("text")
    if text.strip() and len(text) > 50:
        has_text = True
        word_count = len(text.split())
        
    image_list = first_page.get_images(full = True)
    if image_list:
        has_images = True
        
        xref = image_list[0][0]
        image_info = pdf_document.extract_image(xref)
        image_width = image_info['width']
        image_height = image_info['height']
        image_size = (image_width, image_height)
        
        if (image_width/page_rect.width) > 0.8 and (image_height/page_rect.height) > 0.8 :
            if len(pdf_document) > 1 :
                second_page = pdf_document.load_page(1)
                second_page_text = second_page.get_text("text")
                if len(second_page_text.split()) > 60 :
                    is_pdf_digital = True
                    # return "Digital PDF"
            is_pdf_digital = False
            # return "Scanned PDF"
        
            
    pdf_document.close()
    
    if has_text and not has_images :
        is_pdf_digital = True
        file = "Digital PDF"
    elif has_images and not has_text:
        is_pdf_digital = False
        file = "Scanned PDF"
    elif has_text and has_images:
        is_pdf_digital = True
        file = "Digital PDF"
    else:
        is_pdf_digital = True
        file = "Digital PDF"
        
    return is_pdf_digital    
    

# def find_overall_index(module_data):
#     for index, value in module_data.items():
#         if value == "Overall":
#             return index
#     return None

def excel_to_json(input_file_path, module_name, json_output_dir_name, pdf_filename_file):
    os.makedirs(json_output_dir_name, exist_ok=True)
    filename = os.path.basename(input_file_path)
    filename = filename.replace('_fraud_report_file_path.xlsx', '.pdf')
    base_name = os.path.splitext(filename)[0]
    json_output_file_name = f"{base_name}_{module_name}.json"
    json_output_file_name = os.path.join(json_output_dir_name, json_output_file_name)
    excel_data = read_from_data_lake(input_file_path, sheet_name=module_name, skiprows=1)
    excel_data = excel_data.drop(columns=['Unnamed: 0'], errors='ignore')
    excel_data = excel_data.where(pd.notnull(excel_data), None)
      
    json_data = {}
        # 'Sr No.' : 1,
        # "FileName" : filename,
        # "Severity level" : None,
        # "Results" : {}
    
    for column in excel_data.columns[:5]:
        col_data = excel_data[column].to_dict()
        
        # if 'Module' in json_data:
        #     #overall_index = find_overall_index(json_data['Module'])
        #     # if overall_index is not None and "Severity" in json_data:
        #     severity_data = json_data["Severity"]
                #value = severity_data.get(overall_index, None)
                # json_data['Severity level'] = value
        new_key = next(value for value in col_data.values() if value is not None)
        filtered_data = {k: v for k,v in col_data.items() if v != new_key}

        json_data[new_key] = filtered_data
        
    # del json_data['#Occurrences']  
    with open(json_output_file_name, "w+", encoding="utf-8") as writeJsonfile:
        json.dump(json_data, writeJsonfile, indent=4,default=str)


def error_json(error_info, error_json_file_path):
    error_info_bytes = json.dumps(error_info).encode('utf-8')
    write_to_data_lake(error_info_bytes, error_json_file_path)


def write_to_excel(df_list, fraud_report_file_path):

    excel_bytes_io = io.BytesIO()
    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
        for df in df_list:
            pd.DataFrame(df["df"]).to_excel(writer, sheet_name=df["sheet_name"])

    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, fraud_report_file_path)

# def generate_report(excel_df_dict, fraud_report_file_path):
#     df_meta = None
#     df_metadata = None
#     df_font = None
#     font_report = None
#     df_annot_a = None
#     df_annot_b = None
#     df_overlay_a = None
#     df_overlay_b = None
#     mydf1_lang = None
#     mydf2_lang = None
#     df_logo1 = None
#     df_logo2 = None
#     df_reconcile1 = None
#     df_reconcile2 = None

#     for excel_df_name in excel_df_dict.keys():
        
#         excel_df = excel_df_dict[excel_df_name]

#         if excel_df_name == constants.METADATA_ENTRY_MODULE:
#             df_meta, df_metadata = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.FONT_ENTRY_MODULE:
#             df_font, font_report = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.ANNOTATION_ENTRY_MODULE:
#             df_annot_a, df_annot_b = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.OVERLAY_ENTRY_MODULE:
#             df_overlay_a, df_overlay_b = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.LANGUAGE_ENTRY_MODULE:
#             mydf1_lang, mydf2_lang = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.LOGO_ENTRY_MODULE:
#             df_logo1, df_logo2 = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]
        
#         elif excel_df_name == constants.RECONCILIATION_ENTRY_MODULE:
#             df_reconcile1, df_reconcile2 = excel_df['tabs_df'].loc[0], excel_df['tabs_df'].loc[1]

#     create_overall_assessment(df_meta, df_metadata, df_font, font_report, df_annot_a, df_annot_b, df_overlay_a, df_overlay_b, mydf1_lang, mydf2_lang, df_logo1, df_logo2, df_reconcile1, df_reconcile2, fraud_report_file_path)

def create_overall_assessment(df_meta, df_metadata, df_font, font_report, df_annot_a, df_annot_b, df_overlay_a, df_overlay_b, mydf1_lang, mydf2_lang, df_logo1, df_logo2, df_reconcile1, df_reconcile2, df_img_overlay, report_overlay_img, font_df_img, font_report_img, fraud_report_file_path, is_digital_pdf, run_data_df):
    df_overall = []
    if df_metadata is not None:
        run_data_df['File_Was_Modified'] = df_metadata[df_metadata['Rule'] == 'Creation_dt_different_from_modification_dt']['Insight']
        dfm = df_metadata[df_metadata['Flag'] == 1][['Insight','Severity_Level']]
        dfm.insert(0, 'Module', 'Metadata')
        dfm.insert(0, 'Sheet_order', '1')
        dfm.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfm)
    
    if font_report is not None:
        dff = font_report[font_report['Font_Anomaly_Flag'] == 1][['Insight_Elaborated','Severity_Level']]
        dff.insert(0, 'Module', 'Font')
        dff.insert(0, 'Sheet_order', '2')
        dff.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dff)
    
    if df_annot_b is not None:
        dfa = df_annot_b[df_annot_b['Annotation_Flag'] == 1][['Insight','Severity_Level']]
        dfa.insert(0, 'Module', 'Annotation')
        dfa.insert(0, 'Sheet_order', '3')
        dfa.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfa)

    if df_overlay_b is not None:    
        dfo = df_overlay_b[df_overlay_b['Flag'] == 1][['Insight','Severity_Level']]
        dfo.insert(0, 'Module', 'Overlay')
        dfo.insert(0, 'Sheet_order', '4')
        dfo.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfo)
    
    # if df_img_overlay is not None:    
    #     dfo = df_img_overlay[df_img_overlay['Flag'] == 1][['Insight','Severity_Level']]
    #     dfo.insert(0, 'Module', 'Overlay')
    #     dfo.insert(0, 'Sheet_order', '4')
    #     dfo.columns = ['Sheet_order','Module','Alerts','Severity']
    #     df_overall.append(dfo)
    
    if mydf1_lang is not None:
        dfLa = mydf1_lang[mydf1_lang['Flag'] == 1][['Insight','Severity_Level']]
        dfLa.insert(0, 'Module', 'Language')
        dfLa.insert(0, 'Sheet_order', '5')
        dfLa.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfLa)
    
    if df_logo2 is not None:
        dfl = df_logo2[df_logo2['Flag'] == 1][['Insight','Severity_Level']]
        dfl.insert(0, 'Module', 'Logo')
        dfl.insert(0, 'Sheet_order', '6')
        dfl.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfl)
    
    if df_reconcile2 is not None:
        dfr = df_reconcile2[df_reconcile2['Flag'] == 1][['Insight','Severity_Level']]
        dfr.insert(0, 'Module', 'Reconciliation')
        dfr.insert(0, 'Sheet_order', '7')
        dfr.columns = ['Sheet_order','Module','Alerts','Severity']
        df_overall.append(dfr)
    
    if len(df_overall) == 1:
        # print('single module--------------------------------------')
        df_overall = pd.concat(df_overall)
        df_overall.rename(columns={'Insight': 'Alerts', 'Severity_Level': 'Severity'}, inplace=True)
        df_overall = df_overall[['Module', 'Alerts', 'Severity']]
        df_overall.reset_index(drop=True, inplace=True)   
        
        severity_mapping = {'LOW': 1, 'MEDIUM': 2, 'HIGH': 3}
        df_overall['Severity_Num'] = df_overall['Severity'].map(severity_mapping)
        highest_severity_num = df_overall['Severity_Num'].max()
        highest_severity = [key for key, value in severity_mapping.items() if value == highest_severity_num][0]
        overall_assessment = pd.DataFrame({
            'Module': ['Overall'],
            'Alerts': ['Overall Assessment'],
            'Severity': [highest_severity]
        })
        df_overall = pd.concat([df_overall, overall_assessment], ignore_index=True)
        df_overall.drop(columns=['Severity_Num'], inplace=True)
    
    else:
        # print('multi module--------------------')
        df_overall_1 = df_overall
        df_overall = pd.concat(df_overall,ignore_index=True)
        df_overall = df_overall.groupby(['Sheet_order','Module','Alerts','Severity']).size().reset_index(name='#Occurrences')
        run_data_df['Metadata_Occurrences'] = df_overall[df_overall['Module'] == 'Metadata']['#Occurrences'].sum()
        run_data_df['Font_Occurrences'] = df_overall[df_overall['Module'] == 'Font']['#Occurrences'].sum()
        run_data_df['Annotation_Occurrences'] = df_overall[df_overall['Module'] == 'Annotation']['#Occurrences'].sum()
        run_data_df['Overlay_Occurrences'] = df_overall[df_overall['Module'] == 'Overlay']['#Occurrences'].sum()
        run_data_df['Language_Occurrences'] = df_overall[df_overall['Module'] == 'Language']['#Occurrences'].sum()
        run_data_df['Logo_Occurrences'] = df_overall[df_overall['Module'] == 'Logo']['#Occurrences'].sum()
        run_data_df['Reconciliation_Occurrences'] = df_overall[df_overall['Module'] == 'Reconciliation']['#Occurrences'].sum()
        
        df_overall.drop('Sheet_order', axis=1, inplace=True)
        df_overall_copy = pd.concat(df_overall_1, ignore_index=True)
        df_overall_high_med_low_count = df_overall_copy.groupby(['Severity']).size().reset_index(name='#Occurrences')

        try:
            high_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'HIGH']['#Occurrences'].values[0]   
        except:
            high_count_value = 0

        try:
            low_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'LOW']['#Occurrences'].values[0]
        except:
            low_count_value = 0

        try:
            medium_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'MEDIUM']['#Occurrences'].values[0]
        except:
            medium_count_value = 0

        severity_score = high_count_value*150+medium_count_value*50+low_count_value*10
        run_data_df['High_Alerts'] = high_count_value
        run_data_df['Medium_Alerts'] = medium_count_value
        run_data_df['Low_Alerts'] = low_count_value
        run_data_df['Severity_Score'] = severity_score
        
        try:
            module_count_value = f"{[df_overall_copy.groupby(['Module']).size().reset_index(name='#Occurances')]}"
        except:
            module_count_value = 0
        run_data_df['Module_Wise_Count'] = module_count_value
        
        try:
            final_report_insight_value =  f"{[df_overall[['Module','Alerts']]]}"
        except:
            final_report_insight_value = 0
        run_data_df['Summary'] = final_report_insight_value

        if severity_score >= 1000:
            overall_assessment_value = "HIGH"
        elif severity_score >= 500 and severity_score < 1000:
            overall_assessment_value = "MEDIUM"
        elif severity_score > 0 and severity_score < 500:
            overall_assessment_value = "LOW"
        else :
            overall_assessment_value = ""
        
        # severity_score = (high_count_value * 150 + medium_count_value * 50 + low_count_value * 10)
        if overall_assessment_value == "":          
#             new_row = pd.DataFrame(columns=df_overall.columns, index=[0])
#             df_overall = pd.concat([df_overall, new_row], ignore_index=True)
#             # df_overall.loc[len(df_overall.index)] = []
#             run_data_df['Overall_Severity'] = overall_assessment_value
#             overall_occurrences = df_overall[df_overall['Module'] == 'Overall']['#Occurrences']
#             run_data_df['Overall_Occurrences'] = int(overall_occurrences.sum())
            
#             df_overall = df_overall.iloc[:-1]
            
            run_data_df['Overall_Occurrences'] = int(df_overall[df_overall['Module'] == 'Overall']['#Occurrences'])            
            df_overall.loc[len(df_overall.index)] = []
            run_data_df['Overall_Severity'] = overall_assessment_value
            run_data_df['Overall_Occurrences'] = int(df_overall[df_overall['Module'] == 'Overall']['#Occurrences'])
            
            
            severity_values = {'HIGH': 150, 'MEDIUM': 50, 'LOW': 10}
            df_overall['Severity Value'] = df_overall['Severity'].map(severity_values)
            df_overall['Severity Score'] = df_overall['Severity Value'] * df_overall['#Occurrences']
            display(df_overall)
            
            total_severity_score = df_overall[df_overall['Module'] != 'Overall']['Severity Score'].sum()
            df_overall.loc[df_overall['Module'] == 'Overall', 'Severity Score'] = total_severity_score
            del df_overall['Severity Value']
        else :
            df_overall.loc[len(df_overall.index)] = ['Overall', 'Overall Assessment', overall_assessment_value, df_overall['#Occurrences'].sum()]
            run_data_df['Overall_Severity'] = overall_assessment_value
            run_data_df['Overall_Occurrences'] = int(df_overall[df_overall['Module'] == 'Overall']['#Occurrences'])
            severity_values = {'HIGH': 150, 'MEDIUM': 50, 'LOW': 10}
            df_overall['Severity Value'] = df_overall['Severity'].map(severity_values)
            df_overall['Severity Score'] = df_overall['Severity Value'] * df_overall['#Occurrences']
            
            total_severity_score = df_overall[df_overall['Module'] != 'Overall']['Severity Score'].sum()
            df_overall.loc[df_overall['Module'] == 'Overall', 'Severity Score'] = total_severity_score
            del df_overall['Severity Value']
            
        #fixing Sr_no
    def serial_number(df):
        if df is not None:
            df.index.name = 'Sr_no'
            df.reset_index(drop=False, inplace=True)    
            df['Sr_no'] = df.index + 1
            df.set_index('Sr_no', inplace=True)

    dataframes = [{"df":df_overall, "sheet_name":'Overall Assessment'},
                {"df":df_meta, "sheet_name":'1A. Metadata_Raw_Output'}, 
                {"df":df_metadata, "sheet_name":'1B. Metadata_Report'},
                {"df":df_font, "sheet_name":'2A. Font_Raw_Output'},
                {"df":font_report, "sheet_name":'2B. Font_Report'},
                {"df": df_annot_a, "sheet_name":'3A.Annotation_Raw_Output'},
                {"df": df_annot_b, "sheet_name":'3B.Annotation_Report'},
                {"df": df_overlay_a, "sheet_name":'4A.Overlay_Raw_Output'},
                {"df": df_overlay_b, "sheet_name":'4B.Overlay_Report'},
                {"df": mydf2_lang, "sheet_name":'5A.Language_Raw_Output'},
                {"df": mydf1_lang, "sheet_name":'5B.Language_Report'},
                {"df": df_logo1, "sheet_name":'6A.Logo_Raw_Output'},
                {"df": df_logo2, "sheet_name":'6B.Logo_Report'},
                {"df": df_reconcile1, "sheet_name":'7A.Reconciliation_Raw_Output'},
                {"df": df_reconcile2, "sheet_name":'7B.Reconciliation_Report'}

                ]

    dataframes = [d for d in dataframes if d["df"] is not None]
    dataframes1 = []
    if not is_digital_pdf:
        dataframes1 = create_overall_assessment_img(None, None, font_report_img, font_df_img, report_overlay_img, df_img_overlay, fraud_report_file_path=None)
        if dataframes:
            last_df = dataframes[0]["df"]
            filtered_last_df = last_df[last_df['Module'] != 'Overall']
            # display(filtered_last_df)
            dataframes[0]["df"] = filtered_last_df
        if dataframes1:
            last_df1 = dataframes1[0]["df"]
            filtered_last_df1 = last_df1[last_df1['Module'] != 'Overall']
            # display(filtered_last_df1)
            dataframes1[0]["df"] = filtered_last_df1

        overall_dfs = [d["df"] for d in dataframes + dataframes1 if d["sheet_name"] == 'Overall Assessment']
        merged_overall_df = pd.concat(overall_dfs) if overall_dfs else None
        
        # print('---------------------------------------1')
        # display(merged_overall_df)
        
        run_data_df['Metadata_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Metadata']['#Occurrences'].sum()
        run_data_df['Font_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Font']['#Occurrences'].sum()
        run_data_df['Annotation_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Annotation']['#Occurrences'].sum()
        run_data_df['Overlay_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Overlay']['#Occurrences'].sum()
        run_data_df['Language_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Language']['#Occurrences'].sum()
        run_data_df['Logo_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Logo']['#Occurrences'].sum()
        run_data_df['Reconciliation_Occurrences'] = merged_overall_df[merged_overall_df['Module'] == 'Reconciliation']['#Occurrences'].sum()
        
        try:
            high_count_value = merged_overall_df[merged_overall_df["Severity"] == "HIGH"]["#Occurrences"].sum()
        except:
            high_count_value = 0

        try:
            low_count_value = merged_overall_df[merged_overall_df["Severity"] == "LOW"]["#Occurrences"].sum()
        except:
            low_count_value = 0

        try:
            medium_count_value = merged_overall_df[merged_overall_df["Severity"] == "MEDIUM"]["#Occurrences"].sum()
        except:
            medium_count_value = 0

        severity_score = ((high_count_value * 150) + (medium_count_value * 50) + (low_count_value * 10))
        
        # print('severity_score------------------', severity_score)
        
        run_data_df['High_Alerts'] = high_count_value
        run_data_df['Medium_Alerts'] = medium_count_value
        run_data_df['Low_Alerts'] = low_count_value
        run_data_df['Severity_Score'] = severity_score
        
        try:
            module_count_value = f"{[merged_overall_df.groupby(['Module']).size().reset_index(name='#Occurances')]}"
        except:
            module_count_value = 0
        run_data_df['Module_Wise_Count'] = module_count_value
        
        try:
            final_report_insight_value =  f"{[merged_overall_df[['Module','Alerts']]]}"
        except:
            final_report_insight_value = 0
        run_data_df['Summary'] = final_report_insight_value
        
        if severity_score >= 1000:
            overall_assessment_value = "HIGH"
        elif severity_score >= 500 and severity_score < 1000:
            overall_assessment_value = "MEDIUM"
        elif severity_score > 0 and severity_score < 500:
            overall_assessment_value = "LOW"
        else:
            overall_assessment_value = ""
               

        if overall_assessment_value == "":
            merged_overall_df.loc[len(merged_overall_df.index)] = []
            run_data_df['Overall_Severity'] = overall_assessment_value
            run_data_df['Overall_Occurrences'] = ''
        else:
            del merged_overall_df['Severity Score']
            merged_overall_df.loc[len(merged_overall_df.index)] = ["Overall","Overall Assessment",overall_assessment_value,merged_overall_df["#Occurrences"].sum()]
            # print('---------------------------------------2')
            # display(merged_overall_df)
            
            
            run_data_df['Overall_Severity'] = overall_assessment_value
            run_data_df['Overall_Occurrences'] = int(merged_overall_df[merged_overall_df['Module'] == 'Overall']['#Occurrences'])
            severity_values = {'HIGH': 150, 'MEDIUM': 50, 'LOW': 10}
            merged_overall_df['Severity Value'] = merged_overall_df['Severity'].map(severity_values)
            merged_overall_df['Severity Score'] = merged_overall_df['Severity Value'] * merged_overall_df['#Occurrences']
            
            total_severity_score_merged = merged_overall_df[merged_overall_df['Module'] != 'Overall']['Severity Score'].sum()
            merged_overall_df.loc[merged_overall_df['Module'] == 'Overall', 'Severity Score'] = total_severity_score_merged
            del merged_overall_df['Severity Value']
            

        dataframes = [d for d in dataframes if d["sheet_name"] != 'Overall Assessment']
        dataframes1 = [d for d in dataframes1 if d["sheet_name"] != 'Overall Assessment']
        dataframes.extend(dataframes1)
        dataframes.append({"df": merged_overall_df, "sheet_name": "Overall Assessment"})
        
        # print('---------------------------------------3')
        # display(dataframes)
        
    for df in dataframes:
        serial_number(df["df"])

    sheet_order = [
    'Overall Assessment',
    '1A. Metadata_Raw_Output', '1B. Metadata_Report',
    '2A. Font_Raw_Output', '2B. Font_Report',
    '2A. Font_Raw_Output_Img', '2B. Font_Report_Img',
    '3A.Annotation_Raw_Output', '3B.Annotation_Report',
    '4A.Overlay_Raw_Output', '4B.Overlay_Report',
    '4A. Overlay_Raw_Output_Img', '4B. Overlay_Report_Img',
    '5A.Language_Raw_Output', '5B.Language_Report',
    '6A.Logo_Raw_Output', '6B.Logo_Report',
    '7A.Reconciliation_Raw_Output', '7B.Reconciliation_Report',
]
    dataframes_dict = {d["sheet_name"]: d["df"] for d in dataframes}
    # if merged_overall_df is not None:
    #     dataframes_dict['Overall Assessment'] = merged_overall_df

    ordered_dataframes = [{"df": dataframes_dict[sheet], "sheet_name": sheet} for sheet in sheet_order if sheet in dataframes_dict]

    write_to_excel(ordered_dataframes, fraud_report_file_path)
    formatting_excel(fraud_report_file_path)

def run_single_module(module_name,  *args):

    module_functions = {
        constants.BANKNAME_MODULE: bankname,
        constants.METADATA_ENTRY_MODULE: MetadataAnalyzer.metadata_entry,
        constants.LOGO_ENTRY_MODULE: LogoModule.logo_module_entry,
        constants.LOGO_HIGHLIGHT_MODULE: LogoModule.highlight_pdf,
        constants.FONT_ENTRY_MODULE: FontAnalysis.font_data_entry,
        constants.FONT_HIGHLIGHT_MODULE: FontAnalysis.highlight_pdf,
        constants.ANNOTATION_ENTRY_MODULE: Annotation.annotations_entry,
        constants.ANNOTATION_HIGHLIGHT_MODULE: Annotation.highlight_pdf,
        constants.OVERLAY_ENTRY_MODULE: Overlay.overlay_entry,
        constants.OVERLAY_HIGHLIGHT_MODULE: Overlay.highlight_pdf,
        constants.LANGUAGE_ENTRY_MODULE: LanguageModel.language_entry,
        constants.LANGUAGE_HIGHLIGHT_MODULE: LanguageModel.highlight_pdf,
        constants.RECONCILIATION_ENTRY_MODULE: Reconciliation.reconciliation_entry,
        # constants.GENERATE_REPORT: generate_report,
        constants.HIGHLIGHT_MODULE: HighlightModule.highlight_pdf,
        constants.CREATE_EXCEL_FILE: write_to_excel,
        constants.EXCEL_TO_JSON: excel_to_json,
        constants.CREATE_ERROR_REPORT: error_json,
    }

    if module_name in module_functions:
        return module_functions[module_name](*args)
    else:
        raise ModuleNotFoundError(
            f"Function 'your_function_name' not found in module '{module_name}'")


def formatting_excel(excel_file_Path):
    
    xls = read_from_data_lake(excel_file_Path, formating = constants.IS_S3_PATH)
    sheet_names = xls.sheet_names
    current_date = datetime.today()
    # Format the date
    formatted_date = current_date.strftime("%d-%b-%Y")
    i = 1
    excel_bytes_io = io.BytesIO()

    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as excel_writer:

        for sheet in sheet_names:
            df = read_from_data_lake(excel_file_Path, sheet_name=sheet)
            df.to_excel(excel_writer, sheet_name='Sheet'+str(i), index=False, startrow=1, startcol=1)
            excel_writer.sheets['Sheet'+str(i)].name = sheet  # Rename to 'MySheet'

            workbook  = excel_writer.book
            worksheet1 = excel_writer.sheets['Sheet'+str(i)]
            worksheet1.hide_gridlines(2)

            bold_format = workbook.add_format({'bold': True})
            header_format1 = workbook.add_format({'border': 1, 'bg_color': '#FB4E0B', 'font_color': 'white'})

            for col_num, value in enumerate(df.columns.values):
                worksheet1.write(1, col_num+1, value, header_format1)
                max_len = max(df[value].astype(str).map(len).max(), len(value))
                if pd.isna(max_len):
                    max_len = len(value)
                worksheet1.set_column(0, 0, 2)
                if sheet == 'Overall Assessment':
                    worksheet1.write(0, 1, f"Date of Processing - {formatted_date}",bold_format)
                    worksheet1.set_column(1, 2, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, width = max_len + 2)
                    worksheet1.set_column(2,2, width = 14, cell_format=bold_format)
                else:
                    worksheet1.set_column(1, 1, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, max_len + 2)  # Add some padding

            # Define cell format for thick border
            light_border_format = workbook.add_format({'border': 1})  # 1 denotes thin border

            # Apply thick border to enclose the entire table
            num_rows, num_cols = df.shape
            border_range = f'B2:{chr(64 + num_cols+1)}{num_rows + 2}'  # Include header row
            try:
                worksheet1.conditional_format(border_range, {'type': 'blanks', 'format': light_border_format})
                worksheet1.conditional_format(border_range, {'type': 'no_blanks', 'format': light_border_format})
            except:
                pass

            i = i + 1

    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, excel_file_Path)


def run_all_modules(input_file_path, input_json_filename, bank_name_excel_path, fraud_report_file_path,
                    font_output_pdf_path, font_output_image_dir, language_module_output_pdf_path, annotations_output_pdf_path, image_annotations_dir,
                    overlay_output_pdf_path, image_overlap_dir, logo_output_pdf_path,
                    image_logo_dir, alerts_json_file_path, error_json_file_path, json_output_dir, run_data_df, four_corner_run, strategy="sequential"):

    prep_time2 = time.time()
    input_next_module = input_file_path
    doc = read_from_data_lake(input_next_module)
    num_pages = doc.page_count
    
    pdf_filename_file = os.path.basename(input_next_module)
    run_data_df['Pdf_Filename'] = [pdf_filename_file]
    run_data_df['Num_Of_Pages'] = num_pages
    
    # bank_names = bankname(input_json_filename, bank_name_excel_path)
    # bank_names = bankname(bank_name_excel_path)
    bank_names = bank_name_excel_path
    run_data_df['Bank_Name'] = bank_names

    is_digital_pdf = is_pdf_digital(input_file_path)
    highlight_info = {}
    error_info = {}
    if is_digital_pdf:
        print("DIGITAL PDF")
        run_data_df['Pdf_Type'] = 'Digital'
        fn_mappings = [
            ("Metadata", MetadataAnalyzer.metadata_entry, (input_next_module, bank_names, pdf_filename_file, four_corner_run, "Digital")),
            ("Logo", LogoModule.logo_module_entry, (input_next_module, bank_names, pdf_filename_file, image_logo_dir)),
            ("Font", FontAnalysis.font_data_entry, (input_next_module, bank_names, pdf_filename_file)),
            ("Annotation", Annotation.annotations_entry, (input_next_module, image_annotations_dir)),
            ("Overlay", Overlay.overlay_entry, (input_next_module, bank_names, image_overlap_dir, "Digital")),
            ("Language", LanguageModel.language_entry, (input_next_module, input_json_filename)),
            ("Reconciliation", Reconciliation.reconciliation_entry, (input_next_module, input_json_filename)),
        ]
        
        preproc_time2 = time.time() - prep_time2
        run_data_df['Preprocessing_Time'] = preproc_time2

        
        parallel_run_time = time.time()
        mp_array, runtimes = Parallelize.run_parallelize(fn_mappings=fn_mappings, num_cores=constants.NUM_CORES, strategy=strategy)
        all_module_parallel_run_time = time.time() - parallel_run_time
        run_data_df['All_Module_Parallel_Run_Time'] = all_module_parallel_run_time
        print('module_parallel_run_time-----------------------------',all_module_parallel_run_time)
        
        # meta_st = time.time()
        final_report_insight1, excel_df1, df_meta, meta_error_list = mp_array[0]
        # meta_time = time.time() - meta_st
        run_data_df['Metadata_Run_Time'] = runtimes[0]
        
        # logo_st = time.time()
        final_report_insight2, excel_df2, highlight_coords_logo, logo_error_list = mp_array[1]
        # logo_time = time.time() - logo_st
        run_data_df['Logo_Run_Time'] = runtimes[1]
        
        # font_st = time.time()
        final_report_insight3, excel_df3, df_final_font, highlight_coords_font, font_error_list = mp_array[2]
        # font_time = time.time() - font_st
        run_data_df['Font_Run_Time'] = runtimes[2]
        
        # ann_st = time.time()
        final_report_insight4, excel_df4, highlight_coords_annot, annotation_error_list = mp_array[3]
        # ann_time = time.time() - ann_st
        run_data_df['Annotation_Run_Time'] = runtimes[3]
        
        # overlay_st = time.time()
        final_report_insight5, excel_df5, highlight_coords_overlay, overlay_error_list = mp_array[4]
        # Overlay_time = time.time() - overlay_st
        run_data_df['Overlay_Run_Time'] = runtimes[4]
        
        # lang_st = time.time()
        final_report_insight6, excel_df6, highlight_coords_lang, language_error_list = mp_array[5]
        # lang_time = time.time() - lang_st
        run_data_df['Language_Run_Time'] = runtimes[5]
        
        # recon_st = time.time()
        final_report_insight7, excel_df7, reconciliation_error_list = mp_array[6]
        # Recon_time = time.time() - recon_st
        run_data_df['Reconciliation_Run_Time'] = runtimes[6]
        
        highlight_st = time.time()
        highlight_info[constants.LOGO_HIGHLIGHT_MODULE] = highlight_coords_logo
        highlight_info[constants.FONT_HIGHLIGHT_MODULE] = highlight_coords_font
        highlight_info[constants.ANNOTATION_HIGHLIGHT_MODULE] = highlight_coords_annot
        highlight_info[constants.OVERLAY_HIGHLIGHT_MODULE] = highlight_coords_overlay
        highlight_info[constants.LANGUAGE_HIGHLIGHT_MODULE] = highlight_coords_lang
        HighlightModule.highlight_pdf(input_next_module, highlight_info, language_module_output_pdf_path)
        highlight_time = time.time() - highlight_st
        run_data_df['Highlight_Run_Time'] = highlight_time

        error_info[constants.METADATA_ENTRY_MODULE] = meta_error_list
        error_info[constants.LOGO_ENTRY_MODULE] = logo_error_list
        error_info[constants.FONT_ENTRY_MODULE] = font_error_list
        error_info[constants.ANNOTATION_ENTRY_MODULE] = annotation_error_list
        error_info[constants.OVERLAY_ENTRY_MODULE] = overlay_error_list
        error_info[constants.LANGUAGE_ENTRY_MODULE] = language_error_list
        error_info[constants.RECONCILIATION_ENTRY_MODULE] = reconciliation_error_list

        excel_st = time.time()
        create_overall_assessment(excel_df1['tabs_df'].loc[0], excel_df1['tabs_df'].loc[1], excel_df3['tabs_df'].loc[0], excel_df3['tabs_df'].loc[1], excel_df4['tabs_df'].loc[0], excel_df4['tabs_df'].loc[1], excel_df5['tabs_df'].loc[0], excel_df5['tabs_df'].loc[1], excel_df6['tabs_df'].loc[0], excel_df6['tabs_df'].loc[1], excel_df2['tabs_df'].loc[0], excel_df2['tabs_df'].loc[1], excel_df7['tabs_df'].loc[0], excel_df7['tabs_df'].loc[1], None, None, None, None, fraud_report_file_path, is_digital_pdf, run_data_df)
        excel_time = time.time() - excel_st
        run_data_df['Output_Excel_Creation_Time'] = excel_time
        
        
        run_data_df['Pdf_Type'] = 'Digital'

    else:
        run_data_df['Pdf_Type'] = 'Scanned'
        doc = read_from_data_lake(input_next_module)
        doc.save('temp_input_next_module.pdf')
#         # pdf_document = fitz.open("scanned_document.pdf")
#         page = doc.load_page(0)
#         page_width = page.rect.width  # Width in points
#         page_height = page.rect.height  # Height in points
        
#         images = convert_from_path('temp_input_next_module.pdf', dpi=500)
#         first_page_image = images[0]
#         cv_image =np.array(images[0])
#         # Get image dimensions
#         width, height = first_page_image.size
        
#         scale_width = page_width/width
#         scale_height = page_height/height

#         # Convert the image to a PIL Image
#         pil_image = Image.fromarray(cv_image)        
#         # temp_image_path = os.path.join('temp.png')
#         with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp_image_file:
#             temp_image_path = temp_image_file.name
#             pil_image.save(temp_image_path)
                    
#         # temp_image_path = os.path.join('temp.png')
#         with open(temp_image_path,'rb') as temp_image_file:
#             image_bytes = temp_image_file.read()
#         # print('image_logo_dir---------------',image_logo_dir)
        
#         image_path = os.path.join(image_logo_dir,"temp_image.png")
#         write_to_data_lake(image_bytes, image_path)
        
        
        # Open the PDF document with PyMuPDF
        pdf_document = fitz.open('temp_input_next_module.pdf')

        # Convert all pages of the PDF to images
        images = convert_from_path('temp_input_next_module.pdf', dpi=500)
        image_path_list = []
        
        # Process each page
        for i, image in enumerate(images):
            # Load the corresponding page
            page = doc.load_page(i)

            # Get page dimensions
            page_width = page.rect.width  # Width in points
            page_height = page.rect.height  # Height in points

            # Convert the image to a numpy array
            cv_image = np.array(image)

            # Get image dimensions
            width, height = image.size

            # Calculate scale factors
            scale_width = page_width / width
            scale_height = page_height / height
            
            # Convert the image to a PIL Image
            pil_image = Image.fromarray(cv_image)

            # Save the image to a temporary file
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp_image_file:
                temp_image_path = temp_image_file.name
                pil_image.save(temp_image_path)

            # Read the image bytes
            with open(temp_image_path, 'rb') as temp_image_file:
                image_bytes = temp_image_file.read()

            # Define the image path in the data lake
            image_path = os.path.join(image_logo_dir, f"temp_image_{i}.png")
            # print('--------------------------image_path', image_path)
            # Write the image to the data lake
            write_to_data_lake(image_bytes, image_path)
            image_path_list.append((scale_width, scale_height, image_path))
            
        
        fn_mappings = [
            ("Metadata", MetadataAnalyzer.metadata_entry, (input_next_module, bank_names, pdf_filename_file, four_corner_run, "Scanned")),
            ("Font", FontAnalysisImg.font_data_entry, (image_path_list, font_output_image_dir)),
            ("Overlay", Overlay.overlay_entry, (input_next_module, bank_names, image_overlap_dir, "Scanned")),
            ("Image Overlay", OverlayImg.overlay_entry, (image_path_list, image_overlap_dir)),
            ("Annotation", Annotation.annotations_entry, (input_next_module, image_annotations_dir)),
            ("Reconciliation", Reconciliation.reconciliation_entry, (input_next_module, input_json_filename)),
        ]
        
        preproc_time2 = time.time() - prep_time2
        run_data_df['Preprocessing_Time'] = preproc_time2
        # print('Preprocessing_Time-----------------------------',preproc_time2)
        
        parallel_run_time = time.time()
        mp_array, runtimes = Parallelize.run_parallelize(fn_mappings=fn_mappings, num_cores=constants.NUM_CORES, strategy=strategy)
        all_module_parallel_run_time = time.time() - parallel_run_time
        # print('module_parallel_run_time-----------------------------',all_module_parallel_run_time)
        # print('runtimes-----------------------------',runtimes)
        run_data_df['All_Module_Parallel_Run_Time'] = all_module_parallel_run_time
        
        
        # meta_st = time.time()
        final_report_insight1, excel_df1, df_meta, meta_error_list = mp_array[0]
        # meta_time = time.time() - meta_st
        run_data_df['Metadata_Run_Time'] = runtimes[0]
        
        # img_font_st = time.time()
        font_df, misalignment_coordinates, font_report, extra_spaces_coor, font_error_list = mp_array[1]
        # image_font_time = time.time() - img_font_st
        run_data_df['Img_Font_Run_Time'] = runtimes[1]
        
        # overly_st = time.time()
        final_report_insight5, excel_df5, highlight_coords_overlay, overlay_error_list = mp_array[2]
        # overly_time = time.time() - overly_st
        run_data_df['Overlay_Run_Time'] = runtimes[2]
        
        # img_overly_st = time.time()
        overlay_df, copymove_coordinates, newtext_coordinates, overlay_report, overlay_error_list1 = mp_array[3]
        # img_overly_time = time.time() - img_overly_st
        run_data_df['Img_Overlay_Run_Time'] = runtimes[3]
        
        # ann_st = time.time()
        final_report_insight4, excel_df4, highlight_coords_annot, annotation_error_list = mp_array[4]
        # ann_time = time.time() - ann_st
        run_data_df['Annotation_Run_Time'] = runtimes[4]
        
        # recon_st = time.time()
        final_report_insight7, excel_df7, reconciliation_error_list = mp_array[5]
        # Recon_time = time.time() - recon_st
        run_data_df['Reconciliation_Run_Time'] = runtimes[5]
        
        all_coordinates = [copymove_coordinates, newtext_coordinates, misalignment_coordinates, extra_spaces_coor]
        
        copymove_coordinates.extend(newtext_coordinates)
        # copymove_coordinates = [[0, [coord[0] * scale_width, coord[1] * scale_height, coord[2] * scale_width, coord[3] * scale_height]] for coord in copymove_coordinates]
        highlight_coords_overlay.extend(copymove_coordinates)
        # print('highlight_coords_overlay--------------------',highlight_coords_overlay)
        # extra_spaces_coor = [[x1, y1, x2, y2] for [(x1, y1), (x2, y2)] in extra_spaces_coor]
        
        misalignment_coordinates.extend(extra_spaces_coor)
        # print('misalignment_coordinates111--------------------',misalignment_coordinates)
        # misalignment_coordinates = [[0, [coord[0] * scale_width, coorssssd[1] * scale_height, coord[2] * scale_width, coord[3] * scale_height]] for coord in misalignment_coordinates]
        # print('misalignment_coordinates222--------------------',misalignment_coordinates)
        
        highlight_st = time.time()
        # highlight_info[constants.LOGO_HIGHLIGHT_MODULE] = misalignment_coordinates
        highlight_info[constants.FONT_HIGHLIGHT_MODULE] = misalignment_coordinates
        highlight_info[constants.ANNOTATION_HIGHLIGHT_MODULE] = highlight_coords_annot
        highlight_info[constants.OVERLAY_HIGHLIGHT_MODULE] = highlight_coords_overlay
        HighlightModule.highlight_pdf(input_next_module, highlight_info, language_module_output_pdf_path)
        
        highlight_time = time.time() - highlight_st
        run_data_df['Highlight_Run_Time'] = highlight_time
        
        overlay_error_list.extend(overlay_error_list1)
    
        error_info[constants.METADATA_ENTRY_MODULE] = meta_error_list
        error_info[constants.FONT_ENTRY_MODULE] = font_error_list
        error_info[constants.ANNOTATION_ENTRY_MODULE] = annotation_error_list
        error_info[constants.OVERLAY_ENTRY_MODULE] = overlay_error_list
        error_info[constants.RECONCILIATION_ENTRY_MODULE] = reconciliation_error_list
        
        excel_st = time.time()
        create_overall_assessment(excel_df1['tabs_df'].loc[0], excel_df1['tabs_df'].loc[1], None, None, excel_df4['tabs_df'].loc[0], excel_df4['tabs_df'].loc[1], excel_df5['tabs_df'].loc[0], excel_df5['tabs_df'].loc[1], None, None, None, None, excel_df7['tabs_df'].loc[0], excel_df7['tabs_df'].loc[1],overlay_df, overlay_report, font_df, font_report, fraud_report_file_path, is_digital_pdf, run_data_df)
        excel_time = time.time() - excel_st
        run_data_df['Output_Excel_Creation_Time'] = excel_time
        
        

    # BLOCK 4
    
    json_st = time.time()
    error_json(error_info, error_json_file_path)
    excel_to_json(fraud_report_file_path, 'Overall Assessment', json_output_dir, pdf_filename_file)
    json_time = time.time() - json_st
    run_data_df['Json_Creation_Time'] = json_time

def main(input_file_path, input_json_filename, output_base_dir, four_corner_run,bank_name_excel_path, strategy="sequential"):
    run_data_df = pd.DataFrame()
    run_time = time.time()
    
    pdf_filename_file = os.path.basename(input_file_path)
    json_output_dir = os.path.join(output_base_dir, "json_outputs")
    image_output_dir = os.path.join(output_base_dir, "images", pdf_filename_file[:-4])
    pdf_outputs_dir = os.path.join(output_base_dir, "pdf_files")
    df_output_dir = os.path.join(output_base_dir, "excel_files")
    
    
    # bank_name_excel_path = None

    if constants.IS_S3_PATH:
        fraud_report_file_path = os.path.join(constants.S3_DATA_PREFIX, df_output_dir, f"{pdf_filename_file[:-4]}_fraud_report_file_path.xlsx")
        font_output_pdf_path = os.path.join(constants.S3_DATA_PREFIX, pdf_outputs_dir, f"{pdf_filename_file[:-4]}_font_output.pdf")
        font_output_image_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "font/")
        language_module_output_pdf_path = os.path.join(constants.S3_DATA_PREFIX, pdf_outputs_dir, f"{pdf_filename_file[:-4]}_language_output.pdf")
        annotations_output_pdf_path = os.path.join(constants.S3_DATA_PREFIX, pdf_outputs_dir, f"{pdf_filename_file[:-4]}_annotations_output.pdf")
        image_annotations_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "annotations/")
        overlay_output_pdf_path = os.path.join(constants.S3_DATA_PREFIX, pdf_outputs_dir, f"{pdf_filename_file[:-4]}_overlay_output.pdf")
        image_overlap_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "overlap/")
        logo_output_pdf_path = os.path.join(constants.S3_DATA_PREFIX, pdf_outputs_dir, f"{pdf_filename_file[:-4]}_logo_output.pdf")
        image_logo_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "logo/")
        alerts_json_file_path = os.path.join(constants.S3_DATA_PREFIX, json_output_dir, f"{pdf_filename_file[:-4]}_fraud_report_file_path.json")
        error_json_file_path = os.path.join(constants.S3_DATA_PREFIX, json_output_dir, "errors.json")
        json_output_dir = os.path.join(constants.S3_DATA_PREFIX, json_output_dir)
    else:    
        fraud_report_file_path = os.path.join(df_output_dir, f"{pdf_filename_file[:-4]}_fraud_report_file_path.xlsx")
        font_output_pdf_path = os.path.join(pdf_outputs_dir, f"{pdf_filename_file[:-4]}_font_output.pdf")
        font_output_image_dir = os.path.join(image_output_dir, "font/")
        language_module_output_pdf_path = os.path.join(pdf_outputs_dir, f"{pdf_filename_file[:-4]}_language_output.pdf")
        # print('language_module_output_pdf_path-----------',language_module_output_pdf_path)
        annotations_output_pdf_path = os.path.join(pdf_outputs_dir, f"{pdf_filename_file[:-4]}_annotations_output.pdf")
        image_annotations_dir = os.path.join(image_output_dir, "annotations/")
        overlay_output_pdf_path = os.path.join(pdf_outputs_dir, f"{pdf_filename_file[:-4]}_overlay_output.pdf")
        image_overlap_dir = os.path.join(image_output_dir, "overlap/")
        logo_output_pdf_path = os.path.join(pdf_outputs_dir, f"{pdf_filename_file[:-4]}_logo_output.pdf")
        image_logo_dir = os.path.join(image_output_dir, "logo/")
        alerts_json_file_path = os.path.join(json_output_dir, f"{pdf_filename_file[:-4]}_fraud_report_file_path.json")
        error_json_file_path = os.path.join(json_output_dir, "errors.json")

        os.makedirs(json_output_dir, exist_ok=True)
        os.makedirs(image_output_dir, exist_ok=True)
        os.makedirs(pdf_outputs_dir, exist_ok=True)
        os.makedirs(df_output_dir, exist_ok=True)
        os.makedirs(image_annotations_dir, exist_ok=True)
        os.makedirs(image_overlap_dir, exist_ok=True)
        os.makedirs(image_logo_dir, exist_ok=True)

    prep_time = time.time() - run_time
    run_data_df['Directory_Creation_Time'] = prep_time
    run_all_modules(input_file_path, input_json_filename, bank_name_excel_path, fraud_report_file_path,
                    font_output_pdf_path, font_output_image_dir, language_module_output_pdf_path, annotations_output_pdf_path, image_annotations_dir,
                    overlay_output_pdf_path, image_overlap_dir, logo_output_pdf_path,
                    image_logo_dir, alerts_json_file_path, error_json_file_path, json_output_dir, run_data_df, four_corner_run, strategy)
    overall_run_time = time.time() - run_time
    run_data_df['Overall_File_Run_Time'] = overall_run_time
    try:
        run_data_df = run_data_df[['Pdf_Filename', 'Num_Of_Pages', 'Bank_Name', 'Pdf_Type', 'Directory_Creation_Time', 
                                   'Preprocessing_Time', 'Metadata_Run_Time', 'Logo_Run_Time', 'Font_Run_Time', 'Annotation_Run_Time', 
                                   'Overlay_Run_Time', 'Language_Run_Time', 'Reconciliation_Run_Time', 'Highlight_Run_Time', 
                                   'Output_Excel_Creation_Time', 'Json_Creation_Time', 'Overall_File_Run_Time', 'File_Was_Modified', 
                                   'Metadata_Occurrences', 'Font_Occurrences', 'Annotation_Occurrences', 'Overlay_Occurrences', 
                                   'Language_Occurrences', 'Logo_Occurrences', 'Reconciliation_Occurrences', 'High_Alerts', 'Medium_Alerts', 
                                   'Low_Alerts', 'Severity_Score', 'Overall_Severity', 'Overall_Occurrences', 'Module_Wise_Count','Summary']]
        
        run_data_df.to_excel(f"files_run_info/{pdf_filename_file[:-4]}_pdf_run_info.xlsx", index=False)
        
    except:
        run_data_df = run_data_df[['Pdf_Filename', 'Num_Of_Pages', 'Bank_Name','Pdf_Type', 'Directory_Creation_Time', 
                                   'Preprocessing_Time', 'Metadata_Run_Time', 'Img_Font_Run_Time','Annotation_Run_Time', 
                                   'Overlay_Run_Time', 'File_Was_Modified', 'Img_Overlay_Run_Time', 'Reconciliation_Run_Time', 
                                   'Highlight_Run_Time', 'Output_Excel_Creation_Time', 'Json_Creation_Time', 'Overall_File_Run_Time',
                                   'Metadata_Occurrences', 'Font_Occurrences', 'Annotation_Occurrences', 'Overlay_Occurrences', 
                                   'Language_Occurrences', 'Logo_Occurrences', 'Reconciliation_Occurrences', 'High_Alerts', 
                                   'Medium_Alerts', 'Low_Alerts', 'Severity_Score', 'Overall_Severity', 'Overall_Occurrences', 'Module_Wise_Count', 'Summary']]
        
        run_data_df.to_excel(f"files_run_info/{pdf_filename_file[:-4]}_pdf_run_info.xlsx", index=False)
        
        # pass
    # display(run_data_df)

