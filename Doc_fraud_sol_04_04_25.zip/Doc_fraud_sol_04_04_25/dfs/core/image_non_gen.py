from datetime import datetime
import os
import io
import json
import pandas as pd
from dfs.modules.metadata.image_metadata import Metadata
from dfs.modules.font.image_font import FontAnalysis
from dfs.modules.overlay.image_overlay import Overlay
from dfs.modules.highlight.image_highlight import HighlightModule
from dfs.commons.ioutils.datastore_utils import write_to_data_lake, read_from_data_lake
from dfs.commons import constants


def excel_to_json(input_file_path, module_name, json_output_dir_name):
    json_output_file_name = f"{module_name}.json"
    json_output_file_name = os.path.join(json_output_dir_name, json_output_file_name)
    excel_data = read_from_data_lake(input_file_path, sheet_name=module_name, skiprows=1)
    excel_data = excel_data.drop(columns=['Unnamed: 0'], errors='ignore')
    excel_data = excel_data.where(pd.notnull(excel_data), None)
    json_data = {}
    for column in excel_data.columns:
        json_data[column] = excel_data[column].to_dict()
    
    json_info_bytes = json.dumps(json_data).encode('utf-8')
    write_to_data_lake(json_info_bytes, json_output_file_name)

def error_json(error_info, error_json_file_path):
    error_info_bytes = json.dumps(error_info).encode('utf-8')
    write_to_data_lake(error_info_bytes, error_json_file_path)

def write_to_excel(df_list, fraud_report_file_path):

    excel_bytes_io = io.BytesIO()
    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
        for df in df_list:
            pd.DataFrame(df["df"]).to_excel(writer, sheet_name=df["sheet_name"])

    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, fraud_report_file_path)

def create_overall_assessment(metadata_report, metadata_df, font_report, font_df, overlay_report, overlay_df, fraud_report_file_path):
    
    overall_df = []
    if metadata_report is not None:
        # metadata_module_df = metadata_report.assign(Module='Metadata')
        metadata_module_df = metadata_report.copy()
        metadata_module_df.insert(0, 'Module', 'Metadata')
        metadata_module_df.insert(0, 'Sheet_order', '1')
        overall_df.append(metadata_module_df)
        
    if font_report is not None:
        font_module_df = font_report.copy()
        font_module_df.insert(0, 'Module', 'Font')
        font_module_df.insert(0, 'Sheet_order', '2')
        overall_df.append(font_module_df)
        
        
    if overlay_report is not None:
        overlay_module_df = overlay_report.copy()
        overlay_module_df.insert(0, 'Module', 'Overlay')
        overlay_module_df.insert(0, 'Sheet_order', '3')
        overall_df.append(overlay_module_df)

    if overall_df:  # Check if there are any DataFrames in the list
        overall_df = pd.concat(overall_df, ignore_index=True)
        # Rename columns and adjust the order if concatenation happens
        overall_df.rename(columns={'Insight': 'Alerts', 'Severity_Level': 'Severity'}, inplace=True)
        overall_df = overall_df[['Sheet_order', 'Module', 'Alerts', 'Severity']]
        overall_df.reset_index(drop=True, inplace=True)
    else:
        print("No data to concatenate. overall_df is empty.")
        # Optionally, initialize an empty DataFrame to avoid errors later in the code
        overall_df = pd.DataFrame(columns=['Sheet_order', 'Module', 'Alerts', 'Severity'])
    overall_df_copy = overall_df.copy()
    overall_df = overall_df.groupby(['Sheet_order','Module','Alerts','Severity']).size().reset_index(name='#Occurrences')
    overall_df.drop('Sheet_order', axis=1, inplace=True)

    df_overall_high_med_low_count = overall_df_copy.groupby(['Severity']).size().reset_index(name='#Occurrences')
    # display(df_overall_high_med_low_count)
    try:
        high_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'HIGH']['#Occurrences'].values[0]
        print(high_count_value)
    except:
        high_count_value = 0

    try:
        low_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'LOW']['#Occurrences'].values[0]
        print(low_count_value)
    except:
        low_count_value = 0

    try:
        medium_count_value = df_overall_high_med_low_count[df_overall_high_med_low_count['Severity'] == 'MEDIUM']['#Occurrences'].values[0]
        print(medium_count_value)
    except:
        medium_count_value = 0

    severity_score = high_count_value*150+medium_count_value*50+low_count_value*10

    if severity_score >= 1000:
        overall_assessment_value = "HIGH"
    elif severity_score >= 500 and severity_score < 1000:
        overall_assessment_value = "MEDIUM"
    elif severity_score > 0 and severity_score < 500:
        overall_assessment_value = "LOW"
    else :
        overall_assessment_value = ""

    if overall_assessment_value == "":
        overall_df = pd.DataFrame(columns=['Module', 'Alerts', 'Severity', '#Occurrences'])
        # pass
        # overall_df.loc[len(overall_df.index)] = []
    else :
        overall_df.loc[len(overall_df.index)] = ['Overall', 'Overall Assessment', overall_assessment_value, overall_df['#Occurrences'].sum()]
        severity_values = {'HIGH': 150, 'MEDIUM': 50, 'LOW': 10}
        overall_df['Severity Value'] = overall_df['Severity'].map(severity_values)
        overall_df['Severity Score'] = overall_df['Severity Value'] * overall_df['#Occurrences']

        total_severity_score_merged = overall_df[overall_df['Module'] != 'Overall']['Severity Score'].sum()
        overall_df.loc[overall_df['Module'] == 'Overall', 'Severity Score'] = total_severity_score_merged
        del overall_df['Severity Value']
        

    
    # severity_mapping = {'LOW': 1, 'MEDIUM': 2, 'HIGH': 3}
    # overall_df['Severity_Num'] = overall_df['Severity'].map(severity_mapping)
    # highest_severity_num = overall_df['Severity_Num'].max()
    # highest_severity = [key for key, value in severity_mapping.items() if value == highest_severity_num][0]
    # overall_assessment = pd.DataFrame({
    #     'Module': ['Overall'],
    #     'Alerts': ['Overall Assessment'],
    #     'Severity': [highest_severity]
    # })
    # overall_df = pd.concat([overall_df, overall_assessment], ignore_index=True)
    # overall_df.drop(columns=['Severity_Num'], inplace=True)
    
    #fixing Sr_no
    def serial_number(df):
        if df is not None:
            df.index.name = 'Sr_no'
            df.reset_index(drop=False, inplace=True)    
            df['Sr_no'] = df.index + 1
            df.set_index('Sr_no', inplace=True)

    
    dataframes = [{"df":overall_df, "sheet_name":'Overall Assessment'},{"df":metadata_df, "sheet_name":'1A. Metadata_Raw_Output'}, 
                  {"df":metadata_report, "sheet_name":'1B. Metadata_Report'},
                  {"df":font_df, "sheet_name":'2A. Font_Raw_Output_Img'},
                  {"df":font_report, "sheet_name":'2B. Font_Report_Img'},                  
                  {"df": overlay_df, "sheet_name":'4A. Overlay_Raw_Output_Img'},
                  {"df": overlay_report, "sheet_name":'4B. Overlay_Report_Img'},
                  ]

    dataframes = [d for d in dataframes if d["df"] is not None]
    if not fraud_report_file_path:
        return dataframes

    for df in dataframes:
        serial_number(df["df"])
    

    write_to_excel(dataframes, fraud_report_file_path)
    formatting_excel(fraud_report_file_path)

# def create_overall_assessment(
#     metadata_report,
#     metadata_df,
#     font_report,
#     font_df,
#     overlay_report,
#     overlay_df,
#     fraud_report_file_path,
# ):
    
#     overall_df = []
#     if metadata_report is not None:
#         metadata_module_df = metadata_report.assign(Module="Metadata")
#         overall_df.append(metadata_module_df)

#     if overlay_report is not None:
#         overlay_module_df = overlay_report.assign(Module="Overlay")
#         overall_df.append(overlay_module_df)

#     if font_report is not None:
#         font_module_df = font_report.assign(Module="Font")
#         overall_df.append(font_module_df)

#     overall_df = pd.concat(overall_df)

#     overall_df.rename(
#         columns={"Insight": "Alerts", "Severity_Level": "Severity"}, inplace=True
#     )
#     overall_df = overall_df[["Module", "Alerts", "Severity"]]
#     overall_df.reset_index(drop=True, inplace=True)

#     severity_mapping = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
#     overall_df["Severity_Num"] = overall_df["Severity"].map(severity_mapping)
#     highest_severity_num = overall_df["Severity_Num"].max()
#     highest_severity = [
#         key for key, value in severity_mapping.items() if value == highest_severity_num
#     ][0]
#     overall_assessment = pd.DataFrame(
#         {
#             "Module": ["Overall"],
#             "Alerts": ["Overall Assessment"],
#             "Severity": [highest_severity],
#         }
#     )
#     overall_df = pd.concat([overall_df, overall_assessment], ignore_index=True)
#     overall_df.drop(columns=["Severity_Num"], inplace=True)

#     # fixing Sr_no
#     def serial_number(df):
#         if df is not None:
#             df.index.name = "Sr_no"
#             df.reset_index(drop=False, inplace=True)
#             df["Sr_no"] = df.index + 1
#             df.set_index("Sr_no", inplace=True)

#     dataframes = [
#         {"df": metadata_df, "sheet_name": "1A. Metadata_Raw_Output"},
#         {"df": metadata_report, "sheet_name": "1B. Metadata_Report"},
#         {"df": font_df, "sheet_name": "2A. Font_Raw_Output_Img"},
#         {"df": font_report, "sheet_name": "2B. Font_Report_Img"},
#         {"df": overlay_df, "sheet_name": "4A. Overlay_Raw_Output_Img"},
#         {"df": overlay_report, "sheet_name": "4B. Overlay_Report_Img"},
#         {"df": overall_df, "sheet_name": "Overall Assessment"},
#     ]

#     dataframes = [d for d in dataframes if d["df"] is not None]
#     if not fraud_report_file_path:
#         return dataframes

#     for df in dataframes:
#         serial_number(df["df"])

#     write_to_excel(dataframes, fraud_report_file_path)
#     formatting_excel(fraud_report_file_path)

def run_single_module(module_name,  *args):

    module_functions = {
        constants.METADATA_ENTRY_MODULE_IMG: Metadata.metadata_entry,
        constants.FONT_ENTRY_MODULE_IMG: FontAnalysis.font_data_entry,
        constants.OVERLAY_ENTRY_MODULE_IMG: Overlay.overlay_entry,
        constants.HIGHLIGHT_MODULE_IMG: HighlightModule.highlight_image,
        constants.CREATE_EXCEL_FILE_IMG: write_to_excel,
        constants.EXCEL_TO_JSON_IMG: excel_to_json,
        constants.CREATE_OVERALL_ASSESSMENT_IMG: create_overall_assessment,
        constants.CREATE_ERROR_REPORT: error_json
    }

    if module_name in module_functions:
        return module_functions[module_name](*args)
    else:
        raise ModuleNotFoundError(
            f"Function 'your_function_name' not found in module '{module_name}'")

def formatting_excel(input_excel_file_path):
    xls = read_from_data_lake(input_excel_file_path, formating = constants.IS_S3_PATH)
    sheet_names = xls.sheet_names
    current_date = datetime.today()
    # Format the date
    formatted_date = current_date.strftime("%d-%b-%Y")
    i = 1
    excel_bytes_io = io.BytesIO()

    with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
        for sheet in sheet_names:
            df = read_from_data_lake(input_excel_file_path, sheet_name=sheet)
            df.to_excel(writer, sheet_name='Sheet'+str(i), index=False, startrow=1, startcol=1)
            writer.sheets['Sheet'+str(i)].name = sheet

            workbook  = writer.book
            worksheet1 = writer.sheets['Sheet'+str(i)]
            worksheet1.hide_gridlines(2)

            bold_format = workbook.add_format({'bold': True})
            header_format1 = workbook.add_format({'border': 1, 'bg_color': '#FB4E0B', 'font_color': 'white'})

            for col_num, value in enumerate(df.columns.values):
                worksheet1.write(1, col_num+1, value, header_format1)
                max_len = max(df[value].astype(str).map(len).max(), len(value))
                if pd.isna(max_len):
                    max_len = len(value)
                worksheet1.set_column(0, 0, 2)
                if sheet == 'Overall Assessment':
                    worksheet1.write(0, 1, f"Date of Processing - {formatted_date}",bold_format)
                    worksheet1.set_column(1, 2, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, width = max_len + 2)
                    worksheet1.set_column(2,2, width = 14, cell_format=bold_format)
                else:
                    worksheet1.set_column(1, 1, cell_format=bold_format)
                    worksheet1.set_column(col_num+1, col_num+1, max_len + 2)  # Add some padding

            # Define cell format for thick border
            light_border_format = workbook.add_format({'border': 1})  # 1 denotes thin border

            # Apply thick border to enclose the entire table
            num_rows, num_cols = df.shape
            border_range = f'B2:{chr(64 + num_cols+1)}{num_rows + 2}'  # Include header row
            worksheet1.conditional_format(border_range, {'type': 'blanks', 'format': light_border_format})
            worksheet1.conditional_format(border_range, {'type': 'no_blanks', 'format': light_border_format})

            i = i + 1
    
    excel_bytes = excel_bytes_io.getvalue()
    write_to_data_lake(excel_bytes, input_excel_file_path)


# def run_all_modules(input_file_path, font_output_image_path, overlay_output_image_path, fraud_report_file_path, output_image_path, alerts_json_file_path, error_json_file_path, json_output_dir, four_corner_run):
    
#     metadata_df, metadata_report, meta_error_list = Metadata.metadata_entry(input_file_path, four_corner_run) #, DB_border_coor, AB_border_coor
#     font_df, misalignment_coordinates, font_report, extra_spaces_coor, font_error_list = FontAnalysis.font_data_entry(input_file_path, font_output_image_path)
#     overlay_df, copymove_coordinates, newtext_coordinates, overlay_report, overlay_error_list = Overlay.overlay_entry(input_file_path, overlay_output_image_path)

#     error_info = {}
#     error_info[constants.METADATA_ENTRY_MODULE] = meta_error_list
#     error_info[constants.FONT_ENTRY_MODULE] = font_error_list
#     error_info[constants.OVERLAY_ENTRY_MODULE] = overlay_error_list
    
#     all_coordinates = [copymove_coordinates, newtext_coordinates, misalignment_coordinates, extra_spaces_coor] #, [DB_border_coor], [AB_border_coor]]
    
#     HighlightModule.highlight_image(input_file_path, all_coordinates, output_image_path)
    
#     error_json(error_info, error_json_file_path)
#     create_overall_assessment(metadata_report, metadata_df, font_report, font_df, overlay_report, overlay_df, fraud_report_file_path)
#     excel_to_json(  fraud_report_file_path, 'Overall Assessment', json_output_dir)

def run_all_modules(input_file_path, font_output_image_path, overlay_output_image_path, fraud_report_file_path, output_image_path, alerts_json_file_path, error_json_file_path, json_output_dir, four_corner_run):
    
    enable_metadata = True
    enable_font = True
    enable_overlay = True
    
    metadata_df, metadata_report, meta_error_list = (None, None, [])
    font_df, misalignment_coordinates, font_report, extra_spaces_coor, font_error_list = (None, [], None, [], [])
    overlay_df, copymove_coordinates, newtext_coordinates, overlay_report, overlay_error_list = (None, [], [], None, [])
    
    if enable_metadata:
        metadata_df, metadata_report, meta_error_list = Metadata.metadata_entry(input_file_path, four_corner_run)
    if enable_font:
        font_df, misalignment_coordinates, font_report, extra_spaces_coor, font_error_list = FontAnalysis.font_data_entry(input_file_path, font_output_image_path)
    if enable_overlay:
        overlay_df, copymove_coordinates, newtext_coordinates, overlay_report, overlay_error_list = Overlay.overlay_entry(input_file_path, overlay_output_image_path)

    error_info = {}
    if enable_metadata:
        error_info[constants.METADATA_ENTRY_MODULE] = meta_error_list
    if enable_font:
        error_info[constants.FONT_ENTRY_MODULE] = font_error_list
    if enable_overlay:
        error_info[constants.OVERLAY_ENTRY_MODULE] = overlay_error_list
    
    # all_coordinates = [copymove_coordinates, newtext_coordinates, misalignment_coordinates, extra_spaces_coor] #, [DB_border_coor], [AB_border_coor]]
    all_coordinates = []
    if enable_overlay:
        all_coordinates.extend([copymove_coordinates, newtext_coordinates])
    if enable_font:
        all_coordinates.extend([misalignment_coordinates, extra_spaces_coor])
    if all_coordinates:
        HighlightModule.highlight_image(input_file_path, all_coordinates, output_image_path)
    
    error_json(error_info, error_json_file_path)
    create_overall_assessment(metadata_report, metadata_df, font_report, font_df, overlay_report, overlay_df, fraud_report_file_path)
    excel_to_json(  fraud_report_file_path, 'Overall Assessment', json_output_dir)


def main(input_file_path, output_base_dir, four_corner_run, strategy="sequential"):
    json_output_dir = os.path.join(output_base_dir, "json_outputs")
    image_output_dir = os.path.join(output_base_dir, "images")
    df_output_dir = os.path.join(output_base_dir, "excel_files")
    img_filename = os.path.basename(input_file_path)

    if constants.IS_S3_PATH:
        fraud_report_file_path = os.path.join(constants.S3_DATA_PREFIX, df_output_dir, f"{img_filename[:-4]}_fraud_report_file_path.xlsx")
        font_output_image_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "font")
        overlay_output_image_dir = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "overlay")
        output_image_path = os.path.join(constants.S3_DATA_PREFIX, image_output_dir, "output.png")
        alerts_json_file_path = os.path.join(constants.S3_DATA_PREFIX, json_output_dir, "fraud_report_file_path.json")
        error_json_file_path = os.path.join(constants.S3_DATA_PREFIX, json_output_dir, "errors.json")

    else:
        fraud_report_file_path = os.path.join(df_output_dir, f"{img_filename[:-4]}_fraud_report_file_path.xlsx")
        font_output_image_dir = os.path.join(image_output_dir, "font/")
        overlay_output_image_dir = os.path.join(image_output_dir, "overlay/")
        output_image_path = os.path.join(image_output_dir, f"{img_filename[:-4]}_output.png")
        alerts_json_file_path = os.path.join(json_output_dir, f"{img_filename[:-4]}_fraud_report_file_path.json")
        error_json_file_path = os.path.join(json_output_dir, f"{img_filename[:-4]}_errors.json")

        os.makedirs(json_output_dir, exist_ok=True)
        os.makedirs(image_output_dir, exist_ok=True)
        os.makedirs(df_output_dir, exist_ok=True)
    

    run_all_modules(input_file_path, font_output_image_dir, overlay_output_image_dir, fraud_report_file_path, output_image_path, alerts_json_file_path, error_json_file_path, json_output_dir, four_corner_run)


if __name__ == "__main__":
    input_file_path = "Test_Docs_json_pdfs/Demo_Input_Image.png"
    output_norm_path = "output"
    main(input_file_path, output_norm_path)
