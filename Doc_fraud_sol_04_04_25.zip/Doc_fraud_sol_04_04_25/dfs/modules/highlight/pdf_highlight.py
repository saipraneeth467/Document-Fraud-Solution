import os
import fitz
from flair.models import SequenceTagger
from flair.data import Sentence
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake

tagger = SequenceTagger.load("flair/ner-english")

class HighlightModule():

    @staticmethod
    def highlight_font(doc, df, page_num):
        page = doc[page_num]
        for j in range(len(df['bbox'])):
            if 'Enespañd:' not in df['text'][j]:
                st = Sentence(df['text'][j])
                tagger.predict(st)
                et = list(df['bbox'][j])
                highlight = page.add_highlight_annot(et)
                highlight.set_colors({"stroke": (1, 1, 0)})
                highlight.update()
        return doc
    
    @staticmethod
    def highlight_language(doc, bbox, page_num, label):
        l = label
        i = 0
        for page in doc:
            i += 1
            for j in range(len(page_num)):
                if i == page_num[j]:
                    if l == 1:
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()
                    elif l == 2:
                        # print(bbox[j])
                        try:
                            highlight = page.add_highlight_annot(bbox[j])
                            highlight.set_colors({"stroke":(0, 1, 0)})
                            highlight.update()
                        except:
                            pass
                    elif l == 3:
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()
                    elif l == 4:
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()
        return doc
    
    @staticmethod
    def draw_box_annot(doc1, df1, page_num1):
        page1 = doc1[page_num1]
        for j in range(len(df1['Bounding_Box'])):
            if df1['Annotation_Type'][j] == 'Ink':
                page1.draw_rect(df1['Bounding_Box'][j],
                                color=(1, 0, 0), width=1)
            if df1['Annotation_Type'][j] == 'FreeText':
                page1.draw_rect(df1['Bounding_Box'][j],
                                color=(1, 0, 0), width=1)
        return doc1
    

    @classmethod
    def highlight_pdf(cls, input_filename, modules_coord_info, output_pdf_path):
        doc = read_from_data_lake(input_filename)

        for module_name in modules_coord_info.keys():
            highlight_coords = modules_coord_info[module_name]
            
            if module_name == constants.LOGO_HIGHLIGHT_MODULE:
                for t in highlight_coords:
                    Page = doc[t[0]]
                    Page.draw_rect(t[1],  color=(0, 1, 0), width=2)

            elif module_name == constants.FONT_HIGHLIGHT_MODULE:
                for t in highlight_coords:
                    try:
                        doc = cls.highlight_font(doc, t[0], t[1])
                    except:
                        Page = doc[t[0]]
                        Page.wrap_contents()
                        Page.draw_rect(t[1],  color=(1, 1, 0), width=1)

            elif module_name == constants.ANNOTATION_HIGHLIGHT_MODULE:
                for page in doc:
                    page.set_rotation(0)
                    page.wrap_contents()

                for t in highlight_coords:
                    doc = cls.draw_box_annot(doc, t[0], t[1])
            
            elif module_name == constants.OVERLAY_HIGHLIGHT_MODULE:
                for t in highlight_coords:
                    page1 = doc[t[0]]
                    page1.draw_rect(t[1],  color=(1, 0, 0), width=1)

            elif module_name == constants.LANGUAGE_HIGHLIGHT_MODULE:
                for t in highlight_coords:
                    # print("t[0]------------",t[0])
                    # print("t[1]------------",t[1])
                    # print("t[2]------------",t[2])
                    doc = cls.highlight_language(doc, t[0], t[1], t[2])

        highlight_bytes = doc.write()
        write_to_data_lake(highlight_bytes, output_pdf_path)
        doc.close()

if __name__ == '__main__':
    input_next_module = 'core_v2/Wells Fargo Tampered Input.pdf'
