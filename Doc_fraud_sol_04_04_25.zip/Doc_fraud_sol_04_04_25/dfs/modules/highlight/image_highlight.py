import io
from PIL import Image, ImageDraw
from dfs.commons.ioutils.datastore_utils import write_to_data_lake, read_from_data_lake


class HighlightModule():

    @staticmethod
    def draw_bounding_boxes(image, coordinates_list, color):
        draw = ImageDraw.Draw(image)
        for coordinates in coordinates_list:
            draw.rectangle(coordinates, outline=color, width=3)

    @classmethod
    def highlight_image(cls, input_filename, modules_coord_info, output_image_path):
        image = read_from_data_lake(input_filename)
        colors = ['red', 'blue', 'yellow', 'yellow']#, 'green', 'blue']
        # all_coordinates = [copymove_coordinates, newtext_coordinates, misalignment_coordinates, extra_spaces_coor]
        for i,highlight_coords in enumerate(modules_coord_info):
            cls.draw_bounding_boxes(image, highlight_coords, colors[i % len(colors)])
        
        image_bytes = io.BytesIO()
        image.save(image_bytes, format='PNG')
        image_bytes = image_bytes.getvalue()
        write_to_data_lake(image_bytes, output_image_path)