from langchain.vectorstores import FAISS
from langchain.document_loaders import TextLoader  # for textfiles
from tabula import read_pdf
from PyPDF2 import PdfReader
import matplotlib.patches as patches
import matplotlib.pyplot as plt
from transformers import AutoImageProcessor, TableTransformerForObjectDetection
import pdfplumber
import torch
from PIL import Image
from langchain import HuggingFaceHub
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.chains.question_answering import load_qa_chain
from langchain.text_splitter import RecursiveCharacterTextSplitter
import tempfile
import warnings
import fitz
import PyPDF2
import os
from dfs.commons import constants
import pandas as pd
import time
start_time = time.time()


os.environ["HUGGINGFACEHUB_API_TOKEN"] = constants.HUGGINGFACEHUB_API_TOKEN
os.environ["TOKENIZERS_PARALLELISM"] = constants.TOKENIZERS_PARALLELISM


class Reconciliation:
    reconciliation_error_list = []
    @staticmethod
    def document_qa_new_wf(pdf):
        with open(pdf, 'rb') as file:
            # Create a PDF reader object
            reader = PyPDF2.PdfReader(file)

            # Initialize an empty string to store the extracted text
            extracted_text = ''

            # Iterate over each page in the PDF
            # for page_num in range(num_pages):
            for page_num in range(1):
                # Extract the text from the current page
                page = reader.pages[page_num]
                text = page.extract_text()

                # Append the extracted text to the overall string
                extracted_text += text
            file.close()

        #  Write the extracted text to a text file

        documents = ""
        tmp = tempfile.NamedTemporaryFile()

        with open(tmp.name, 'w') as f:
            f.write(extracted_text)
            f.seek(0)  # Move the file pointer to the beginning of the file
            print('Text extracted and saved successfully.')

        loader = TextLoader(tmp.name)
        documents = loader.load()

        # Text Splitter
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500, chunk_overlap=10)

        docs = text_splitter.split_documents(documents)

        # Embeddings
        embeddings = HuggingFaceEmbeddings()

        # Create the vectorized db
        db = FAISS.from_documents(docs, embeddings)
        # Flan-t5-xxl
        llm = HuggingFaceHub(repo_id="google/flan-t5-xxl",
                             model_kwargs={"temperature": 0.05, "max_length": 1024})

        chain = load_qa_chain(llm, chain_type="stuff")

        query2 = "What is the Account Number? if not present any, give N/A"
        query4 = "What is the Beginning Balance? if not present any, give N/A"
        query5 = "What is the amount of Deposits/Credits? if not present any, give N/A"
        query6 = "What is the Withdrawals'Debits? if not present any, give N/A"
        query7 = "What is the Ending Balance? if not present any, give N/A"
        query8 = "What is the Average Ledger Balance? if not present any, give N/A"

        query_list = [query2, query4, query5, query6, query7, query8]
        answer_list = []

        try:
            for i in range(0, len(query_list)):
                docs = db.similarity_search(query_list[i])
                answer_list.append(
                    chain.run(input_documents=docs, question=query_list[i]))
        except:
            answer_list = []

        return answer_list

    # TABLE EXTRACTION

    @staticmethod
    def table_extraction(pdf_path, reconcile_image_dir):
        reader = PdfReader(pdf_path)
        num_pages = len(reader.pages)

        dpi = 300  # choose desired dpi here
        zoom = dpi / 72  # zoom factor, standard: 72 dpi
        magnify = fitz.Matrix(zoom, zoom)  # magnifies in x, resp. y direction
        doc = fitz.open(pdf_path)  # open document

        table_df_list = []

        for page_number in range(1, num_pages + 1):
            image_folder = reconcile_image_dir
            page = doc[page_number-1]
            pix = page.get_pixmap(matrix=magnify)  # render page to an image
            pix.save(image_folder + f"page_{page.number+1}.png")
            selected_image = pix

            if selected_image is not None:
                image_folder = reconcile_image_dir
                output_file_path = image_folder + f"page_{page_number}.png"

                # Get dimensions of the output image
                height_image = selected_image.height
                width_image = selected_image.width

            image_path = output_file_path
            image = Image.open(image_path).convert("RGB")

            image_processor = AutoImageProcessor.from_pretrained(
                "microsoft/table-transformer-detection")
            model = TableTransformerForObjectDetection.from_pretrained(
                "microsoft/table-transformer-detection")

            inputs = image_processor(images=image, return_tensors="pt")
            outputs = model(**inputs)

            target_sizes = torch.tensor([image.size[::-1]])
            results = image_processor.post_process_object_detection(
                outputs, threshold=0.9, target_sizes=target_sizes)[0]

            fig, ax = plt.subplots(1)
            ax.imshow(image)

            coordinates_list_j = []
            j = 0
            for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
                box = [round(i, 2) for i in box.tolist()]
                coordinates_list_j.append(box)
                j += 1
                class_name = model.config.id2label[label.item()]
                confidence = round(score.item(), 3)

                rect = patches.Rectangle(
                    (box[0], box[1]), box[2] - box[0], box[3] - box[1], linewidth=1, edgecolor="r", facecolor="none")
                ax.add_patch(rect)
                ax.text(box[0], box[1], f"{class_name}: {confidence}",
                        color="white", verticalalignment="top")

            plt.axis("off")

            coordinates_list = []
            i = 0
            for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
                box = [round(i, 2) for i in box.tolist()]
                coordinates_list.append(box)
                i += 1

            reader = PdfReader(pdf_path)
            page_number2 = page_number - 1
            page = reader.pages[page_number2]

            upper_right = page.cropbox.upper_right

            width_pdf = float(upper_right[0])
            height_pdf = float(upper_right[1])
            width_conversion_factor = float(round((width_image/width_pdf), 3))
            height_conversion_factor = float(
                round((height_image/height_pdf), 3))

            for table_no in range(0, len(coordinates_list)):
                uplx_no = coordinates_list[table_no][0]/width_conversion_factor
                uply_no = coordinates_list[table_no][1] / \
                    height_conversion_factor
                upper_left_x = uplx_no - 20  # 25
                upper_left_y = float(height_pdf) - float(uply_no) + 20  # 30
                lower_right_x = float(
                    coordinates_list[table_no][2]/width_conversion_factor) + 20  # 25
                lower_right_y = float(
                    height_pdf) - float(coordinates_list[table_no][3]/height_conversion_factor) - 20  # 30

                area_1 = height_pdf - upper_left_y
                area_2 = upper_left_x
                area_3 = height_pdf - lower_right_y
                area_4 = lower_right_x

                if area_1 <= 0:
                    area_1 = 0
                else:
                    pass

                if area_2 <= 0:
                    area_2 = 0
                else:
                    pass

                if area_3 >= 792:
                    area_3 = 792
                else:
                    pass

                if area_4 >= 612:
                    area_4 = 612
                else:
                    pass

                area = [area_1, area_2, area_3, area_4]

                try:
                    table_tabula2 = read_pdf(
                        pdf_path, multiple_tables=False, pages=page_number, stream=True, area=area, silent=True)
                    df = table_tabula2[0]
                    table_df_list.append(df)

                except:
                    print("table not detected by tabula library")

                bbox_1 = upper_left_x
                bbox_2 = height_pdf - upper_left_y
                bbox_3 = lower_right_x
                bbox_4 = height_pdf - lower_right_y

                if bbox_1 <= 0:
                    bbox_1 = 0
                else:
                    pass

                if bbox_2 <= 0:
                    bbox_2 = 0
                else:
                    pass

                if bbox_3 >= 612:
                    bbox_3 = 612
                else:
                    pass

                if bbox_4 >= 792:
                    bbox_4 = 792
                else:
                    pass

                with pdfplumber.open(pdf_path) as pdf:
                    page = pdf.pages[page_number2]
                    bounding_box = (bbox_1, bbox_2, bbox_3, bbox_4)
                    crop_area = page.crop(bounding_box)
                    crop_text = crop_area.extract_text().split("\n")

        return table_df_list

    # DATA CLEANING

    @staticmethod
    def data_clean(df):
        df.columns = df.iloc[0]
        df.rename(columns={'Number': 'Check Number',
                  'balance': 'Ending Balance'}, inplace=True)
        df = df.drop(index=0)
        df.fillna(0, inplace=True)
        df = df.drop('Check Number', axis=1)
        df = df.reset_index(drop=True)
        df = df.drop(df[(df['Date'] == 0) & (df['Credits'] == 0) & (
            df['Debits'] == 0) & (df['Ending Balance'] == 0)].index)
        df = df.reset_index(drop=True)
        df[['Credits', 'Debits', 'Ending Balance']] = df[[
            'Credits', 'Debits', 'Ending Balance']].astype(str)
        return df

    # ALL RULES FUNCTIONS

    @staticmethod
    def data_extraction(pdf):

        warnings.filterwarnings('ignore')

        # Data Extraction

        reader = PyPDF2.PdfReader(pdf)
        number_of_pages = len(reader.pages)
        all_text = ""

        # All Pages Extraction

        for i in range(number_of_pages):

            page = reader.pages[i]
            all_text += page.extract_text()
            all_text2 = all_text.split('\n')
            all_text3 = [x.split() for x in all_text2]

        # Page 1 Extraction

        page1 = reader.pages[0]
        text1 = page1.extract_text()

        text11 = text1.split('\n')
        text_pg1 = [x.split() for x in text11]

        # Page 2 Extraction

        page2 = reader.pages[1]
        text2 = page2.extract_text()

        text22 = text2.split('\n')
        text_pg2 = [x.split() for x in text22]

        # Page 3 Extraction

        page3 = reader.pages[2]
        text3 = page3.extract_text()

        text33 = text3.split('\n')
        text_pg3 = [x.split() for x in text33]

        # Page 4 Extraction

        page4 = reader.pages[3]
        text4 = page4.extract_text()

        text44 = text4.split('\n')
        text_pg4 = [x.split() for x in text44]

        return all_text3

    # Rule 1

    @staticmethod
    def page_number_rule2(all_text3):

        page_num = [[txt[i] + " " + txt[i+1] + " " + txt[i+2] + " " + txt[i+3]
                     for i in range(len(txt)) if i < (len(txt)-3) and txt[i] == "Page"] for txt in all_text3]
        page_num_all = [x for x in page_num if len(x)]
        page_num_list = []

        for m in page_num_all:
            page_num_list.append(m)

        pg_list1 = []
        pg_list2 = []
        pg_list3 = []
        pg_list4 = []

        for i in page_num_all:

            for j in i:
                page_num_split = j.split(' ')

                i = 1
                for k in page_num_split:
                    i += 1
                    if i == 2:
                        pg_list1.append(k)
                    elif i == 3:
                        pg_list2.append(k)
                    elif i == 4:
                        pg_list3.append(k)
                    else:
                        pg_list4.append(k)

        pg_list2_int = [eval(i) for i in pg_list2]

        max_val = pg_list2_int[3]
        min_val = pg_list2_int[0]

        if ((max_val - min_val + 1) == len(pg_list2_int)) and (max_val > min_val) and (len(pg_list2_int) > 1) and ((max_val > 0) and (min_val > 0)):

            pg_num_rule = "Rule 1: Page Number Rule Passed: The Page numbers are consistent throughout the Bank Statement"
        else:
            pg_num_rule = "Rule 1: Page Number Rule Violation: The Page numbers are not consistent throughout the Bank Statement"

        return pg_num_rule, page_num_list

    # Rule 3

    @staticmethod
    def acnt_num_rule2(all_text3):

        actnum = []
        for txt in all_text3:

            if ("Account" in txt) and ("number:" in txt) and ("summary" not in txt):

                mk1 = txt.index('Account')
                mk2 = txt.index(chr(9632), mk1)  # extended ascii code
                subString = txt[mk1: mk2]

                if subString[-2].isnumeric():

                    acc_num = subString[-2] + subString[-1]
                    actnum.append(acc_num)

                else:

                    acc_num = subString[-1]
                    actnum.append(acc_num)

            elif ("Account" in txt) and ("number:" in txt) and ("summary" in txt):

                mk1 = txt.index('Account')
                subString = txt[mk1:]
                actnum.append(subString[-1])

        if len(set(actnum)) == 1:
            acnt_num = "Rule 3: Account Number Rule Passed: The Account Number is consistent through out the Bank Statement"
        else:
            acnt_num = "Rule 3: Account Number Rule Violation: The Account Number is not consistent through out the Bank Statement"

        return acnt_num, actnum

    # RULE 4

    @staticmethod
    def begg_bal(answer_list, transc_table):

        beg_bal11 = answer_list[1]
        beg_bal1 = str(beg_bal11)
        beg_bal1 = beg_bal1.replace('$', '')
        beg_bal1 = beg_bal1.replace(',', '')
        beg_bal1 = float(beg_bal1)

        df = transc_table.copy(deep=True)

        for cr in range(len(df['Credits'])):

            i = df['Credits'][cr]
            i = i.replace('$', '')
            i = i.replace(',', '')
            i = float(i)
            df['Credits'][cr] = i

        for db in range(len(df['Debits'])):

            j = df['Debits'][db]
            j = j.replace('$', '')
            j = j.replace(',', '')
            j = float(j)
            df['Debits'][db] = j

        for en in range(len(df['Ending Balance'])):

            k = df['Ending Balance'][en]
            k = k.replace('$', '')
            k = k.replace(',', '')
            k = float(k)
            df['Ending Balance'][en] = k

        # df[['Credits', 'Debits', 'Ending Balance']] = df[['Credits', 'Debits', 'Ending Balance']].astype(float)

        beg_bal2 = df['Ending Balance'][0] - df['Credits'][0] + df['Debits'][0]

        if beg_bal1 == beg_bal2:
            beg_bal_rule = "Rule 4: Beginning Balance Rule Passed: the Beginning balance in the Account Summary matches with the transaction table's data"
        else:
            beg_bal_rule = "Rule 4: Beginning Balance Rule Violation: the Beginning balance in the Account Summary does not matche with the transaction table's data"

            return beg_bal_rule, beg_bal11, beg_bal2

    # RULE 5

    @staticmethod
    def acct_sum_dep(answer_list, transc_table):

        act_sum_dep1 = answer_list[2]
        act_sum_dep = str(act_sum_dep1)
        act_sum_dep = act_sum_dep.replace('$', '')
        act_sum_dep = act_sum_dep.replace(',', '')
        act_sum_dep = float(act_sum_dep)

        tbl_len = len(transc_table['Credits'])
        trans_tab_dep1 = transc_table['Credits'][tbl_len-1]
        trans_tab_dep = str(trans_tab_dep1)
        trans_tab_dep = trans_tab_dep.replace('$', '')
        trans_tab_dep = trans_tab_dep.replace(',', '')
        trans_tab_dep = float(trans_tab_dep)

        if act_sum_dep == trans_tab_dep:
            act_sum_dep_rule = "Rule 5: Account Summary Credits Rule Passed: the Credits in the Account Summary matches with the transaction table's data"
        else:
            act_sum_dep_rule = "Rule 5: Account Summary Credits Rule Violation: the Credits in the Account Summary does not match with the transaction table's data"

        return act_sum_dep_rule, act_sum_dep1, trans_tab_dep1

    # RULE 6

    @staticmethod
    def deposit_rule(transc_table):

        tbl_len = len(transc_table['Credits'])
        tr_dep1 = transc_table['Credits'][tbl_len-1]
        tr_dep = str(tr_dep1)
        tr_dep = tr_dep.replace('$', '')
        tr_dep = tr_dep.replace(',', '')
        tr_dep = float(tr_dep)

        df = transc_table.copy(deep=True)

        for cr in range(len(df['Credits'])):

            i = df['Credits'][cr]
            i = i.replace('$', '')
            i = i.replace(',', '')
            i = float(i)
            df['Credits'][cr] = i

        dep = df['Credits'][:tbl_len-2].sum()

        if dep == tr_dep:
            dep_rule = "Rule 6: Transaction Table Credits Rule Passed: The sum of Credits in all the transactions matches with the Total Credits"
        else:
            dep_rule = "Rule 6: Transaction Table Credits Rule Violation: The sum of Credits in all the transactions does not match with the Total Credits"

        return dep_rule, dep, tr_dep1

    # RULE 7

    @staticmethod
    def acct_sum_wtd(answer_list, transc_table):

        act_sum_wtd1 = answer_list[3]
        act_sum_wtd = str(act_sum_wtd1)
        act_sum_wtd = act_sum_wtd.replace('$', '')
        act_sum_wtd = act_sum_wtd.replace(',', '')
        act_sum_wtd = float(act_sum_wtd)

        tbl_len = len(transc_table['Debits'])
        trans_tab_wtd1 = transc_table['Debits'][tbl_len-1]
        trans_tab_wtd = str(trans_tab_wtd1)
        trans_tab_wtd = trans_tab_wtd.replace('$', '')
        trans_tab_wtd = trans_tab_wtd.replace(',', '')
        trans_tab_wtd = float(trans_tab_wtd)

        if act_sum_wtd == trans_tab_wtd:
            act_sum_wtd_rule = "Rule 7: Account Summary Debits Rule Passed: the Debits in the Account Summary matches with the transaction table's data"
        else:
            act_sum_wtd_rule = "Rule 7: Account Summary Debits Rule Violation: the Debits in the Account Summary does not matche with the transaction table's data"

        return act_sum_wtd_rule, act_sum_wtd1, trans_tab_wtd1

    # RULE 8

    @staticmethod
    def acct_sum_end_bal(answer_list, transc_table):

        act_sum_end1 = answer_list[4]
        act_sum_end = str(act_sum_end1)
        act_sum_end = act_sum_end.replace('$', '')
        act_sum_end = act_sum_end.replace(',', '')
        act_sum_end = float(act_sum_end)

        tbl_len = len(transc_table['Ending Balance'])
        trans_tab_end1 = transc_table['Ending Balance'][tbl_len-2]
        trans_tab_end = str(trans_tab_end1)
        trans_tab_end = trans_tab_end.replace('$', '')
        trans_tab_end = trans_tab_end.replace(',', '')
        trans_tab_end = float(trans_tab_end)

        if act_sum_end == trans_tab_end:
            act_sum_end_rule = "Rule 8: Account Summary Ending Balance Rule Passed: the Ending Balance in the Account Summary matches with the transaction table's data"
        else:
            act_sum_end_rule = "Rule 8: Account Summary Ending Balance Rule Violation: the Ending Balance in the Account Summary does not matche with the transaction table's data"

        return act_sum_end_rule, act_sum_end1, trans_tab_end1

    # RULE 9

    @staticmethod
    def ending_bal(transc_table):

        tbl_len = len(transc_table)

        trans_tab_end1 = transc_table['Ending Balance'][tbl_len-2]
        trans_tab_end = str(trans_tab_end1)
        trans_tab_end = trans_tab_end.replace('$', '')
        trans_tab_end = trans_tab_end.replace(',', '')
        trans_tab_end = float(trans_tab_end)

        df = transc_table.copy(deep=True)

        for cr in range(len(df['Credits'])):

            i = df['Credits'][cr]
            i = i.replace('$', '')
            i = i.replace(',', '')
            i = float(i)
            df['Credits'][cr] = i

        for db in range(len(df['Debits'])):

            j = df['Debits'][db]
            j = j.replace('$', '')
            j = j.replace(',', '')
            j = float(j)
            df['Debits'][db] = j

        for en in range(len(df['Ending Balance'])):

            k = df['Ending Balance'][en]
            k = k.replace('$', '')
            k = k.replace(',', '')
            k = float(k)
            df['Ending Balance'][en] = k

        sum = df['Ending Balance'][0]
        checks_out = 0
        doesnt_check_out = 0
        credit = 0
        debit = 0

        for i in range(1, (tbl_len-2)):
            credit += df['Credits'][i]
            debit += df['Debits'][i]

            if i == (tbl_len-3) or df['Date'][i] != df['Date'][i+1]:
                sum = sum + credit - debit
                credit = 0
                debit = 0

                if sum == df['Ending Balance'][i]:
                    checks_out += 1
                else:
                    doesnt_check_out += 1
                    daily_end_rule = "Rule 9: Transaction Table Daily Ending Balance Rule Passed: The Daily Ending Balances are correct for all of the transactions"
            else:
                daily_end_rule = "Rule 9: Transaction Table Daily Ending Balance Rule Violation: The Daily Ending Balances are not correct for all of the transactions"

        return daily_end_rule, trans_tab_end1

    # RULE 10

    @staticmethod
    def withdrawal_rule(transc_table):
        tbl_len = len(transc_table['Debits'])
        df = transc_table.copy(deep=True)

        for cr in range(len(df['Debits'])):
            i = df['Debits'][cr]
            i = i.replace('$', '')
            i = i.replace(',', '')
            i = float(i)
            df['Debits'][cr] = i

        wthd = df['Debits'][:tbl_len-2].sum()
        tr_wthd1 = transc_table['Debits'][tbl_len-1]
        tr_wthd = str(tr_wthd1)
        tr_wthd = tr_wthd.replace('$', '')
        tr_wthd = tr_wthd.replace(',', '')
        tr_wthd = float(tr_wthd)

        if wthd == tr_wthd:
            dep_rule2 = "Rule 10: Transaction Table Debits Rule Passed: The sum of Debits in all the transactions matches with the Total Debits "
        else:
            dep_rule2 = "Rule 10: Transaction Table Debits Rule Violation: The sum of Debits in all the transactions does not match with the Total Debits"

        return dep_rule2, wthd, tr_wthd1

    # RULE 11

    # Transaction Table Date Rule

    @staticmethod
    def date_rule(transc_table):

        trans_table_len2 = len(transc_table)

        df = transc_table.copy(deep=True)
        df_date = df[:trans_table_len2-2]
        df_date['Date'] = pd.to_datetime(df_date['Date'], format='%m/%d')

        data = df_date.copy(deep=True)
        data['Date'] = data['Date'].mask(
            data['Date'].dt.year == 1900, data['Date'] + pd.offsets.DateOffset(year=2015))

        data2 = data.copy(deep=True)
        data2.sort_values(by='Date')

        if data['Date'].equals(data2['Date']):
            dt_rule = "Rule 12: Date Rule Passed: The dates in the transaction table are in order"
        else:
            dt_rule = "Rule 12: Date Rule Violation: The dates in the transaction table are not in order"

        return dt_rule

    # Rule 12

    # Average ledger Balance Rule

    @staticmethod
    def avg_ldg_bal(all_text3):
        ledger_bal1 = ""
        ledger_bal2 = ""
        subString1 = []
        subString2 = []
        try:

            for txt in all_text3:
                if ("Average" in txt) and ('balance' in txt) and ('ledger' in txt) and ('(RTN):' in txt) and ('this' in txt) and ('period' in txt):
                    mk1 = txt.index('Average')
                    mk2 = txt.index('Routing', mk1)  # extended ascii code
                    subString1 = txt[mk1:mk2]

                elif ("Average" in txt) and ('balance' in txt) and ('ledger' in txt) and ('$500.00' in txt):
                    mk1 = txt.index('Average')
                    mk2 = len(txt)
                    subString2 = txt[mk1:mk2-1]

            subString1.remove('Average')
            subString1.remove('ledger')
            subString1.remove('balance')
            subString1.remove('this')
            subString1.remove('period')

            subString2.remove('Average')
            subString2.remove('ledger')
            subString2.remove('balance')
            subString2.remove('$500.00')

            for i in subString1:
                ledger_bal1 = ledger_bal1 + i
                ledger_bal1 = ledger_bal1.strip()
                ledger_bal1 = ledger_bal1.replace(',', '')
                ledger_bal1 = ledger_bal1.replace('$', '')

            ledger_bal1 = float(ledger_bal1)

            for i in subString2:
                ledger_bal2 = ledger_bal2 + i
                ledger_bal2 = ledger_bal2.strip()
                ledger_bal2 = ledger_bal2.replace(',', '')
                ledger_bal2 = ledger_bal2.replace('$', '')

            ledger_bal2 = float(ledger_bal2)
        except:
            pass

        if ledger_bal1 == ledger_bal2 and ledger_bal1 != "":
            ledger_bal_rule = "Rule 12: Average Ledger Balance Rule Passed: the Average Ledger Balance in the Account Summary matches with the transaction table's data"
        else:
            ledger_bal_rule = "Rule 12: Average Ledger Balance Rule Violation: the Average Ledger Balance in the Account Summary does not matche with the transaction table's data"

        return ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2

    # HIGHLIGHTING PDF

    @classmethod
    def Highlighting_doc(cls, doc, pg_num_rule, page_num_list, acnt_num, actnum, beg_bal_rule, beg_bal1, beg_bal2, act_sum_dep_rule, act_sum_dep, trans_tab_dep, dep_rule, dep, tr_dep, act_sum_wtd_rule, act_sum_wtd, trans_tab_wtd, act_sum_end_rule, act_sum_end, trans_tab_end, daily_end_rule, trans_tab_end2, dep_rule2, wthd, tr_wthd, dt_rule, ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2, reconcile_output_pdf_path):

        doc = fitz.open(doc)

        if pg_num_rule == 'Rule 1: The Page numbers are not consistent throughout the Bank Statement':

            page = doc[0]
            et1 = page.search_for(page_num_list[0][0])

            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[1]
            et1 = page.search_for(page_num_list[1][0])

            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[2]
            et1 = page.search_for(page_num_list[2][0])

            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[3]
            et1 = page.search_for(page_num_list[3][0])

            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if acnt_num == 'Rule 3: The Account Numbers are not consistent through out the Bank Statement':
            # if acnt_num == "Rule 3: Account Number Rule Passed: The Account Number is consistent through out the Bank Statement":

            page = doc[0]
            et1 = page.search_for(actnum[0])
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[0]
            et1 = page.search_for(actnum[1])
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[1]
            et1 = page.search_for(actnum[2])
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[2]
            et1 = page.search_for(actnum[3])
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[3]
            et1 = page.search_for(actnum[4])
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if beg_bal_rule == "Rule 4: Beginning Balance Rule Violation: the Beginning balance in the Account Summary does not matche with the transaction table's data":

            print("Rule 4 violated")
            page = doc[0]
            beg_bal1 = str(beg_bal1)
            et1 = page.search_for(beg_bal1)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if act_sum_dep_rule == "Rule 5: Account Summary Credits Rule Violation: the Credits in the Account Summary does not match with the transaction table's data":

            print("Rule 5 violated")
            page = doc[0]
            act_sum_dep = str(act_sum_dep)
            act_sum_dep = str(act_sum_dep)
            et1 = page.search_for(act_sum_dep)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[1]
            trans_tab_dep = str(trans_tab_dep)
            et1 = page.search_for(trans_tab_dep)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (0, 0.9, 0), "fill": (0.55, 0.8, 0.95)})   # LIGHT GREEN
            highlight.update()

        if dep_rule == "Rule 6: Transaction Table Credits Rule Violation: The sum of Credits in all the transactions does not match with the Total Credits":

            print("Rule 6 violated")
            page = doc[1]
            tr_dep = str(tr_dep)
            et1 = page.search_for(tr_dep)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if act_sum_wtd_rule == "Rule 7: Account Summary Debits Rule Violation: the Debits in the Account Summary does not matche with the transaction table's data":

            print("Rule 7 violated")
            page = doc[0]
            act_sum_wtd = str(act_sum_wtd)
            # print("act_sum_wtd", act_sum_wtd)
            et1 = page.search_for(act_sum_wtd)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[1]
            trans_tab_wtd = str(trans_tab_wtd)
            # print("trans_tab_wtd", trans_tab_wtd)
            et1 = page.search_for(trans_tab_wtd)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if act_sum_end_rule == "Rule 8: Account Summary Ending Balance Rule Violation: the Ending Balance in the Account Summary does not matche with the transaction table's data":

            print("Rule 8 violated")
            page = doc[0]
            act_sum_end = str(act_sum_end)
            et1 = page.search_for(act_sum_end)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

            page = doc[1]
            trans_tab_end = str(trans_tab_end)
            et1 = page.search_for(trans_tab_end)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if daily_end_rule == "Rule 9: Transaction Table Daily Ending Balance Rule Violation: The Daily Ending Balances are not correct for all of the transactions":

            print("Rule 9 violated")
            page = doc[1]
            trans_tab_end2 = str(trans_tab_end2)
            et1 = page.search_for(trans_tab_end2)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if dep_rule2 == "Rule 10: Transaction Table Debits Rule Violation: The sum of Debits in all the transactions does not match with the Total Debits":

            print("Rule 10 violated")
            page = doc[1]
            tr_wthd = str(tr_wthd)
            et1 = page.search_for(tr_wthd)
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if dt_rule == "Rule 11: Date Rule Violation: The dates in the transaction table are not in order":

            print("Rule 11 violated")
            page = doc[1]
            et1 = page.search_for('Date')
            highlight = page.add_highlight_annot(et1)
            highlight.set_colors(
                {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
            highlight.update()

        if ledger_bal_rule == "Rule 12: Average Ledger Balance Rule Violation: the Average Ledger Balance in the Account Summary does not matche with the transaction table's data":

            print("Rule 12 violated")

            for i in subString1:
                page = doc[0]
                et1 = page.search_for(i)
                highlight = page.add_highlight_annot(et1)
                highlight.set_colors(
                    {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
                highlight.update()

            for j in subString2:
                page = doc[1]
                et1 = page.search_for(j)
                highlight = page.add_highlight_annot(et1)
                highlight.set_colors(
                    {"stroke": (1, 1, 0), "fill": (0.85, 0.4, 0.95)})    # YELLOW
                highlight.update()
        doc.save(reconcile_output_pdf_path)
        return doc

    # CREATE EXCEL REPORT

    @classmethod
    def create_excel(cls, pg_num_rule, page_num_list, acnt_num, actnum, beg_bal_rule, beg_bal1, beg_bal2, act_sum_dep_rule, act_sum_dep, trans_tab_dep, dep_rule, dep, tr_dep, act_sum_wtd_rule, act_sum_wtd, trans_tab_wtd, act_sum_end_rule, act_sum_end, trans_tab_end, daily_end_rule, trans_tab_end2, dep_rule2, wthd, tr_wthd, dt_rule, ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2):
        df = pd.DataFrame(
            columns=['Reconciliation', 'Value'], index=range(1, 12))
        df2 = pd.DataFrame(
            columns=['Rule', 'Flag', 'Severity_Level', 'Insight'], index=range(1, 12))

        try:
            beg_bal1 = beg_bal1.strip()              # rule 4
            beg_bal1 = beg_bal1.replace(',', '')
            beg_bal1 = beg_bal1.replace('$', '')
            beg_bal1 = float(beg_bal1)
        except:
            beg_bal1 = ""

        try:
            act_sum_dep = act_sum_dep.strip()        # rule 5
            act_sum_dep = act_sum_dep.replace(',', '')
            act_sum_dep = act_sum_dep.replace('$', '')
            act_sum_dep = float(act_sum_dep)
        except:
            act_sum_dep = ""

        try:
            trans_tab_dep = trans_tab_dep.strip()    # rule 5
            trans_tab_dep = trans_tab_dep.replace(',', '')
            trans_tab_dep = trans_tab_dep.replace('$', '')
            trans_tab_dep = float(trans_tab_dep)
        except:
            trans_tab_dep = ""

        try:
            tr_dep = tr_dep.strip()                  # rule 6
            tr_dep = tr_dep.replace(',', '')
            tr_dep = tr_dep.replace('$', '')
            tr_dep = float(tr_dep)
        except:
            tr_dep = ""

        try:
            act_sum_wtd = act_sum_wtd.strip()        # rule 7
            act_sum_wtd = act_sum_wtd.replace(',', '')
            act_sum_wtd = act_sum_wtd.replace('$', '')
            act_sum_wtd = float(act_sum_wtd)
        except:
            act_sum_wtd = ""

        try:
            trans_tab_wtd = trans_tab_wtd.strip()    # rule 7
            trans_tab_wtd = trans_tab_wtd.replace(',', '')
            trans_tab_wtd = trans_tab_wtd.replace('$', '')
            trans_tab_wtd = float(trans_tab_wtd)
        except:
            trans_tab_wtd = ""

        try:
            act_sum_end = act_sum_end.strip()        # rule 8
            act_sum_end = act_sum_end.replace(',', '')
            act_sum_end = act_sum_end.replace('$', '')
            act_sum_end = float(act_sum_end)
        except:
            act_sum_end = ""

        try:
            trans_tab_end = trans_tab_end.strip()    # rule 8
            trans_tab_end = trans_tab_end.replace(',', '')
            trans_tab_end = trans_tab_end.replace('$', '')
            trans_tab_end = float(trans_tab_end)
        except:
            trans_tab_end = ""

        try:
            tr_wthd = tr_wthd.strip()        # rule 10
            tr_wthd = tr_wthd.replace(',', '')
            tr_wthd = tr_wthd.replace('$', '')
            tr_wthd = float(tr_wthd)
        except:
            tr_wthd = ""

        if isinstance(beg_bal1, float) and isinstance(beg_bal2, float):
            diff_beg = beg_bal1 - beg_bal2                 # Rule 4
        else:
            diff_beg = ""

        if isinstance(act_sum_dep, float) and isinstance(trans_tab_dep, float):
            diff_dep = act_sum_dep - trans_tab_dep         # Rule 5
        else:
            diff_dep = ""

        if isinstance(dep, float) and isinstance(tr_dep, float):
            diff_tr_dep = dep - tr_dep                     # Rule 6
        else:
            diff_tr_dep = ""

        if isinstance(act_sum_wtd, float) and isinstance(trans_tab_wtd, float):
            diff_act_wtd = act_sum_wtd - trans_tab_wtd     # Rule 7
        else:
            diff_act_wtd = ""

        if isinstance(act_sum_end, float) and isinstance(trans_tab_end, float):
            diff_end_balc = act_sum_end - trans_tab_end    # Rule 8
        else:
            diff_end_balc = ""

        if isinstance(wthd, float) and isinstance(tr_wthd, float):
            diff_tr_wtd = wthd - tr_wthd                   # Rule 10
        else:
            diff_tr_wtd = ""
            # Rule 9

        if daily_end_rule == "Rule 9: Transaction Table Daily Ending Balance Rule Passed: The Daily Ending Balances are correct for all of the transactions":
            diff_tr_end_balc = "Ending Daily Balance checks out"
        else:
            diff_tr_end_balc = "Ending Daily Balance doesn't check out"

        # if dt_rule == "Rule 11: Date Rule Passed: The dates in the transaction table are in order":
        if dt_rule == "Rule 12: Date Rule Passed: The dates in the transaction table are in order":
            diff_dt_rule = "Dates in order"
        else:
            diff_dt_rule = "Dates not in Order"

        if isinstance(ledger_bal1, float) and isinstance(ledger_bal2, float):
            diff_ldg = ledger_bal1 - ledger_bal2
        else:
            diff_ldg = ""

        df['Reconciliation'] = ['Page Numbers', 'Account Number', 'Beginning Balance difference between Account Summary and Transaction Table', 'Deposits/Credits difference between Account Summary and Transaction Table',
                                'Deposits/Credits difference in Transaction Table', 'Withdrawals/Debits difference between Account Summary and Transaction Table',
                                'Ending Balance difference between Account Summary and Transaction Table', 'Ending Daily Balance All Transaction Check', 'Ledger Balance difference between Account Summary and Transaction Table', 'Dates Order', 'Withdrawals/Debits difference in Transaction Table']

        df['Value'] = [page_num_list, actnum, diff_beg, diff_dep, diff_tr_dep, diff_act_wtd,
                       diff_end_balc, diff_tr_end_balc, diff_ldg, diff_dt_rule, diff_tr_wtd]

        df2['Rule'] = ['Pg_Num_not_consistent', 'Acct_Num_not_consistent', 'Beg_Bal_mismatch', 'Dep_cred_mismatch_bw_as_tt', 'Dep_cred_mismatch_in_tt',
                       'wdr_deb_mismatch_bw_as_tt', 'End_Bal_mismatch', 'End_Bal_Check', 'ledg_bal_mismatch_bw_as_tt', 'Dates_not_consistent', 'wdr_deb_mismatch_in_tt']

        tamp_ind8 = 0
        tamp_ind9 = 0
        tamp_ind1 = 0
        tamp_ind2 = 0
        tamp_ind3 = 0
        tamp_ind4 = 0
        tamp_ind5 = 0
        tamp_ind6 = 0
        tamp_ind7 = 0
        tamp_ind10 = 0
        tamp_ind11 = 0

        sev8 = ''
        sev9 = ''
        sev1 = ''
        sev2 = ''
        sev3 = ''
        sev4 = ''
        sev5 = ''
        sev6 = ''
        sev7 = ''
        sev10 = ''
        sev_11 = ''

        sev88 = ''
        sev99 = ''
        sev11 = ''
        sev22 = ''
        sev33 = ''
        sev44 = ''
        sev55 = ''
        sev66 = ''
        sev77 = ''
        sev100 = ''
        sev110 = ''

        if pg_num_rule == "Rule 1: Page Number Rule Violation: The Page numbers are not consistent throughout the Bank Statement":
            tamp_ind8 = 1
            sev8 = 'HIGH'
            sev88 = 'Page Number Mismatch Detected'
        else:
            tamp_ind8 = 0

        if acnt_num == "Rule 3: Account Number Rule Passed: The Account Number is consistent through out the Bank Statement":
            tamp_ind9 = 0
        else:
            tamp_ind9 = 1
            sev9 = 'HIGH'
            sev99 = 'Account Number Mismatch Detected'

        if beg_bal_rule == "Rule 4: Beginning Balance Rule Passed: the Beginning balance in the Account Summary matches with the transaction table's data":
            tamp_ind1 = 0
        else:
            tamp_ind1 = 1
            sev1 = 'HIGH'
            sev11 = 'Beginning Balance Mismatch Detected between Account Summary and Transaction Table'

        if act_sum_dep_rule == "Rule 5: Account Summary Credits Rule Passed: the Credits in the Account Summary matches with the transaction table's data":
            tamp_ind2 = 0
        else:
            tamp_ind2 = 1
            sev2 = 'HIGH'
            sev22 = 'Deposits/Credits Mismatch Detected between Account Summary and Transaction Table'

        if dep_rule == 'Rule 6: Transaction Table Credits Rule Violation: The sum of Credits in all the transactions does not match with the Total Credits':
            tamp_ind3 = 1
            sev3 = 'HIGH'
            sev33 = 'Deposits/Credits Mismatch Detected in Transaction Table'
        else:
            tamp_ind3 = 0

        if act_sum_wtd_rule == "Rule 7: Account Summary Debits Rule Passed: the Debits in the Account Summary matches with the transaction table's data":
            tamp_ind4 = 0
        else:
            tamp_ind4 = 1
            sev4 = 'HIGH'
            sev44 = 'Withdrawals/Debits Mismatch Detected between Account Summary and Transaction Table'

        if act_sum_end_rule == "Rule 8: Account Summary Ending Balance Rule Violation: the Ending Balance in the Account Summary does not matche with the transaction table's data":
            tamp_ind5 = 1
            sev5 = 'HIGH'
            sev55 = 'Ending Balance Mismatch Detected between Account Summary and Transaction Table'
        else:
            tamp_ind5 = 0

        if daily_end_rule == 'Rule 9: Transaction Table Daily Ending Balance Rule Violation: The Daily Ending Balances are not correct for all of the transactions':
            tamp_ind6 = 1
            sev6 = 'HIGH'
            sev66 = 'Withdrawals/Debits Mismatch Detected in Transaction Table'
        else:
            tamp_ind6 = 0

        if dep_rule2 == 'Rule 10: Transaction Table Debits Rule Violation: The sum of Debits in all the transactions does not match with the Total Debits':
            tamp_ind7 = 1
            sev7 = 'HIGH'
            sev77 = 'Withdrawals/Debits Mismatch Detected in Transaction Table'
        else:
            tamp_ind7 = 0

        if dt_rule == "Rule 11: Date Rule Violation: The dates in the transaction table are not in order":
            tamp_ind10 = 1
            sev10 = 'HIGH'
            sev100 = 'Withdrawals/Debits Mismatch Detected in Transaction Table'
        else:
            tamp_ind10 = 0

        if ledger_bal_rule == "Rule 9: Average Ledger Balance Rule Passed: the Average Ledger Balance in the Account Summary matches with the transaction table's data":
            tamp_ind11 = 0
        else:
            tamp_ind11 = 1
            sev_11 = 'HIGH'
            sev110 = 'Ledger Balance Mismatch Detected between Account Summary and Transaction Table'

        df2['Rule'] = ['Pg_Num_not_consistent', 'Acct_Num_not_consistent', 'Beg_Bal_mismatch', 'Dep_cred_mismatch_bw_as_tt', 'Dep_cred_mismatch_in_tt',
                       'wdr_deb_mismatch_bw_as_tt', 'End_Bal_mismatch_bw_as_tt', 'End_Bal_Check', 'ledg_bal_mismatch_bw_as_tt', 'Dates_not_consistent', 'wdr_deb_mismatch_in_tt']
        df2['Flag'] = [tamp_ind8, tamp_ind9, tamp_ind1, tamp_ind2, tamp_ind3,
                       tamp_ind4, tamp_ind5, tamp_ind6, tamp_ind11, tamp_ind10, tamp_ind7]
        df2['Severity_Level'] = [sev8, sev9, sev1, sev2,
                                 sev3, sev4, sev5, sev6, sev_11, sev10, sev7]
        df2['Insight'] = [sev88, sev99, sev11, sev22, sev33,
                          sev44, sev55, sev66, sev110, sev100, sev77]

        new_df2 = df2[df2['Flag'] == 1][['Insight', 'Severity_Level']]
        new_df2['Module'] = 'Reconciliation'
        new_df2.columns = ['Alerts', 'Severity', 'Module']
        new_df2 = new_df2[['Module', 'Alerts', 'Severity']]

        return new_df2, df, df2, cls.reconciliation_error_list

    @staticmethod
    def write_to_excel(df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname, index=False)

    @classmethod
    def reconcile_demo_2(cls, pdf, reconcile_image_dir):

        answer_list = cls.document_qa_new_wf(pdf)
        pdf_tables = cls.table_extraction(pdf, reconcile_image_dir)
        all_text3 = cls.data_extraction(pdf)

        pg_num_rule, page_num_list = cls.page_number_rule2(all_text3)  # Rule 1
        acnt_num, actnum = cls.acnt_num_rule2(all_text3)  # Rule 3
        ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2 = cls.avg_ldg_bal(
            all_text3)  # Rule 12

        try:
            transc_table = pdf_tables[1]
            transc_table = cls.data_clean(transc_table)
            beg_bal_rule, beg_bal1, beg_bal2 = cls.begg_bal(
                answer_list, transc_table)  # Rule 4
            act_sum_dep_rule, act_sum_dep, trans_tab_dep = cls.acct_sum_dep(
                answer_list, transc_table)  # Rule 5
            dep_rule, dep, tr_dep = cls.deposit_rule(transc_table)  # Rule 6
            act_sum_wtd_rule, act_sum_wtd, trans_tab_wtd = cls.acct_sum_wtd(
                answer_list, transc_table)  # Rule 7
            act_sum_end_rule, act_sum_end, trans_tab_end = cls.acct_sum_end_bal(
                answer_list, transc_table)  # Rule 8
            daily_end_rule, trans_tab_end2 = cls.ending_bal(
                transc_table)  # Rule 9
            dep_rule2, wthd, tr_wthd = cls.withdrawal_rule(
                transc_table)  # Rule 10
            dt_rule = cls.date_rule(transc_table)  # Rule 11
            output = [pg_num_rule, page_num_list, acnt_num, actnum, beg_bal_rule, beg_bal1, beg_bal2, act_sum_dep_rule, act_sum_dep, trans_tab_dep, dep_rule, dep, tr_dep, act_sum_wtd_rule, act_sum_wtd,
                      trans_tab_wtd, act_sum_end_rule, act_sum_end, trans_tab_end, daily_end_rule, trans_tab_end2, dep_rule2, wthd, tr_wthd, dt_rule, ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2]
        except:
            output = [pg_num_rule, page_num_list, acnt_num, actnum, "", "", "", "", "", "", "", "", "", "", "", "",
                      "", "", "", "", "", "", "", "", "", ledger_bal_rule, subString1, subString2, ledger_bal1, ledger_bal2]

        return output
        
        


if __name__ == '__main__':
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    reconciliation_output_pdf_path = os.path.join(
        "test", "pdf_files", "reconciliation_output.pdf")
    reconcile_image_dir = os.path.join("test", "images", "reconciliation")
    fraud_report_file_path = os.path.join(
        "test", 'excel_files', "fraud_report_file_path.xlsx")

    os.makedirs(os.path.dirname(fraud_report_file_path), exist_ok=True)
    os.makedirs(reconcile_image_dir, exist_ok=True)
    os.makedirs(os.path.dirname(reconciliation_output_pdf_path), exist_ok=True)

    reconcile_output_list = Reconciliation.reconcile_demo_2(
        input_next_module, reconcile_image_dir)

    Reconciliation.Highlighting_doc(
        input_next_module, *reconcile_output_list, reconciliation_output_pdf_path)
    final_report_insight_5, df_reconcile1, df_reconcile2 = Reconciliation.create_excel(
        *reconcile_output_list)

    mode = 'a'
    if not os.path.exists(fraud_report_file_path):
        mode = 'w'

    Reconciliation.write_to_excel(
        df_reconcile1, fraud_report_file_path, mode, '7A.Reconciliation_Raw_Output')
    Reconciliation.write_to_excel(
        df_reconcile2, fraud_report_file_path, mode, '7B.Reconciliation_Report')
