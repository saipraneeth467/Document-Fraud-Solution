import pandas as pd
from datetime import datetime
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake


class Reconciliation:
    reconciliation_error_list = []

    @staticmethod
    def opening_balance_rule(trans_table, data):
        n_credits_debits = 0
        reconciliation = []
        values = []
        dict1 = {}
        flag = 0
        severity = ''
        insight = ''
        Rule = 'Opening balance mismatch'
        words_to_highlight1 = []
        for x in range(len(data['results']['Account level'])):
            open_balance = abs(
                round(float(data['results']['Account level'][x]['Opening_Balance'] or 0), 2))
            n_credits_debits = n_credits_debits
            available_balance = round(
                float(trans_table['Availablebalance'][n_credits_debits]), 2)
            deposit = trans_table['CREDIT'][n_credits_debits]
            withdrawal = trans_table['DEBIT'][n_credits_debits]
            opening_bal_at_transaction_level = abs(
                round(available_balance - deposit + withdrawal, 2))
            statement_start_date = data['results']['Account level'][x]['Statement_Start_Date'] or 0
            n_credits_debits = data['results']['Account level'][x]['n_credits'] + \
                data['results']['Account level'][x]['n_debits'] + n_credits_debits

            if open_balance != opening_bal_at_transaction_level:
                dict1[statement_start_date] = f'R {(open_balance - opening_bal_at_transaction_level)}'
                flag = 1
                severity = 'HIGH'
                insight = 'Opening balance mismatch detected between account summary and transaction table'
                words_to_highlight1.append(statement_start_date)
                words_to_highlight1.append(opening_bal_at_transaction_level)

        # print('opening_Balance_rule words_to_highlight:',words_to_highlight1)
        reconciliation.append(
            'Opening balance difference between Account Summary and Transaction Table  { Statement_Start_Date : Opening balance difference} ')
        values.append(dict1)
        df1 = pd.DataFrame(list(zip(reconciliation, values)),
                           columns=['Reconciliation', 'Values'])

        df11 = pd.DataFrame(
            {'Rule': [Rule], 'Flag': flag, 'Severity_Level': severity, 'Insight': insight})
        return df1, df11, words_to_highlight1

    @staticmethod
    def closing_balance_rule(trans_table, data):
        n_credits_debits = 0
        reconciliation = []
        values = []
        dict1 = {}
        flag = 0
        severity = ''
        insight = ''
        rule = 'Closing balance mismatch'
        words_to_highlight2 = []
        for x in range(len(data['results']['Account level'])):
            try:
                closing_balance = abs(
                    round(float(data['results']['Account level'][x]['Closing_Balance'] or 0), 2))
                n_credits_debits = n_credits_debits + \
                    data['results']['Account level'][x]['n_credits'] + \
                    data['results']['Account level'][x]['n_debits']
                closing_bal_at_transaction_level = abs(
                    round(float(trans_table['Availablebalance'][n_credits_debits-1]), 2))
                statement_end_date = data['results']['Account level'][x]['Statement_End_Date'] or 0
                if closing_balance == 0:
                    pass
                elif closing_balance != closing_bal_at_transaction_level:
                    dict1[statement_end_date] = f'R {(closing_balance - closing_bal_at_transaction_level)}'
                    flag = 1
                    severity = 'HIGH'
                    insight = 'Closing balance mismatch detected between account summary and transaction table'
                    words_to_highlight2.append(statement_end_date)
                    words_to_highlight2.append(
                        closing_bal_at_transaction_level)
            except:
                print(
                    f"Closing balance value {data['results']['Account level'][x]['Closing_Balance']} present in json can not convert to float data type.")
        reconciliation.append(
            'Closing balance difference between Account Summary and Transaction Table { Statement_End_Date : Closing balance difference}')
        values.append(dict1)
        df2 = pd.DataFrame(list(zip(reconciliation, values)),
                           columns=['Reconciliation', 'Values'])

        df22 = pd.DataFrame(
            {'Rule': [rule], 'Flag': flag, 'Severity_Level': severity, 'Insight': insight})
        return df2, df22, words_to_highlight2

    @staticmethod
    def running_balance_rule(trans_table, data):
        reconciliation = []
        values = []
        dict1 = {}
        flag = 0
        severity = ''
        insight = ''
        rule = 'Running balance mismatch'
        words_to_highlight3 = []
        sum = trans_table['Availablebalance'][0]
        deposit = 0
        withdrawal = 0
        for i in range(1, len(trans_table)):
            deposit += trans_table['CREDIT'][i]
            withdrawal += trans_table['DEBIT'][i]
            sum = round((sum) + (deposit) - (withdrawal), 2)
            if sum != trans_table['Availablebalance'][i]:
                dict1['Txndate'] = trans_table['Txndate'][i]
                dict1['Availablebalance'] = f"R {trans_table['Availablebalance'][i]}"
                values.append(dict1)
                flag = 1
                severity = 'HIGH'
                insight = 'Running balance mismatch detected in transaction table'
                words_to_highlight3.append(trans_table['Txndate'][i])
                words_to_highlight3.append(trans_table['Availablebalance'][i])

                if len(values) == 3:
                    break

            deposit = 0
            withdrawal = 0
            dict1 = {}
        reconciliation.append(
            'Running balance check [Txndate,Availablebalance]')
        df3 = pd.DataFrame(
            {'Reconciliation': reconciliation, 'Values': [values]})

        df33 = pd.DataFrame(
            {'Rule': [rule], 'Flag': flag, 'Severity_Level': severity, 'Insight': insight})
        return df3, df33, words_to_highlight3

    @staticmethod
    def duplicate_transaction_count_rule(trans_table, data):
        duplicate_transaction = trans_table[trans_table.duplicated(
            ['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance'], keep=False)]
        sorted_duplicate_transaction = duplicate_transaction.sort_values(
            by=['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance'])
        group_counts = (sorted_duplicate_transaction.groupby(
            ['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance']).size()-1).reset_index(name='duplicate_count')
        duplicate_transaction_count = group_counts.duplicate_count.sum()
        reconciliation = []
        values = []
        flag = 0
        severity = ''
        insight = ''
        rule = 'Duplicate transaction detected'
        if duplicate_transaction_count > 0:
            flag = 1
            severity = 'HIGH'
            insight = 'duplicate transaction detected in transaction table'

        reconciliation.append('Total count of duplicate transactions')
        values.append(duplicate_transaction_count)
        df4 = pd.DataFrame(list(zip(reconciliation, values)),
                           columns=['Reconciliation', 'Values'])

        df44 = pd.DataFrame(
            {'Rule': [rule], 'Flag': flag, 'Severity_Level': severity, 'Insight': insight})
        return df4, df44

    @staticmethod
    def duplicate_transaction_records_rule(trans_table, data):
        duplicate_transaction = trans_table[trans_table.duplicated(
            ['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance'], keep=False)]
        sorted_duplicate_transaction = duplicate_transaction.sort_values(
            by=['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance'])
        group_counts = (sorted_duplicate_transaction.groupby(
            ['Txndate', 'TransactionType', 'Txnamount', 'Description', 'Availablebalance']).size()-1).reset_index(name='duplicate_count')
        group_counts = group_counts[[
            'Txndate', 'Txnamount', 'Availablebalance']]
        reconciliation = []
        values = []
        dict1 = {}
        words_to_highlight4 = []

        for i in range(len(group_counts)):
            dict1['Txndate'] = group_counts['Txndate'][i]
            dict1['Txnamount'] = f"R {group_counts['Txnamount'][i]}"
            dict1['Availablebalance'] = f"R {group_counts['Availablebalance'][i]}"
            values.append(dict1)
            words_to_highlight4.append(group_counts['Txndate'][i])
            words_to_highlight4.append(group_counts['Txnamount'][i])
            words_to_highlight4.append(group_counts['Availablebalance'][i])
            if len(values) == 3:
                break
            dict1 = {}
        reconciliation.append(
            'Duplicate transaction records [Txndate, Txnamount, Availablebalance]')
        df5 = pd.DataFrame(
            {'Reconciliation': reconciliation, 'Values': [values]})
        return df5, words_to_highlight4

    @staticmethod
    def metadata_check_rule(pdf_file, data):
        reader = read_from_data_lake(pdf_file)
        if type(reader.metadata) == None.__class__:
            pdf_info = {'/Producer': '', '/CreationDate': '', '/ModDate': '',
                        '/Author': '', '/Creator': '', '/Keywords': '', '/Subject': '', '/Title': ''}
        else:
            pdf_info = reader.metadata

        reconciliation = []
        values = []
        flag = 0
        severity = ''
        insight = ''
        rule = 'Metadata_check_rule'

        try:
            creation_date = pdf_info['/CreationDate']
            if creation_date.startswith("D:"):
                year = int(creation_date[2:6])
                month = int(creation_date[6:8])
                day = int(creation_date[8:10])
                creation_date = f"{year:04d}-{month:02d}-{day:02d}"
                creation_date = pd.to_datetime(creation_date)

            elif '/' in creation_date:
                date_format = "%m/%d/%Y %H:%M:%S"
                creation_date = datetime.strptime(creation_date, date_format)
                creation_date = creation_date.strftime("%Y-%m-%d")
                creation_date = pd.to_datetime(creation_date)

            elif creation_date == '':
                creation_date = 0

            else:
                year = int(creation_date[:4])
                month = int(creation_date[4:6])
                day = int(creation_date[6:8])
                creation_date = f"{year:04d}-{month:02d}-{day:02d}"
                creation_date = pd.to_datetime(creation_date)

        except:
            creation_date = 0

        statement_end_date = data['results']['Account level'][0]['Statement_End_Date'] or 0
        statement_end_date = pd.to_datetime(statement_end_date)

        if creation_date == 0:
            values.append('Document creation date not available')
            flag = 1
            severity = 'MEDIUM'
            insight = 'Document creation date not available'

        elif creation_date >= statement_end_date:
            values.append('Yes')

        else:
            values.append('NO')
            flag = 1
            severity = 'HIGH'
            insight = 'Statement end date is greater than Document creation date'

        reconciliation.append(
            'Document creation date is greater than or equal to statement end date')
        df6 = pd.DataFrame(list(zip(reconciliation, values)),
                           columns=['Reconciliation', 'Values'])
        df66 = pd.DataFrame(
            {'Rule': [rule], 'Flag': flag, 'Severity_Level': severity, 'Insight': insight})
        return df6, df66

    @classmethod
    def reconciliation_main1(cls, pdf_file, json_file_path, final_report_insight, excel_df):

        # data = read_from_data_lake(json_file_path)
        try:
            data = read_from_data_lake(json_file_path)

        except:
            cls.reconciliation_error_list.append("Reconciliation Module: json file not available")
            print('Reconciliation Module-json file not available')            
            data = 0    

        try:
            transaction_len = len(data['results']['Transaction level'])
            if transaction_len == 0:
                final_df = pd.DataFrame({k: [v] for k, v in {
                                        'Reconciliation': 'Error', 'Values': 'Transaction data is not available in json output'}.items()})
                final_df1 = pd.DataFrame({k: [v] for k, v in {
                                         'Rule': '', 'Flag': 'Error', 'Severity_Level': '', 'Insight': 'Transaction data is not available in json File'}.items()})

                final_df2 = final_df1[final_df1['Flag']
                                      == 1][['Insight', 'Severity_Level']]
                final_df2['Module'] = 'Reconciliation'
                final_df2.columns = ['Alerts', 'Severity', 'Module']
                final_df2 = final_df2[['Module', 'Alerts', 'Severity']]
                final_report_insight = pd.concat(
                    [final_report_insight, final_df2])
                excel_df.loc[len(excel_df.index)] = [
                    final_df, '7A.Reconciliation_Raw_Output']
                excel_df.loc[len(excel_df.index)] = [
                    final_df1, '7B.Reconciliation_Report']

                return final_report_insight, excel_df

            else:
                trans_table = pd.DataFrame(
                    data['results']['Transaction level'])
                trans_table = trans_table.fillna(0)
                trans_table['Txnamount'] = trans_table['Txnamount'].astype(
                    'float')
                trans_table['Availablebalance'] = round(
                    trans_table['Availablebalance'].astype('float'), 2)
                trans_table['CREDIT'] = trans_table[['Txnamount']
                                                    ].loc[trans_table['TransactionType'] == 'CREDIT']
                trans_table['DEBIT'] = trans_table[['Txnamount']
                                                   ].loc[trans_table['TransactionType'] == 'DEBIT']
                trans_table = trans_table.fillna(0)

                df1, df11, _ = cls.opening_balance_rule(trans_table, data)
                df2, df22, _ = cls.closing_balance_rule(trans_table, data)
                df3, df33, _ = cls.running_balance_rule(trans_table, data)
                df4, df44 = cls.duplicate_transaction_count_rule(
                    trans_table, data)
                df5, _ = cls.duplicate_transaction_records_rule(
                    trans_table, data)
                df6, df66 = cls.metadata_check_rule(pdf_file, data)
                final_df = pd.concat(
                    [df1, df2, df3, df4, df5, df6], ignore_index=True)
                final_df1 = pd.concat(
                    [df11, df22, df33, df44, df66], ignore_index=True)

                # generate json file for alerts
                final_df2 = final_df1[final_df1['Flag']
                                      == 1][['Insight', 'Severity_Level']]
                final_df2['Module'] = 'Reconciliation'
                final_df2.columns = ['Alerts', 'Severity', 'Module']
                final_df2 = final_df2[['Module', 'Alerts', 'Severity']]
                final_report_insight = pd.concat(
                    [final_report_insight, final_df2])

                excel_df.loc[len(excel_df.index)] = [
                    final_df, '7A.Reconciliation_Raw_Output']
                excel_df.loc[len(excel_df.index)] = [
                    final_df1, '7B.Reconciliation_Report']
                print('Reconciliation output file generated')
                return final_report_insight, excel_df

        except Exception as e:
            print(f"An error occurred: {e}")

    @classmethod
    def reconciliation_entry(cls, input_next_module, json_output_path):
        final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
        excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
        print("json_output_path",json_output_path)
        
        try:
            if not json_output_path:
                cls.reconciliation_error_list.append("Reconciliation Module: json file not available")
                print("Reconciliation Module: json file not available")
                final_df = pd.DataFrame({k: [v] for k, v in {
                                        'Reconciliation': 'Error', 'Values': 'Json file not found'}.items()})
                final_df1 = pd.DataFrame({k: [v] for k, v in {
                                         'Rule': '', 'Flag': 'Error', 'Severity_Level': '', 'Insight': 'Json file not found'}.items()})

                final_df2 = final_df1[final_df1['Flag']
                                      == 1][['Insight', 'Severity_Level']]
                final_df2['Module'] = 'Reconciliation'
                final_df2.columns = ['Alerts', 'Severity', 'Module']
                final_df2 = final_df2[['Module', 'Alerts', 'Severity']]
                final_report_insight = pd.concat([final_report_insight, final_df2])
                excel_df.loc[len(excel_df.index)] = [
                    final_df, '7A.Reconciliation_Raw_Output']
                excel_df.loc[len(excel_df.index)] = [
                    final_df1, '7B.Reconciliation_Report']

    #             final_df = pd.DataFrame(columns = ['Reconciliation', 'Values'])
    #             final_df1 = pd.DataFrame(columns = ['Rule', 'Rule', 'Severity_Level','Insight'])

    #             excel_df.loc[len(excel_df.index)] = [
    #                 final_df, '7A.Reconciliation_Raw_Output']
    #             excel_df.loc[len(excel_df.index)] = [
    #                 final_df1, '7B.Reconciliation_Report']

    #             final_df2 = pd.DataFrame(columns = ['Flag', 'Insight', 'Severity_Level'])
    #             final_df3 = final_df2[final_df2['Flag']== 1][['Insight', 'Severity_Level']] 
    #             final_df3['Module'] = 'Reconciliation'                                   
    #             final_df3 = final_df3.drop_duplicates('Insight', keep='first')
    #             final_df3.columns = ['Alerts','Severity','Module']
    #             final_df3 = final_df3[['Module','Alerts', 'Severity']]                                           
    #             final_report_insight = pd.concat([final_report_insight, final_df3])

    #             print('Reconciliation module - No json found')
                # return final_report_insight, excel_df, cls.reconciliation_error_list
            else:
                final_report_insight, excel_df = cls.reconciliation_main1(
                    input_next_module, json_output_path, final_report_insight, excel_df)
                
        except Exception as e:
            print(f"Error in Reconciliation module: {e}")
            cls.reconciliation_error_list.append(f"Reconciliation: Error {e}")
            final_report_insight = pd.DataFrame(columns=['Module', 'Alerts', 'Severity'])
            final_df = pd.DataFrame(columns=['Reconciliation','Values'])
            final_df1 = pd.DataFrame(columns=['Rule','Flag','Severity_Level','Insight'])
            excel_df.loc[len(excel_df.index)] = [final_df, '7A.Reconciliation_Raw_Output']
            excel_df.loc[len(excel_df.index)] = [final_df1, '7B.Reconciliation_Report']

        
        return final_report_insight, excel_df, cls.reconciliation_error_list


if __name__ == '__main__':
    import os
    input_json_filename = 'core_v2/Bank_Statement_1.json'
    path_intermediate = 'output/Intermediate/'
    os.makedirs(os.path.dirname(path_intermediate), exist_ok=True)
    input_next_module = os.path.join(path_intermediate, "language_output.pdf")

    # input_next_module = os.path.join(
    #     constants.S3_DATA_PREFIX, 'input_data', 'Wells Fargo Tampered Input.pdf')
    # input_json_filename = os.path.join(
    #     constants.S3_DATA_PREFIX, 'input_data', 'Bank_Statement_1.json')

    final_report_insight, excel_df = Reconciliation.reconciliation_entry(
        input_next_module, input_json_filename)
    print(final_report_insight)
    print(excel_df)
