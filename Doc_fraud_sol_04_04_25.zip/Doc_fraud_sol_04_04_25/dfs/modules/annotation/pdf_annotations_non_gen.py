import fitz
import pandas as pd
import os
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake


class Annotation:
    annotation_error_list = []
    @staticmethod
    def draw_box(doc1, df1, page_num1):
        page1 = doc1[page_num1]
        for j in range(len(df1['Bounding_Box'])):
            if df1['Annotation_Type'][j] == 'Ink':
                page1.draw_rect(df1['Bounding_Box'][j],
                                color=(1, 0, 0), width=1)
            if df1['Annotation_Type'][j] == 'FreeText':
                page1.draw_rect(df1['Bounding_Box'][j],
                                color=(1, 0, 0), width=1)
        return doc1

    @classmethod
    def annotations(cls, filename, path_annotations):
        try:
            doc = read_from_data_lake(filename)
        except Exception as e:
            print('Annotations Module failed -- Please make sure a pdf file is uploaded')
            return

        highlight_coords = []
        # reset pdf rotation to zero degree and reset coordinates of pdf to top left corner
        for page in doc:
            page.set_rotation(0)
            page.wrap_contents()
        # Intermediate_path

        doc_temp1 = doc.write()
        doc.close()
        doc = fitz.open(stream=doc_temp1, filetype='pdf')

        df = pd.DataFrame(columns=['Bounding_Box', 'Annotation_Text', 'Background_Text', 'Page_Num',
                          'Annotation_Type', 'Free_Text_Flag', 'Ink_Flag', 'Annotation_Flag', 'Severity_Level', 'Insight'])
        annts_count = 0

        # Check whether there is FreeText or Ink Present on the Pages of the Document.
        for page1 in doc:
            for ann1 in page1.annots():
                if (ann1.type[1] == "FreeText" or ann1.type[1] == "Ink"):
                    annts_count += 1

        # If Annotations Found, delete it and save the file and run hidden text on the new pdf.
        if annts_count > 0:

            for page2 in doc:
                for ann2 in page2.annots():
                    page2.delete_annot(ann2)

            doc_temp = doc.write()
            doc.close()

            doc = fitz.open(stream=doc_temp1, filetype='pdf')
            doc2 = fitz.open(stream=doc_temp, filetype='pdf')

            for page_number, page2 in enumerate(doc):
                if page2.rotation == 0:
                    bbox = []
                    text_in_rect = []
                    page_numb = []
                    annotation_type = []
                    annotation_text = []
                    free_text_flag = []
                    ink_flag = []
                    annotation_flag = []
                    severity_level = []
                    insight = []

                    temp = pd.DataFrame(columns=['Bounding_Box', 'Annotation_Text', 'Background_Text', 'Page_Num',
                                                 'Annotation_Type', 'Free_Text_Flag', 'Ink_Flag', 'Annotation_Flag', 'Severity_Level', 'Insight'])

                    for annotations in page2.annots():
                        if (annotations.type[1] == "FreeText" or annotations.type[1] == "Ink"):
                            rc = annotations.rect
                            if annotations.type[1] == "FreeText":
                                free_text_flag.append(1)
                                insight.append("Free Text added")
                            else:
                                free_text_flag.append(0)

                            if annotations.type[1] == "Ink":
                                ink_flag.append(1)
                                insight.append("Information hidden using Ink")
                            else:
                                ink_flag.append(0)

                            bbox.append(rc)
                            t = doc2[page_number].get_textbox(rc)
                            if len(t) == 0:
                                image_count = 0
                                image_intersect_lap_list = []
                                for images in doc2[page_number]:#.get_image_info():
                                    images_rect = fitz.Rect(images['bbox'])
                                    if rc.intersects(images_rect):
                                        image_count += 1
                                        save_location = path_annotations

                                        image_file_name = f"page_{page_number+1}_{rc}_{image_count}.png"
                                        print('save_location + image_file_name-------------',save_location + image_file_name)
                                        pix = doc2[page_number].get_pixmap(
                                            dpi=images['xres'], clip=rc)
                                        image_bytes = pix.tobytes(output='png')
                                        write_to_data_lake(
                                            image_bytes, save_location + image_file_name)
                                        image_intersect_lap_list.append(
                                            image_file_name)
                                    # else:
                                    #     image_intersect_lap_list = ''

                                text_in_rect.append(image_intersect_lap_list)

                            else:
                                text_in_rect.append(
                                    doc2[page_number].get_textbox(rc))
                            annotation_text.append(annotations.get_text())
                            page_numb.append(page_number+1)
                            annotation_type.append(annotations.type[1])
                            annotation_flag.append(1)
                            severity_level.append("HIGH")

                    temp = pd.DataFrame(data={'Bounding_Box': bbox, 'Annotation_Text': annotation_text, 'Background_Text': text_in_rect, 'Page_Num': page_numb, 'Annotation_Type': annotation_type, 'Free_Text_Flag': free_text_flag, 'Ink_Flag': ink_flag, 'Annotation_Flag': annotation_flag, 'Severity_Level': severity_level,
                                              'Insight': insight})

                    highlight_coords.append((temp, page_number))
                    df = pd.concat([df, temp], axis=0)
                    df.reset_index(inplace=True, drop=True)
            doc2.close()
        else:
            pass
            print('Clean PDF File')
        return doc, df, highlight_coords

    @classmethod
    def highlight_pdf(cls, input_filename, highlight_coords, annotation_output_pdf_path):
        doc = read_from_data_lake(input_filename)
        for page in doc:
            page.set_rotation(0)
            page.wrap_contents()

        doc_temp1 = doc.write()
        doc = fitz.open(stream=doc_temp1, filetype='pdf')

        for t in highlight_coords:
            doc = cls.draw_box(doc, t[0], t[1])

        pdf_bytes = doc.write()
        write_to_data_lake(pdf_bytes, annotation_output_pdf_path)

    @classmethod
    def annotations_entry(cls, input_next_module, path_annotations):

        final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
        excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
        try:
            a1 = cls.annotations(input_next_module, path_annotations)
            if not (a1 is None):

                # Get the DataFrame having the highlighting details.
                df1 = a1[1]
                df1['Module'] = 'Annotation'
                df1 = df1.drop(['Bounding_Box'], axis=1)

                dfA = df1[['Annotation_Text', 'Background_Text',
                           'Page_Num', 'Annotation_Type']]
                dfB = df1[['Annotation_Flag', 'Free_Text_Flag',
                           'Ink_Flag', 'Severity_Level', 'Insight']]
 
                # generate json file for alerts
                df2 = df1[df1['Annotation_Flag'] == 1][[
                    'Module', 'Insight', 'Severity_Level']]
                df2.columns = ['Module', 'Alerts', 'Severity']
                df2.drop_duplicates(keep='first', inplace=True)
                final_report_insight = pd.concat([final_report_insight, df2])
                final_report_insight.reset_index(inplace=True, drop=True)

                excel_df.loc[len(excel_df.index)] = [dfA, '4A.Annotation_Raw_Output']
                excel_df.loc[len(excel_df.index)] = [dfB, '4B.Annotation_Report']
        
        except Exception as e:
            print(f"Error in Annotation module: {e}")
            cls.annotation_error_list.append(f"Annotation: Error {e}")
            final_report_insight = pd.DataFrame(columns=['Module', 'Alerts', 'Severity'])
            dfA = pd.DataFrame(columns=['Annotation_Text', 'Background_Text', 'Page_Num', 'Annotation_Type'])
            dfB = pd.DataFrame(columns=['Annotation_Flag', 'Free_Text_Flag', 'Ink_Flag', 'Severity_Level', 'Insight'])
            excel_df.loc[len(excel_df.index)] = [dfA, '3A.Annotation_Raw_Output']
            excel_df.loc[len(excel_df.index)] = [dfB, '3B.Annotation_Report']
            a1 = ['','',[]]

        return final_report_insight, excel_df, a1[2], cls.annotation_error_list


if __name__ == '__main__':
    import os
    # path_annotations = 'output/Images/Annotations/'
    # path_intermediate = 'output/Intermediate/'

    os.makedirs(os.path.dirname(path_annotations), exist_ok=True)
    os.makedirs(os.path.dirname(path_intermediate), exist_ok=True)

    input_next_module = os.path.join(path_intermediate, "font_output.pdf")
    annotation_output_pdf_path = os.path.join(
        path_intermediate, "annotation_output.pdf")
    pdf_filename_file = "wells fargo input.pdf"

    # input_next_module = os.path.join(
    #     constants.S3_DATA_PREFIX, 'input_data', 'Wells Fargo Tampered Input.pdf')
    # annotation_output_pdf_path = os.path.join(
    #     constants.S3_DATA_PREFIX, path_intermediate, "annotation_output.pdf")
    # path_annotations = os.path.join(
    #     constants.S3_DATA_PREFIX, "output", "Images", "Annotations")

    bank_names = ['wells fargo']
    final_report_insight, excel_df, highlight_coords, annotation_error_list = Annotation.annotations_entry(
        input_next_module, path_annotations)
    Annotation.highlight_pdf(
        input_next_module, highlight_coords, annotation_output_pdf_path)
    print(final_report_insight)
    print(excel_df)
