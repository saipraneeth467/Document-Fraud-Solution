import fitz
import pandas as pd
import os
import warnings
from PyPDF2 import PdfReader, PdfWriter

warnings.filterwarnings('ignore')


class Annotation:
    annotation_error_list = []
    @classmethod
    def return_final_report(cls, df, final_report_insight):
        df1 = df
        df1['Module'] = 'Annotation'
        df1 = df1.drop(['Bounding_Box'], axis=1)

        df_a = df1[['Annotation_Text', 'Background_Text',
                    'Page_Num', 'Annotation_Type']]
        df_b = df1[['Annotation_Flag', 'Free_Text_Flag',
                    'Ink_Flag', 'Severity_Level', 'Insight']]

        df2 = df1[df1['Annotation_Flag'] == 1][[
            'Module', 'Insight', 'Severity_Level']]
        df2.columns = ['Module', 'Alerts', 'Severity']
        df2.drop_duplicates(keep='first', inplace=True)

        final_report_insight = pd.concat([final_report_insight, df2])
        final_report_insight.reset_index(inplace=True, drop=True)

        return df_a, df_b, final_report_insight, cls.annotation_error_list

    @classmethod
    def draw_pdf(cls, input_file_path, pdf_highlighting_coordinates, annotations_output_pdf_path):
        doc = fitz.open(input_file_path)
        for page in doc:
            page.set_rotation(0)
            page.wrap_contents()

        for temp, page_number in pdf_highlighting_coordinates:
            doc = cls.draw_box(doc, temp, page_number)

        if doc is not None:
            doc.save(annotations_output_pdf_path)

    @classmethod
    def write_to_excel(cls, df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname,index=False)

    @classmethod
    def annotations(cls, input_file_path, image_annotations_dir):
        try:
            doc = fitz.open(input_file_path)
            doc2 = fitz.open(input_file_path)

        except Exception as e:
            print('Annotations Module failed -- Please make sure a pdf file is uploaded')
            return

        # reset pdf rotation to zero degree and reset coordinates of pdf to top left corner
        for page in doc:
            page.set_rotation(0)
            page.wrap_contents()

        df = pd.DataFrame(columns=['Bounding_Box', 'Annotation_Text', 'Background_Text', 'Page_Num',
                                   'Annotation_Type', 'Free_Text_Flag', 'Ink_Flag',
                                   'Annotation_Flag', 'Severity_Level', 'Insight'])

        annotations_count = 0
        for page1 in doc:
            for ann1 in page1.annots():
                if ann1.type[1] in ["FreeText", "Ink"]:
                    annotations_count += 1

        pdf_highlighting_coordinates = []

        if annotations_count > 0:
            for page2 in doc2:
                for ann2 in page2.annots():
                    page2.delete_annot(ann2)

            for page_number, page2 in enumerate(doc):
                if page2.rotation == 0:
                    b_box = []
                    text_in_rect = []
                    page2_number = []
                    annotation_type = []
                    annotation_text = []
                    free_text_flag = []
                    ink_flag = []
                    annotation_flag = []
                    severity_level = []
                    insight = []

                    for annotations in page2.annots():
                        if annotations.type[1] in ["FreeText", "Ink"]:
                            rc = annotations.rect

                            if annotations.type[1] == "FreeText":
                                free_text_flag.append(1)
                                insight.append("Free Text added")
                            else:
                                free_text_flag.append(0)

                            if annotations.type[1] == "Ink":
                                ink_flag.append(1)
                                insight.append("Information hidden using Ink")
                            else:
                                ink_flag.append(0)

                            b_box.append(rc)
                            t = doc2[page_number].get_textbox(rc)
                            if len(t) == 0:
                                image_count = 0
                                image_intersect_lap_list = []
                                for images in doc2[page_number].get_image_info():
                                    images_rect = fitz.Rect(images['b_box'])

                                    if rc.intersects(images_rect):
                                        image_count += 1
                                        image_file_name = f"page_{page_number + 1}_{rc}_{image_count}.png"

                                        pix = doc2[page_number].get_pixmap(
                                            dpi=images['xres'], clip=rc)
                                        pix.save(os.path.join(
                                            image_annotations_dir, image_file_name))
                                        image_intersect_lap_list.append(
                                            image_file_name)

                                text_in_rect.append(image_intersect_lap_list)
                            else:
                                text_in_rect.append(
                                    doc2[page_number].get_textbox(rc))
                            annotation_text.append(annotations.get_text())
                            page2_number.append(page_number + 1)
                            annotation_type.append(annotations.type[1])
                            annotation_flag.append(1)
                            severity_level.append("HIGH")

                    temp = pd.DataFrame(data={'Bounding_Box': b_box, 'Annotation_Text': annotation_text,
                                              'Background_Text': text_in_rect, 'Page_Num': page2_number,
                                              'Annotation_Type': annotation_type, 'Free_Text_Flag': free_text_flag,
                                              'Ink_Flag': ink_flag, 'Annotation_Flag': annotation_flag,
                                              'Severity_Level': severity_level, 'Insight': insight})
                    pdf_highlighting_coordinates.append((temp, page_number))
                    df = pd.concat([df, temp], axis=0)
                    df.reset_index(inplace=True, drop=True)

        return pdf_highlighting_coordinates, df

    @classmethod
    def annotation_main(cls, input_file_path, image_annotations_dir):
        pdf_highlighting_coordinates, df = cls.annotations(
            input_file_path, image_annotations_dir)
        return pdf_highlighting_coordinates, df

    @staticmethod
    def draw_box(doc1, df1, page_num1):
        page1 = doc1[page_num1]
        for j in range(len(df1['Bounding_Box'])):
            if df1['Annotation_Type'][j] in ["Ink", "FreeText"]:
                page1.draw_rect(df1['Bounding_Box'][j],
                                color=(1, 0, 0), width=1)
        return doc1


if __name__ == '__main__':
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
    fraud_report_file_path = 'test/report.xlsx'
    annotations_output_pdf_path = "test/pdf_files/annotations_output.pdf"
    image_annotations_dir = 'test/images/annotations'
    pdf_highlighting_coordinates, df = Annotation.annotation_main(
        input_next_module, annotations_output_pdf_path, image_annotations_dir, fraud_report_file_path)

    Annotation.draw_pdf(input_next_module, pdf_highlighting_coordinates,
                        annotations_output_pdf_path)

    df_a, df_b, final_report_insight = Annotation.return_final_report(
        df, final_report_insight)

    mode = 'a'
    if not os.path.exists(fraud_report_file_path):
        mode = 'w'

    Annotation.write_to_excel(df_a, fraud_report_file_path,
                              mode, '4A.Annotation_Raw_Output')
    Annotation.write_to_excel(df_b, fraud_report_file_path,
                              'a', '4B.Annotation_Report')
