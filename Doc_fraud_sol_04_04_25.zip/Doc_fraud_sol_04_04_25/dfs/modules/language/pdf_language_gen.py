import warnings
import re
import pandas as pd
import io
import time
from collections import defaultdict
import os
import numpy as np
from pdf2image import convert_from_bytes
import cv2
import pdfplumber
from transformers import AutoImageProcessor, TableTransformerForObjectDetection
import torch
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PyPDF2 import PdfReader
from dfs.commons import constants
import fitz
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage

import language_tool_python
import PyPDF2
from tabula import read_pdf
from langchain import HuggingFaceHub

warnings.filterwarnings('ignore')
os.environ["HUGGINGFACEHUB_API_TOKEN"] = constants.HUGGINGFACEHUB_API_TOKEN
huggingfacehub_api_token = constants.HUGGINGFACEHUB_API_TOKEN
repo_id = "meta-llama/Llama-2-13b-chat-hf"
falcon_llm = HuggingFaceHub(
    repo_id=repo_id, model_kwargs={"temperature": 0.1, "max_new_tokens": 1000})

l0 = list(['Nyc'])
l1 = list(['claro'])
l2 = list(['Account'])
l3 = list([])

prompt = """ Context: Play a role of foreign language(apart from english language) identifier  agent.
Step1: From below list of comma separated words identify the foreign language words.
Step3: If a word is from other language than english then it should not be tagged as spelling mistakes.
Input:{list0}
Output:
Input:{list1}
Output: claro
Input: {list2}
Output:
Input: {list3}
Output: """.format(list0=l1, list1=l1, list2=l2, list3=l3)


class LanguageModel:
    language_error_list = []
    @staticmethod
    def pdf_to_image(pdf_path, page_number, dpi=300):
        images = convert_from_bytes(open(pdf_path, 'rb').read(), dpi=dpi)
        if 1 <= page_number <= len(images):
            cv_image = np.array(images[page_number - 1])
        return cv_image

    @classmethod
    def table_extraction(cls, pdf_path, image_output_dir):
        start_time = time.time()
        # no of pages in pdf
        reader = PdfReader(pdf_path)
        num_pages = len(reader.pages)

        table_df_list = []
        a1 = []
        p1 = []

        for page_number in range(1, num_pages + 1):

            selected_image = cls.pdf_to_image(pdf_path, page_number)

            if selected_image is not None:
                output_file_path = f"{image_output_dir}/page_{page_number}.png"
                cv2.imwrite(output_file_path, selected_image)

        # Get dimensions of the output image
                height_image, width_image, _ = selected_image.shape

            image_path = output_file_path
            image = Image.open(image_path).convert("RGB")

            image_processor = AutoImageProcessor.from_pretrained(
                "microsoft/table-transformer-detection")
            model = TableTransformerForObjectDetection.from_pretrained(
                "microsoft/table-transformer-detection")

            inputs = image_processor(images=image, return_tensors="pt")
            outputs = model(**inputs)

            target_sizes = torch.tensor([image.size[::-1]])
            results = image_processor.post_process_object_detection(
                outputs, threshold=0.9, target_sizes=target_sizes)[0]

            fig, ax = plt.subplots(1)
            ax.imshow(image)

            coordinates_list_j = []
            j = 0
            for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
                box = [round(i, 2) for i in box.tolist()]
                coordinates_list_j.append(box)
                j += 1
                class_name = model.config.id2label[label.item()]
                confidence = round(score.item(), 3)

                rect = patches.Rectangle(
                    (box[0], box[1]), box[2] - box[0], box[3] - box[1], linewidth=1, edgecolor="r", facecolor="none")
                ax.add_patch(rect)
                ax.text(box[0], box[1], f"{class_name}: {confidence}",
                        color="white", verticalalignment="top")

            plt.axis("off")

            coordinates_list = []
            i = 0
            for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
                box = [round(i, 2) for i in box.tolist()]
                coordinates_list.append(box)
                i += 1

            reader = PdfReader(pdf_path)
            page_number2 = page_number - 1
            page = reader.pages[page_number2]

            upper_right = page.cropbox.upper_right

            width_pdf = float(upper_right[0])
            height_pdf = float(upper_right[1])

            width_conversion_factor = float(round((width_image/width_pdf), 3))
            height_conversion_factor = float(
                round((height_image/height_pdf), 3))

            for table_no in range(0, len(coordinates_list)):
                uplx_no = coordinates_list[table_no][0]/width_conversion_factor
                uply_no = coordinates_list[table_no][1] / \
                    height_conversion_factor
                upper_left_x = uplx_no - 25
                upper_left_y = float(height_pdf) - float(uply_no) + 30
                lower_right_x = float(
                    coordinates_list[table_no][2]/width_conversion_factor) + 25
                lower_right_y = float(
                    height_pdf) - float(coordinates_list[table_no][3]/height_conversion_factor) - 30
                area = [height_pdf - upper_left_y, upper_left_x,
                        height_pdf - lower_right_y, lower_right_x]
                a1.append(area)
                p1.append(page_number)
                table_tabula2 = read_pdf(
                    pdf_path, multiple_tables=False, pages=page_number, stream=True, area=area, silent=True)
                df = table_tabula2[0]
                table_df_list.append(df)

                with pdfplumber.open(pdf_path) as pdf:

                    page = pdf.pages[page_number2]
                    try:
                        bounding_box = (upper_left_x, height_pdf - upper_left_y,
                                        lower_right_x, height_pdf - lower_right_y)
                        crop_area = page.crop(bounding_box)
                        crop_text = crop_area.extract_text().split("\n")
                    except:
                        pass

        return table_df_list, a1, p1

    @staticmethod
    def rem_sp_char(a):
        pattern = r'[^a-zA-Z0-9]'
        return re.sub(pattern, '', a)

    @staticmethod
    def rem_sp_char_space(a):
        pattern = r'[^a-zA-Z0-9]'
        return re.sub(pattern, ' ', a)
    
    # @staticmethod
    # def remove_accents(input_str):            
    # nfkd_form = unicodedata.normalize('NFKD', input_str)
    # only_ascii = nfkd_form.encode('ASCII', 'ignore')
    # return str(only_ascii)
    #[â,î,ô,ü,ï,é,è]  âir air

    @classmethod
    def get_table_words(cls, filepath, image_output_dir):
        # df = read_pdf(filepath,pages="all")
        df, a1, p1 = cls.table_extraction(filepath, image_output_dir)
        word_list = []
        for i in range(len(df)):
            cl = list(df[i].columns)
            for j in range(len(cl)):
                for k in range(len(df[i][cl[j]])):
                    if type(df[i][cl[j]].iloc[k]) == str:
                        df[i][cl[j]].iloc[k] = cls.rem_sp_char_space(
                            df[i][cl[j]].iloc[k])
                        for t in df[i][cl[j]].iloc[k].split():
                            if t not in word_list:
                                word_list.append(cls.rem_sp_char(t).lower())
        return word_list, a1, p1

    @staticmethod
    def highlight(file_path, bbox, page_num, label, language_output_pdf_path):
        # Page_num: list of page numbers
        # doc: original doc when page_num = 1 else updated doc
        # bbox: list of all bboxs
        # lable: one integer to identify the module
        l = label
        i = 0
        doc = fitz.open(file_path)
        for page in doc:
            i += 1
            for j in range(len(page_num)):
                if i == page_num[j]:
                    if l == 1:  # font module
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()
                    elif l == 2:  # language module
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.set_colors(stroke=(0, 1, 0))
                        highlight.update()
                    elif l == 3:  # annotation module
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()
                    elif l == 4:  # overlay module
                        highlight = page.add_highlight_annot(bbox[j])
                        highlight.update()

        doc.save(language_output_pdf_path)
        return doc

    @staticmethod
    def convert(fname, pages=None):
        if not pages:
            pagenums = set()
        else:
            pagenums = set(pages)

        output = io.StringIO()
        manager = PDFResourceManager()
        converter = TextConverter(manager, output, laparams=LAParams())
        interpreter = PDFPageInterpreter(manager, converter)
        infile = open(fname, 'rb')
        for page in PDFPage.get_pages(infile, pagenums):
            interpreter.process_page(page)
        infile.close()
        converter.close()
        text = output.getvalue()
        output.close
        return text
    
    @staticmethod
    def find_double_spaces(text,page):
        pattern = r'\w\s{2,}[^\n\w+]\w'    #result  (w)-last_char spaces++ 1st_char(w)
        matches = re.findall(pattern,text)
        matches = [word for word in matches if '\n' not in word]   
        bbox = []
        for wrd1 in matches:
            et1 = page.search_for(wrd1.strip())
            if et1:
                if len(et1)>1:
                    max_xc = 0
                    max_box = 0
                    for box in et1:
                        xc = box[2] - box[0]
                        if xc>max_xc:
                            max_xc = xc
                            max_box = box
                    bbox.append(max_box)
                else:
                    bbox.append(et1)
        return matches,bbox
                        
    @staticmethod
    def cleantext(text):
        pattern = r'\b\w{1,2}\b'
        cleaned_text = re.sub(r'\W+', ' ', text) #remove non word char(punct and spaces).
        cleaned_text = re.sub(r'\d+', ' ', cleaned_text) #remove one or more consecutive digits.
        # cleaned_text = re.sub(r'\b[A-Z]+\b', '', cleaned_text) #remove word which entirely consist of uppercase letters.
        cleaned_text = re.sub(pattern, ' ', cleaned_text) #remove words consist of one or two char.
        # cleaned_text = re.sub(r'\b(\w)\1+\b', ' ', cleaned_text) #remove word which entirely consist of same char.
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)  #remove all consecutive whitespace.
        return cleaned_text
    
    @classmethod
    def extract_text(cls,page_1):
        text2 = page_1.get_text()
        text1 = cls.cleantext(text2)
        words = text1.split()
        unique_words = set(words)
        text = ' '.join(unique_words)
        matches,bbox = cls.find_double_spaces(text2,page_1)    
        return text,matches,bbox

    @classmethod
    def spelling_module(cls, file_path, image_output_dir):
        tool = language_tool_python.LanguageTool('en-US')
        reader = PyPDF2.PdfReader(file_path)
        doc = fitz.open(file_path)

        word = []
        word1 = []
        replacement = defaultdict(lambda: 0)
        word = []
        flag = []
        replacement1 = []
        bbox = []
        page_num = []
        r1 = []
        w1 = []
        pg = []
        pg1 = []
        table_cords = defaultdict(lambda: [])
        _, a1, p1 = cls.get_table_words(file_path, image_output_dir)

        for v in range(len(p1)):
            table_cords[p1[v]].append(a1[v])

        for i in range(len(reader.pages)):
            
            page = doc[i]
            text,space_word,space_bbox = cls.extract_text(page)
            bbox = bbox + space_bbox
            matches = tool.check(text)

            pp = text.split()
            for k in range(len(pp)):
                word.append(pp[k].strip())
                pg1.append(i+1)
            table_c = table_cords[i+1]

            for j in range(len(matches)):
                if matches[j].message != 'Possible typo: you repeated a whitespace':

                    off = matches[j].offset
                    length = matches[j].errorLength
                    wr = text[off:off+length+1]

                    if wr.isspace() != True:
                        if matches[j].message == 'Possible spelling mistake found.':
                            if wr != 'Enespañd:':
                                wrr = cls.rem_sp_char_space(wr)
                                wrr = wrr.split()
                                z = -1
                                
                                ET = page.search_for(wr)

                                et = page.search_for(wrr[0])
                                
                                for tc in table_c:
                                    for c in et:
                                        if (c[0] >= tc[1] and c[0] <= tc[3]) and (c[2] >= tc[1] and c[2] <= tc[3]) and (c[1] >= tc[0] and c[1] <= tc[2]) and (c[3] >= tc[0] and c[3] <= tc[2]):
                                            z = 1
                                if z != 1:
                                    l3 = list([cls.rem_sp_char(wr).lower()])
                                    # print('l3..........',l3)
                                    try:
                                        ans = falcon_llm(prompt)
                                    except:
                                        ans = ''
                                    ans_s = ans.split('\n')
                                    if ans_s[0] == '':
                                        z = 0
                                    else:
                                        pass
                                if z == 0 :
                                    
                                    r1.append(matches[j].replacements)
                                    w1.append(cls.rem_sp_char(wr))
                                    pg.append(i+1)
                                    replacement[cls.rem_sp_char(
                                        wr)] = matches[j].replacements
                                    word1.append(cls.rem_sp_char(wr))
                                    bbox.append(et)
                                    if i == 3:
                                        pass
                                    page_num.append(i+1)
                                
                            
        insights = []
        sr = []
        t = 0
        # for k in range(len(word)):
        #     t1 = cls.rem_sp_char(word[k])
        #     if t1 not in word1:
        #         flag.append(0)
        #         replacement1.append('')
        #         insights.append('')
        #         sr.append('')
        #     else:
        #         flag.append(1)
        #         replacement1.append(replacement[t1])
        #         insights.append('Spelling Mistake found')
        #         sr.append('HIGH')
        #         t = 1
                
        for k in range(len(w1)):
            t1 = cls.rem_sp_char(w1[k])
            flag.append(1)
            replacement1.append(replacement[t1])
            insights.append('Spelling Mistake found')
            #sr.append('HIGH')
            sr.append('LOW')
            t = 1
            
        if t == 1:        
            df_json = pd.DataFrame(
                {"Alerts": ["Spelling Mistake Detected"], "Severity": ["HIGH"]})
        else:
            df_json = pd.DataFrame()
            # final_report_insight = pd.concat([final_report_insight, df_json], ignore_index=True)

        file_path1 = file_path.split('.')[0]

        mydf1 = pd.DataFrame(list(zip(w1, flag, sr, insights, pg1)), columns=[
                             'Word', 'Flag', 'Severity_Level', 'Insight', 'Page_Num'])
        mydf2 = pd.DataFrame(list(zip(w1, r1, pg)), columns=[
                             'Word', 'Replacement', 'Page_Num'])
        return df_json, bbox, page_num, mydf1, mydf2, cls.language_error_list

    @classmethod
    def write_to_excel(cls, df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname,index=False)


if __name__ == "__main__":
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    fraud_report_file_path = os.path.join(
        "test", 'excel_files', "fraud_report_file_path.xlsx")
    language_output_pdf_path = os.path.join(
        "test", "pdf_files", "language_output.pdf")
    image_output_dir = os.path.join("test", "images", "language")

    os.makedirs(os.path.dirname(fraud_report_file_path), exist_ok=True)
    os.makedirs(os.path.dirname(language_output_pdf_path), exist_ok=True)
    os.makedirs(image_output_dir, exist_ok=True)

    final_report_insight, bbox, page_num, mydf1, mydf2 = LanguageModel.spelling_module(
        input_next_module, image_output_dir)
    LanguageModel.highlight(input_next_module, bbox,
                            page_num, 2, language_output_pdf_path)

    mode = 'a'
    if not os.path.exists(fraud_report_file_path):
        mode = 'w'

    LanguageModel.write_to_excel(
        mydf2, fraud_report_file_path, mode, '6A.Language_Raw_Output')
    LanguageModel.write_to_excel(
        mydf1, fraud_report_file_path, mode, '6B.Language_Report')
