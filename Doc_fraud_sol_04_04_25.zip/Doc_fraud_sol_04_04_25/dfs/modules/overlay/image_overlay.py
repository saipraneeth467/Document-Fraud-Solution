import os
import io
import re
import cv2 
import math
import time
import tempfile
import imagehash
import statistics
import pytesseract
import numpy as np
import pandas as pd
import multiprocessing
from PIL import ImageDraw
from gliner import GLiNER
import matplotlib.pyplot as plt
from dfs.commons import constants
from doctr.io import DocumentFile
from doctr.models import ocr_predictor
from PIL import Image, ImageChops, ImageEnhance

from sklearn.metrics.pairwise import cosine_similarity
from scipy.stats import kurtosis, skew
from skimage.feature import local_binary_pattern

from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake, list_dir_files

model = ocr_predictor(det_arch = 'db_resnet50',reco_arch = 'crnn_vgg16_bn', pretrained = True)

class Overlay:
    overlay_error_list = []
    
    @staticmethod
    def copymove(image_path, overlay_output_image_path):
        
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        custom_config = r'--oem 3 --psm 6'
        
        if constants.IS_S3_PATH:
            raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
        else:
            raw_image_data = read_from_data_lake(image_path, reader='cv2')
        
        # Loading and reading the image
        nparr = np.frombuffer(raw_image_data, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Generating the PRNU of the image using Denoising techniques
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        denoised_image = cv2.fastNlMeansDenoising(gray_image, None, h=10, templateWindowSize=3, searchWindowSize=5)
        prnu = gray_image - denoised_image 
        prnu_path = os.path.join(overlay_output_image_path, "PRNU_image")
        
        if not constants.IS_S3_PATH:
            os.makedirs(prnu_path, exist_ok=True)
        
        #Saving the PRNU image
        prnu_path = os.path.join(prnu_path, f"{image_name}_prnu_img.png")
        _, buffer = cv2.imencode('.png', prnu)
        bytes_data = buffer.tobytes()
        write_to_data_lake(bytes_data, prnu_path)

        #IMAGE COORDINATES AND EXTRACTION
        image = read_from_data_lake(image_path)
        result = pytesseract.image_to_boxes(image, lang='eng', config=custom_config)
        letter_coordinates = []

        for line in result.splitlines():
            data = line.split()
            if len(data) == 6: 
                letter, x1, y1, x2, y2, _ = data
                letter_coordinates.append({
                    'letter': letter,
                    'x1': int(x1)-1,
                    'y1': image.size[1] - int(y2)-3, 
                    'x2': int(x2)+1,
                    'y2': image.size[1] - int(y1)+3
                })

        image_info_dict = {}
        
        #Reading the prnu image
        prnu_image = read_from_data_lake(prnu_path)

        # Using pytesseract coordinates of each letter to get cropped images from org and prnu image
        for idx, letter_info in enumerate(letter_coordinates):
            letter = letter_info['letter']
            coordinates = (
                letter_info['x1'],
                letter_info['y1'],
                letter_info['x2'],
                letter_info['y2']
            )
            cropped_image_prnu = prnu_image.crop(coordinates)

            cropped_image_og = image.crop(coordinates)

            image_info_dict[f'image_{idx}'] = {
            'letter': letter,
            'coordinates': coordinates,
            'prnu_img':cropped_image_prnu,
            'org_img': cropped_image_og
        }

        # Getting hash value and dimensions of each cropped part in prnu image
        for i in image_info_dict:
            image = image_info_dict[i]['prnu_img']
            # image = read_from_data_lake(file_path)
            hash_value = imagehash.average_hash(image)
            image_info_dict[i]['hash'] = hash_value
            image_info_dict[i]['dimensions'] = image.size

        # Threshold for saying if 2 letters are copy moved based on hash value similarity of noise pattern in prnu
        threshold = 0.9
        similar_images = []
        for i, (image1, info1) in enumerate(image_info_dict.items()):
            for image2, info2 in list(image_info_dict.items())[i + 1:]:
                dimensions1 = info1['dimensions']
                dimensions2 = info2['dimensions']
                hash1 = info1['hash']
                hash2 = info2['hash']
                letter1 = info1['letter'].lower()
                letter2 = info2['letter'].lower()
                if dimensions1 == dimensions2 and letter1 == letter2:
                    similarity = 1 - (hash1 - hash2) / 64
                    if similarity > threshold:
                        # print(f"Letter 1: {letter1} | Letter 2: {letter2} | similarity: {similarity}")
                        similar_images.append((image1,image2,letter1,letter2, similarity))

        # BOUNDING BOX AND FALSE POSITIVE REMOVAL
        base_image = read_from_data_lake(image_path)
        draw = ImageDraw.Draw(base_image)
        copymove_coordinates = []
        copymove_results = []
        # print(similar_images)
        for image_1_name, image_2_name,letter1,letter2, similarity in similar_images:

            text_1 = letter1
            text_2 = letter2
            text_1_cleaned = ''.join(filter(lambda x: x.isalnum(), text_1))
            text_2_cleaned = ''.join(filter(lambda x: x.isalnum(), text_2))
            if set(text_1_cleaned).intersection(set(text_2_cleaned)):
                result = True
            else:
                result = False
            
            coordinates_1 = None
            coordinates_2 = None
            if result:
            #  print(f"Similar images: {file_name_1} and {file_name_2}, Similarity: {similarity}")
                if image_1_name in image_info_dict:
                    info_1 = image_info_dict[image_1_name]
                    coordinates_1 = info_1['coordinates']
                    copymove_coordinates.append(coordinates_1)
                    draw.rectangle(coordinates_1, outline="red", width=2) 
        
                if image_2_name in image_info_dict:
                    info_2 = image_info_dict[image_2_name]
                    coordinates_2 = info_2['coordinates']
                    copymove_coordinates.append(coordinates_2)
                    draw.rectangle(coordinates_2, outline="red", width=2)  
                
                copymove_results.append({
                    'image_1': image_1_name,
                    'image_2':image_2_name,
                    'word_1': text_1_cleaned,
                    'word_2': text_2_cleaned,
                    'coordinates_1' : coordinates_1,
                    'coordinates_2': coordinates_2
                })
                    
        # Defining the output file path 
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_folder = os.path.join(overlay_output_image_path, "Extracted Sections", "Output")
        
        if not constants.IS_S3_PATH:
            os.makedirs(output_folder, exist_ok=True)
        
        output_file_name = f"{base_name}_with_boxes.png"
        base_image_with_boxes_path = os.path.join(output_folder, output_file_name)

        image_bytes = io.BytesIO()

        base_image.save(image_bytes, format='PNG')
        image_bytes.seek(0)
        write_to_data_lake(image_bytes.getvalue(), base_image_with_boxes_path)
        
        # print(copymove_results)
        return copymove_results, copymove_coordinates
    
    @staticmethod
    def new_text_detection_using_noise_pattern(image_path, overlay_output_image_path):
        
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        
        # FUNCTION TO CREATE BITPLANE 7 IMAGE
        def generate_bitplanes(image_path, bitplane_images_folder):
            if constants.IS_S3_PATH:
                raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
            else:    
                raw_image_data = read_from_data_lake(image_path, reader='cv2')
            nparr = np.frombuffer(raw_image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
            # image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            
            for i in range(7,8):
                bitplane = (image >> i) & 1
                bitplane = bitplane*255
                bitplane = cv2.cvtColor(bitplane, cv2.COLOR_BGR2RGB)
                
                bitplane_image_path = f"{bitplane_images_folder}/{image_name}_bitplane_{i}.png"
                bitplane_buffer = io.BytesIO()
                plt.imsave(bitplane_buffer, bitplane, format='png')
                bitplane_buffer.seek(0)
                bytes_data = bitplane_buffer.getvalue()
                write_to_data_lake(bytes_data, bitplane_image_path)

        # bitplane_start = time.time()
        bitplane_images_folder = os.path.join(overlay_output_image_path, "bitplanes")
        
        if not constants.IS_S3_PATH:
            os.makedirs(bitplane_images_folder, exist_ok=True)
        
        generate_bitplanes(image_path, bitplane_images_folder)
        # print("Bit plane generation Time: ", time.time() - bitplane_start)

        # Checking file extension
        def png_jpg_check(image_path):
            # Get the file extension
            file_extension = os.path.splitext(image_path)[1].lower()
            # Determine the image format based on the file extension
            if file_extension == '.png' or '.jpg' or '.jpeg':
                return True
            else:
                return False

        # EXTRACTING DOCTR COORDINATES
        def doctr_extraction(img):
            
            img1 = read_from_data_lake(img)
            with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(img)[-1]) as temp_file:
                img1.save(temp_file, format=img1.format)
                temp_file_path = temp_file.name   
                
            doc = DocumentFile.from_images(temp_file_path)
            result = model(doc)
            output = result.export()

            def convert_coordinates(geometry, page_dim):
                len_x = page_dim[1]
                len_y = page_dim[0]
                (x_min, y_min) = geometry[0]
                (x_max, y_max) = geometry[1]
                x_min = math.floor(x_min * len_x)
                x_max = math.ceil(x_max * len_x)
                y_min = math.floor(y_min * len_y)
                y_max = math.ceil(y_max * len_y)
                return [x_min, y_min, x_max,y_max]
            def get_coordinates(output):
                page_dim = output['pages'][0]["dimensions"]
                text_coordinates = []
                for obj1 in output['pages'][0]["blocks"]:
                    for obj2 in obj1["lines"]:
                        for obj3 in obj2["words"]:                
                            converted_coordinates = convert_coordinates(obj3["geometry"],page_dim)

                            if len(obj3["value"])>1:
                                text_coordinates.append([converted_coordinates,obj3["value"]])
                            if len(obj3["value"])==1 and obj3["value"].isalnum():
                                text_coordinates.append([converted_coordinates,obj3["value"]])
                return text_coordinates

            coordinates = get_coordinates(output)
            return coordinates

        # doctr_start = time.time()
        doctr_coordinates = doctr_extraction(image_path)
        # print("Time Taken for Doctr Extraction: ", time.time() - doctr_start)
        
        #Getting color for each word in the image
        def text_color_compare(doctr_coordinates, image_path):
            if constants.IS_S3_PATH:
                raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
            else:    
                raw_image_data = read_from_data_lake(image_path, reader='cv2')
            nparr = np.frombuffer(raw_image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            word_colors = []
            updated_coordinates = []
            all_word_pixels = []

            for i in doctr_coordinates:
                word_img = image[i[0][1]:i[0][3], i[0][0]:i[0][2]]
                # Flatten the region to get the pixel values of the word

                mask = (word_img <230).any(axis=2)
                final_pixels = word_img[mask]

                # Extend all_word_pixels with final_pixels directly as a list
                all_word_pixels.extend(final_pixels)

                if final_pixels.size > 0:
                    # Calculate the average color of final_pixels in a single operation
                    word_avg_color = final_pixels.mean(axis=0)

                    # Compute color differences in one step using np.abs
                    bg_diff, gr_diff, rb_diff = np.abs([
                        word_avg_color[0] - word_avg_color[1],
                        word_avg_color[2] - word_avg_color[1],
                        word_avg_color[0] - word_avg_color[2]
                    ])

                    # Append the rounded differences to word_colors
                    word_colors.append(np.round([bg_diff, gr_diff, rb_diff], 2).tolist())
                # updated_coordinates.append([i[0], i[1], word_avg_color])

            all_word_avg_color = [round(i,2) for i in np.average(all_word_pixels, axis=0)]
            all_word_bg_diff_mode = statistics.mode([round(i[0],-1) for i in word_colors])
            all_word_gr_diff_mode = statistics.mode([round(i[1],-1) for i in word_colors])
            all_word_rb_diff_mode = statistics.mode([round(i[2],-1) for i in word_colors])
            # print("all word avg rgb diff: ",all_word_bg_diff_mode, all_word_gr_diff_mode, all_word_rb_diff_mode)

            word_colors_np = np.array(word_colors)

            # Calculate the absolute differences between the mode values and each color difference in word_colors_np
            bg_diffs = np.abs(all_word_bg_diff_mode - word_colors_np[:, 0])
            gr_diffs = np.abs(all_word_gr_diff_mode - word_colors_np[:, 1])
            rb_diffs = np.abs(all_word_rb_diff_mode - word_colors_np[:, 2])

            # Determine which words have significant color differences
            color_diffs = ((bg_diffs > 10) & (rb_diffs > 10)) | ((bg_diffs > 10) & (gr_diffs > 10)) | ((gr_diffs > 10) & (rb_diffs > 10))

            # Prepare updated_coordinates using a list comprehension
            updated_coordinates = [[doctr_coordinates[i][0], doctr_coordinates[i][1], "Different color" if color_diffs[i] else "Same color"] for i in range(len(doctr_coordinates))]

            return updated_coordinates

        doctr_coordinates = text_color_compare(doctr_coordinates, image_path)
        
        #Performing ELA Analysis for detecting new text in image
        def ELA_Analysis(image_path, doctr_coordinates):
            
            def generate_ela_image(path, quality, ela_image_path):
                
                original_image = read_from_data_lake(path).convert("RGB")

                # resaving input image at the desired quality
                jpeg_image_io = io.BytesIO()
                original_image.save(jpeg_image_io, format='JPEG', quality=100)
                jpeg_image_io.seek(0)
                resaved_image_1 = Image.open(jpeg_image_io)

                jpeg_image_io = io.BytesIO()
                original_image.save(jpeg_image_io, format='JPEG', quality=quality)
                jpeg_image_io.seek(0)
                resaved_image_2 = Image.open(jpeg_image_io)

                # pixel difference between original and resaved image
                ela_image = ImageChops.difference(resaved_image_1, resaved_image_2)

                # scaling factors are calculated from pixel extremas
                extrema = ela_image.getextrema()
                max_difference = max([pix[1] for pix in extrema])
                if max_difference == 0:
                    max_difference = 1
                scale = 350.0 / max_difference

                # enhancing elaimage to brighten the pixels
                ela_image = ImageEnhance.Brightness(ela_image).enhance(scale)
                ela_image_buffer = io.BytesIO()
                ela_image.save(ela_image_buffer, format='JPEG')
                
                bytes_data = ela_image_buffer.getvalue()
                write_to_data_lake(bytes_data, ela_image_path)

                # ela_image.save(ela_image_path)
                return ela_image,scale

            quality = 90
            ela_image_path = os.path.join(overlay_output_image_path, "ELA_image")
            
            if not constants.IS_S3_PATH:
                os.makedirs(ela_image_path, exist_ok=True)
            
            ela_image_path = f"{ela_image_path}/{image_name}_ELA_img.png"
            
            ela,scale = generate_ela_image(image_path, quality, ela_image_path)
            # ela.show()

            #Enhacing the ELA Image for differentiating tamperings clearly from thr rest of the text.By converting the image into Binary format
            def ELA_binary_image_and_gray_check(ela_image):
                
                ELA_image = cv2.cvtColor(np.array(ela_image), cv2.COLOR_RGB2BGR)

                # Get the dimensions of the image
                height, width = ELA_image.shape[:2]
                
                ela_image_bw = np.zeros((height, width, 3), dtype=np.uint8)
                            
                diff_blue_green = np.abs(ELA_image[:,:,0] - ELA_image[:,:,1])
                diff_red_green = np.abs(ELA_image[:,:,1] - ELA_image[:,:,2])
                diff_blue_red = np.abs(ELA_image[:,:,0] - ELA_image[:,:,2])
                
                mask = (diff_blue_green < 30) & (diff_red_green < 30) & (diff_blue_red < 30) 
                
                ela_image_bw[mask] = [0,0,0]
                ela_image_bw[~mask] = [255,255,255]
                
                colored_pixels = np.count_nonzero(~mask)

                # Define the kernel for morphological operations
                kernel = np.ones((2,2), np.uint8)
                
                # Perform morphological opening (erosion followed by dilation)
                opened_image = cv2.morphologyEx(ela_image_bw, cv2.MORPH_OPEN, kernel)
                
                # Perform morphological closing (dilation followed by erosion) to fill small holes
                closed_image = cv2.morphologyEx(opened_image, cv2.MORPH_CLOSE, kernel)

                binary_ela_image = closed_image

                # Based on number of colored pixels in ELA image to check whether the image is gray or not.
                gray_check = 1
                if colored_pixels >=100:
                    gray_check = 0
                    
                return binary_ela_image, gray_check

            binary_ela_image, gray_check = ELA_binary_image_and_gray_check(ela) 

            #Function to find number of black pixels and white pixels in an image
            def black_white_pixel_count(img):
                # Assuming 'img' is a NumPy array with shape (height, width, 3)
                black_pixels = np.sum(img[:, :, 0] == 0)  # Count black pixels by checking if the red channel is 0
                white_pixels = img.shape[0] * img.shape[1] - black_pixels  # Total pixels - black pixels
                
                return max(black_pixels,1), max(white_pixels,1)
            
            def non_gray_ELA_tamperings(binary_ela_image, doctr_coordinates):
                
                height, width = binary_ela_image.shape[:2]
                words_and_pers = []
                word_heights = []
                
                for i in doctr_coordinates:
                    if i[0][1] >= 0.1*height and i[0][3] <= 0.9*height:
                        word_heights.append(round((i[0][3] - i[0][1]), -1))

                avg_word_height = statistics.mean(word_heights)
                
                for i in doctr_coordinates:
                    w,h = i[0][2] - i[0][0], i[0][3] - i[0][1]
                    x1 = int(i[0][0])
                    y1 = int(i[0][1] + 0.1*h)
                    x2 = int(i[0][2])
                    y2 = int(i[0][3] - 0.1*h)
                    word_img = binary_ela_image[y1:y2, x1:x2]
                    word_black, word_white = black_white_pixel_count(word_img)
                    black_per = round((word_black /(word_black + word_white)) * 100,2)
                    white_per = round((word_white /(word_black + word_white)) * 100,2)
                    words_and_pers.append([i[2], i[0], i[1], white_per, black_per])

                white_percentages = [i[3] for i in words_and_pers]
                white_mean = statistics.mean(white_percentages)
                white_stdev = statistics.stdev(white_percentages)
                
                if white_stdev != 0:
                    white_z_scores = [(i - white_mean)/white_stdev for i in white_percentages]
                else:
                    white_z_scores = [0 for i in white_percentages]

                black_percentages = [i[4] for i in words_and_pers]
                black_mean = statistics.mean(black_percentages)
                black_stdev = statistics.stdev(black_percentages)
                
                if black_stdev != 0:
                    black_z_scores = [(i - black_mean)/black_stdev for i in black_percentages]
                else:
                    black_z_scores = [0 for i in black_percentages]

                black_white_diff_pers = [abs(i[3] - i[4]) for i in words_and_pers]
                bw_mean = statistics.mean(black_white_diff_pers)
                bw_stdev = statistics.stdev(black_white_diff_pers)
                
                if bw_stdev != 0:
                    bw_z_scores = [(i - bw_mean)/bw_stdev for i in black_white_diff_pers]
                else:
                    bw_z_scores = [0 for i in black_white_diff_pers]

                for i in range(len(words_and_pers)):
                    words_and_pers[i].extend([black_white_diff_pers[i], white_z_scores[i], black_z_scores[i], bw_z_scores[i]])

                for i in words_and_pers:
                    if i[4] <= 55:
                        i.extend(["white_word"])
                    else:
                        i.extend(["black_word"])

                def tampering_color_check(words_and_pers):
                    word_colors = [i[-1] for i in words_and_pers]
                    total_words = len(word_colors)
                    white_words = 0
                    black_words = 0
                    for i in word_colors:
                        if i == "white_word":
                            white_words += 1
                        else:
                            black_words += 1
                    if (white_words/total_words) >= 0.4:
                        return "black_tampering"
                    else:
                        return "white_tampering"

                tampering_color = tampering_color_check(words_and_pers)
                avg_bw_diff = bw_mean
                tampered_words = []
                if tampering_color == "black_tampering":
                    for i in words_and_pers:
                        # print(i)
                        if i[-1] == "black_word" and(i[4] > 60)and (i[7] > 2.5 or i[8] > 1.5) and (i[1][3] - i[1][1]) > 0.7*avg_word_height:
                            if i[1][1] >= 0.1*height and i[1][3] <= 0.9*height:
                                tampered_words.append(i[:3])
                else:
                    for i in words_and_pers:
                        # print(i)
                        if i[-1] == "white_word" and (i[4] > 60) and ( i[6] > 2.5 or i[8] < -1.5) and (i[1][3] - i[1][1]) > 0.7*avg_word_height:
                            if i[1][1] >= 0.1*height and i[1][3] <= 0.9*height:
                                tampered_words.append(i[:3])

                return tampered_words
            
            non_gray_ela_tampered_words = non_gray_ELA_tamperings(binary_ela_image, doctr_coordinates)
            
            def gray_ela_tampering_detection(doctr_coordinates, ela_image):
                
                bgr_image = cv2.cvtColor(np.array(ela_image), cv2.COLOR_RGB2BGR)
                hsv_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2HSV)
                v_channel = cv2.split(hsv_image)[2]

                # Get the dimensions of the image
                height, width = bgr_image.shape[:2]
                
                word_heights = []
                for i in doctr_coordinates:
                    if i[0][1] >= 0.1*height and i[0][3] <= 0.9*height:
                        word_heights.append(round((i[0][3] - i[0][1]), -1))

                avg_word_height = statistics.mean(word_heights)

                def pixel_count_and_degree_whiteness(word_gray_pixels):
                    # Convert the list to a NumPy array if it's not already
                    word_gray_pixels = np.array(word_gray_pixels)

                    # Create a mask for non-black pixels (assuming black pixels have a value of 0)
                    non_black_pixels_mask = word_gray_pixels != 0
                    non_black_pixels = np.count_nonzero(non_black_pixels_mask)  # Count non-black pixels

                    # Calculate the grayness (sum of pixel values for non-black pixels)
                    grayness = np.sum(word_gray_pixels[non_black_pixels_mask])

                    # Total pixels
                    total_pixels = word_gray_pixels.size

                    # Calculate whiteness and blackness
                    white_pixels = round(non_black_pixels / max(total_pixels, 1), 2)
                    black_pixels = 100 - white_pixels

                    # Calculate the average grayness if non-black pixels exist
                    grayness_avg = grayness / non_black_pixels if non_black_pixels != 0 else 0

                    return white_pixels, black_pixels, grayness_avg

                words_and_avg_color = []
                for i in doctr_coordinates:
                    
                    x1 = int(i[0][0])
                    y1 = int(i[0][1] + 0.1 * (i[0][3] - i[0][1]))
                    x2 = int(i[0][2])
                    y2 = int(i[0][3] - 0.1 * (i[0][3] - i[0][1]))
                    word_gray_pixels = v_channel[y1:y2, x1:x2]
                    white_pixels, black_pixels, whiteness = pixel_count_and_degree_whiteness(word_gray_pixels)
                    words_and_avg_color.append([i[2],i[0],i[1],white_pixels, black_pixels, whiteness])

                whiteness_percentages = [i[5] for i in words_and_avg_color]
                whiteness_mean = statistics.mean(whiteness_percentages)
                whiteness_stdev = statistics.stdev(whiteness_percentages)
                
                if whiteness_stdev != 0:
                    whiteness_z_scores = [(i - whiteness_mean)/whiteness_stdev for i in whiteness_percentages]
                else:
                    whiteness_z_scores = [0 for i in whiteness_percentages]

                for i in range(len(words_and_avg_color)):
                    words_and_avg_color[i].extend([whiteness_z_scores[i]])

                tampered_words = []
                for i in words_and_avg_color:
                    if whiteness_mean > 60:
                        if abs(i[5] - whiteness_mean) > 20 and i[6] <= -3:
                            if i[1][1] >= 0.1*height and i[1][3] <= 0.9*height and (i[1][3] - i[1][1]) > 0.7*avg_word_height:
                                tampered_words.append(i[:3])
                    else:
                        if abs(i[5] - whiteness_mean) > 20 and i[6] >= 2.5:
                            if i[1][1] >= 0.1*height and i[1][3] <= 0.9*height and (i[1][3] - i[1][1]) > 0.7*avg_word_height:
                                tampered_words.append(i[:3])
                if len(tampered_words) > 10:
                    tampered_words = []

                return tampered_words
    
            tampered_words = []
            if gray_check == 0:
                tampered_words = non_gray_ela_tampered_words
                if len(tampered_words) == 0:
                    tampered_words = gray_ela_tampering_detection(doctr_coordinates, ela)
            else:
                tampered_words = gray_ela_tampering_detection(doctr_coordinates, ela)

            overlay_coords = [list(i[1]) for i in tampered_words if i[0] == "Same color"]
            overlay_words = [{'words':i[2],'coords':list(i[1])} for i in tampered_words if i[0] == "Same color"]

            final_overlay_coords, final_overlay_words = [], []
            for i in range(len(overlay_coords)):
                if len(overlay_words[i]['words']) > 1:
                    final_overlay_coords.append(overlay_coords[i])
                    final_overlay_words.append(overlay_words[i])
                else:
                    if overlay_words[i]['words'].isnumeric() :
                        final_overlay_coords.append(overlay_coords[i])
                        final_overlay_words.append(overlay_words[i])
            
            if len(final_overlay_coords) > 10:
                final_overlay_words, final_overlay_coords = [], []
            
            return final_overlay_words, final_overlay_coords
        
        #PRNU Analysis
        def PRNU_Analysis(image_path, doctr_coordinates): 

            def convert_to_PRNU_image(image_path, prnu_image_path):
                
                if constants.IS_S3_PATH:
                    raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
                else:    
                    raw_image_data = read_from_data_lake(image_path, reader='cv2')   
                    
                nparr = np.frombuffer(raw_image_data, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                denoised_image = cv2.fastNlMeansDenoising(gray_image, None, h=10, templateWindowSize=3, searchWindowSize=5)
                prnu = gray_image - denoised_image
                _, buffer = cv2.imencode('.png', prnu)
                bytes_data = buffer.tobytes()
                write_to_data_lake(bytes_data, prnu_image_path)
                return prnu

            prnu_image_path = os.path.join(overlay_output_image_path, "PRNU_image")

            if not constants.IS_S3_PATH:
                os.makedirs(prnu_image_path, exist_ok=True)
            
            prnu_image_path = f"{prnu_image_path}/{image_name}_prnu_img.png"

            PRNU_image = convert_to_PRNU_image(image_path, prnu_image_path)
            
            # Feature extraction from PRNU
            def feature_extraction(prnu, coordinates):

                x_min, y_min, x_max, y_max = coordinates
                height = y_max - y_min
                region = prnu[int(y_min):int(y_max), x_min:x_max]
                # Statistical features
                mean = region.mean()
                std = region.std()

                # Check if all values are identical
                if np.all(region.flatten() == region.flatten()[0]):
                    skewness = 0  # Define skewness as 0 for constant data
                    kurt = 0      # Define kurtosis as 0 for constant data
                else:
                    skewness = skew(region.flatten())
                    kurt = kurtosis(region.flatten())

                # Texture features
                region_gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
                _, region_binary = cv2.threshold(region_gray, 30, 255, cv2.THRESH_BINARY)
                white_pixel_count = np.sum(region_binary == 255)
                white_percentage = (white_pixel_count/region_binary.size)*100
                lbp = local_binary_pattern(region_gray, P=8, R=1.0, method='uniform').mean()

                # Combine features
                return [mean, std, skewness, kurt, lbp, white_percentage]

            def tampering_detection_prnu(prnu, doctr_coordinates):
                     
                words_cos_sim =[]
            
                doctr_boxes = doctr_coordinates
                for i, word_data in enumerate(doctr_boxes):
                    doctr_coordinates[i].append(feature_extraction(prnu, word_data[0]))

                st_time = time.time()

                # Extract PRNU features
                prnu_features = np.array([data[3] for data in doctr_coordinates])

                # Compute the cosine similarity matrix
                similarity_matrix = cosine_similarity(prnu_features)

                # Compute mean similarity for each word with other words in document
                words_cos_sim = similarity_matrix.mean(axis=1).tolist()

                words_cos_mean = np.mean(words_cos_sim)
                words_cos_stdev = np.std(words_cos_sim)

                if words_cos_stdev != 0:
                    words_cos_z_scores = [(i - words_cos_mean)/words_cos_stdev for i in words_cos_sim]
                else:
                    words_cos_z_scores = [0 for i in words_cos_sim]

                tampered_words = []
                for i in range(len(words_cos_z_scores)):
                    doctr_coordinates[i].append(words_cos_sim[i])
                    doctr_coordinates[i].append(words_cos_z_scores[i])
                    # print(doctr_coordinates[i][1], "|", round(words_cos_sim[i],4), "|", round(words_cos_z_scores[i],4))

                    if ((words_cos_z_scores[i] < -1 and abs(words_cos_sim[i]) < 0.985) or abs(words_cos_sim[i]) <= 0.9) and (len(doctr_coordinates[i][1])>1):
                        tampered_words.append(doctr_coordinates[i])

                return tampered_words
            
            if constants.IS_S3_PATH:
                raw_image_data = read_from_data_lake(prnu_image_path, reader='cv2').getvalue()
            else:    
                raw_image_data = read_from_data_lake(prnu_image_path, reader='cv2')   

            nparr = np.frombuffer(raw_image_data, np.uint8)
            PRNU_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            tampered_words = tampering_detection_prnu(PRNU_image, doctr_coordinates)
            overlay_coords = [list(i[0]) for i in tampered_words if i[2] == "Same color"]
            overlay_words = [{'words':i[1],'coords':list(i[0])} for i in tampered_words if i[2] == "Same color"]
            
            final_overlay_coords, final_overlay_words = [], []
            for i in range(len(overlay_coords)):
                if len(overlay_words[i]['words']) > 1:
                    final_overlay_coords.append(overlay_coords[i])
                    final_overlay_words.append(overlay_words[i])
                else:
                    if overlay_words[i]['words'].isnumeric():
                        final_overlay_coords.append(overlay_coords[i])
                        final_overlay_words.append(overlay_words[i])
            
            if len(final_overlay_coords) > 10:
                final_overlay_words, final_overlay_coords = [], []
            
            return final_overlay_words, final_overlay_coords
        
        def Sobel_PRNU_suspicious_map(image_path, doctr_coordinates):
            
            if constants.IS_S3_PATH:
                raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
            else:    
                raw_image_data = read_from_data_lake(image_path, reader='cv2')   

            nparr = np.frombuffer(raw_image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            def suspicious_map_generation(image):
        
                """Creating the PRNU"""
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                smooth = cv2.GaussianBlur(gray, (3,3), 0)
                prnu = gray.astype(float)-smooth

                """Generating Sobel Edges Filtered Image"""
                clahe = cv2.createCLAHE(clipLimit = 2.0, tileGridSize = (8,8))
                gray2 = clahe.apply(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))

                grad_x = cv2.Sobel(gray2, cv2.CV_64F, 1, 0, ksize = 3)
                grad_y = cv2.Sobel(gray2, cv2.CV_64F, 0, 1, ksize = 3)
                edges = cv2.magnitude(grad_x, grad_y)
                edges = cv2.normalize(edges, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

                """Generating Suspicious map using PRNU Pattern and Sobel filter image"""
                prnu_normalized = cv2.normalize(np.abs(prnu), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                prnu_thresh = np.percentile(prnu_normalized, 99)
                edge_thresh = np.percentile(edges, 99)
                suspicious_map = np.zeros_like(prnu_normalized, dtype = np.uint8)
                suspicious_map [(prnu_normalized > prnu_thresh) & (edges > edge_thresh)] = 255

                highlighted_image = image.copy()
                highlighted_image[suspicious_map > 0] = [255,0,0]

                """Saving these Suspicious images"""
                base_folder = os.path.join(overlay_output_image_path, "suspicious_map")
                # print(base_folder)
                os.makedirs(base_folder, exist_ok = True)
                
                suspicious_map_path = os.path.join(base_folder, "suspicious_map.png")
                suspicious_highlighted_map_path = os.path.join(base_folder, "suspicious_highlighted_image.png")

                if len(suspicious_map.shape) > 2 and suspicious_map.shape[2] == 3:
                    suspicious_map = cv2.cvtColor(suspicious_map, cv2.COLOR_BGR2GRAY)
                    
                #Saving the Suspicious map image
                suspicious_map_buffer = io.BytesIO()
                plt.imsave(suspicious_map_buffer, cv2.cvtColor(suspicious_map, cv2.COLOR_BGR2RGB), format='png')
                suspicious_map_buffer.seek(0)
                bytes_data = suspicious_map_buffer.getvalue()
                write_to_data_lake(bytes_data, suspicious_map_path)
                
                #Saving the Suspicious Highlighted image
                highlighted_image_buffer = io.BytesIO()
                plt.imsave(highlighted_image_buffer, cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB), format='png')
                highlighted_image_buffer.seek(0)
                bytes_data = highlighted_image_buffer.getvalue()
                write_to_data_lake(bytes_data, suspicious_highlighted_map_path)

                return suspicious_map

            suspicious_map = suspicious_map_generation(image)

            def map_boxes_to_suspicious_map(image, suspicious_map, boxes):
                suspicious_map_height, suspicious_map_width = suspicious_map.shape 
                height, width = image.shape[:2] 
                # Ensure both images have the same size; resize if necessary 
                if (suspicious_map_height, suspicious_map_width) != (height, width): 
                    suspicious_map = cv2.resize(suspicious_map, (width, height), interpolation=cv2.INTER_NEAREST) 

                results = [] 
                for box in boxes: 
                    x_min, y_min, x_max, y_max = box[0] 

                    # Extract the region from the suspicious map
                    region = suspicious_map[y_min:y_max, x_min:x_max] 
                    # Calculate percentage of white pixels 
                    total_pixels = region.size 
                    white_pixels = cv2.countNonZero(region) 
                    white_pixel_percentage = (white_pixels / total_pixels) * 100 if total_pixels > 0 else 0 

                    results.append({
                        'bbox': (x_min, y_min, x_max, y_max), 
                        'value': box[1], 
                        'word_color': box[2],
                        'white_pixel_percentage': round(white_pixel_percentage,4)
                    }) 

                white_percentages = np.array([i['white_pixel_percentage'] for i in results])
                white_mean = np.mean(white_percentages)
                white_stdev = np.std(white_percentages)

                if white_stdev != 0:
                    white_z_scores = [(i - white_mean)/white_stdev for i in white_percentages]
                else:
                    white_z_scores = [0 for i in white_percentages]

                for i in range(len(results)):
                    results[i]['Z score'] = round(white_z_scores[i],4)

                # Sort by 'white pixel percentage'
                results = sorted(results, key=lambda x: x["white_pixel_percentage"], reverse = True)

                white_pers = [x["white_pixel_percentage"] for x in results]
                sudden_decrease = 0
                for i in range(1, len(white_pers)):
                    diff = white_pers[i - 1] - white_pers[i]
                    sudden_decrease = max(sudden_decrease, diff)

                tampered_words = []
                for i in results:
                    if i['white_pixel_percentage'] >= 9 and i["Z score"] >= 1.5 and sudden_decrease > 2.5:
                        tampered_words.append([i['bbox'], i['value'], i['word_color']])
                    if i['white_pixel_percentage'] <= 0.3 and i["Z score"] <= -1.5:
                        tampered_words.append([i['bbox'], i['value'], i['word_color']])

                return tampered_words

            tampered_words = map_boxes_to_suspicious_map(image, suspicious_map, doctr_coordinates)
            
            overlay_coords = [list(i[0]) for i in tampered_words if i[2] == "Same color"]
            overlay_words = [{'words':i[1],'coords':list(i[0])} for i in tampered_words if i[2] == "Same color"]
            
            final_overlay_coords, final_overlay_words = [], []
            for i in range(len(overlay_coords)):
                if len(overlay_words[i]['words']) > 1:
                    final_overlay_coords.append(overlay_coords[i])
                    final_overlay_words.append(overlay_words[i])
                else:
                    if overlay_words[i]['words'].isnumeric():
                        final_overlay_coords.append(overlay_coords[i])
                        final_overlay_words.append(overlay_words[i])
            
            if len(final_overlay_coords) > 10:
                final_overlay_words, final_overlay_coords = [], []
            
            return final_overlay_words, final_overlay_coords
        
        def check_date_patterns(word):
            date_pattern = [
                    r"\b\d{1,2}(st|nd|rd|th)?\s+July\s+\d{4}\b",
                    r"\bJuly\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}\b",
                    r"\b\d{4}\s+July\s+\d{1,2}\b",
                    r"\b\d{1,2}\s+Jul\s+\d{4}\b",
                    r"\bJul\s+\d{1,2}\s+\d{4}\b",
                    r"\b\d{4}\s+Jul\s+\d{1,2}\b",
                    r"\b\d{2}[-/]\d{2}[-/]\d{4}\b",
                    r"\b\d{4}[-/]\d{2}[-/]\d{2}\b",
                    r"\b\d{2}[-/]\d{4}[-/]\d{2}\b",
                    r"\b\d{2}[-/]\d{2}\b",
                    r"\bJul\s+\d{1,2}\b",
                    r"\b\d{1,2}\s+Jul\b",
            ]
            for pattern in date_pattern:
                if re.search(pattern, word):
                    return True
            return False

        def contains_number(s):
            return bool(re.search(r'\d', s))
        
        def named_enity_reg (word, line_text):

            model = GLiNER.from_pretrained("numind/NuNerZero")
            # NuZero requires labels to be lower-cased!
            labels = ["organization", "Company name", "person name", "address", "place", "location", "document type"]
            labels = [l.lower() for l in labels]

            text = line_text
            entities = model.predict_entities(line_text, labels)
            # print(entities)
            word_entity = "random word"
            for entity in entities:
                if word == entity["text"]:
                    word_entity = entity["label"]
            return word_entity
        
        def line_words(doctr_coordinates, word_coor):  
            words_in_line = []
            coords = word_coor["coords"]
            word = word_coor["words"]
            word_height = coords[3] - coords[1]
            
            for i in doctr_coordinates:
                i_height = i[0][3] - i[0][1]
                height_diff = abs(i_height - word_height)
                if abs(i[0][3]-coords[3]) < 0.5*word_height and abs(i[0][1]-coords[1]) < 0.5*word_height:
                    if height_diff < 0.1*word_height:
                        if coords[0] == i[0][0] and coords[1] == i[0][1]:
                            words_in_line.append([i[0],i[1],"yes"])
                        else:
                            words_in_line.append([i[0],i[1],"no"])

            words_in_line = sorted(words_in_line, key=lambda x: x[0][0])
            sublines = []
            subline = []
            for i in range(len(words_in_line)):
                if i<len(words_in_line)-2:
                    current_word = words_in_line[i]
                    next_word = words_in_line[i+1]
                    if (next_word[0][0] - current_word[0][0]) < 1.5*((current_word[0][2] - current_word[0][0])):
                        subline.append(words_in_line[i])
                    else:
                        sublines.append(subline)
                        subline = []
                else:
                    subline.append(words_in_line[i])
                    sublines.append(subline)
            main_line = []
            for l in sublines:
                if "yes" in [i[2] for i in l]:
                    main_line = l

            line_text = " ".join([i[1] for i in main_line])
            return main_line, line_text
        
        def tampering_filter(overlay_words, overlay_coords, doctr_coordinates):
        
            final_overlay_words = [] 
            final_overlay_coords = []
            for i in overlay_words:
                word = str(i["words"])
                line_text = line_words(doctr_coordinates, i)[1]

                if check_date_patterns(word):
                    final_overlay_coords.append(list(i["coords"])) 
                    final_overlay_words.append({'words':i["words"],'coords':list(i["coords"]), 'word_type':"date", 'severity':"HIGH"})
                else:
                    if contains_number(word):
                        final_overlay_coords.append(list(i["coords"])) 
                        final_overlay_words.append({'words':i["words"],'coords':list(i["coords"]), 'word_type':"Numerical", 'severity':"HIGH"})
                    else:
                        word_type = named_enity_reg(word, line_text)
                        if word_type == "organization" or word_type == "Company name" or word_type == "person name":
                            final_overlay_coords.append(list(i["coords"])) 
                            final_overlay_words.append({'words':i["words"],'coords':list(i["coords"]), 'word_type':word_type, 'severity':"HIGH"})

                        elif word_type == "address" or word_type == "place" or word_type == "location" or word_type == "document type":
                            final_overlay_coords.append(list(i["coords"])) 
                            final_overlay_words.append({'words':i["words"],'coords':list(i["coords"]), 'word_type':word_type, 'severity':"MEDIUM"})

                        else:
                            final_overlay_coords.append(list(i["coords"])) 
                            final_overlay_words.append({'words':i["words"],'coords':list(i["coords"]), 'word_type':"random word",'severity':"LOW"})

            return final_overlay_words, final_overlay_coords
        
        if constants.IS_S3_PATH:
            raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
        else:    
            raw_image_data = read_from_data_lake(image_path, reader='cv2')
        nparr = np.frombuffer(raw_image_data, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        # Get the dimensions of the image
        image_height, image_width = image.shape[:2]   
        
        detection_method = ""
        if len(doctr_coordinates) > 10 and (image_height > 400 and image_width > 400) and png_jpg_check(image_path):
            print("Performing Error Level Analysis (ELA) .....")
            print()
            # ela_start_time = time.time()
            overlay_words, overlay_coords = ELA_Analysis(image_path, doctr_coordinates)
            # print("ELA Time Taken: ", time.time() - ela_start_time)
            
            if len(overlay_words) > 0:
                detection_method = "ELA"
                print(f"ELA detected {len(overlay_words)} tamperings")
                print()
                
            else:
                print("Performing PRNU analysis......")
                print()
                # prnu_start_time = time.time()
                overlay_words, overlay_coords = PRNU_Analysis(image_path, doctr_coordinates)
                # print("PRNU Time Taken: ", time.time() - prnu_start_time)

                if len(overlay_words) > 1:
                    detection_method = "PRNU"
                    print(f"PRNU detected {len(overlay_words)} tamperings")
                    print()
                    
                else:
                    print("Performing Sobel PRNU Suspicious Map analysis......")
                    print()
                    # prnu_start_time = time.time()
                    overlay_words, overlay_coords = Sobel_PRNU_suspicious_map(image_path, doctr_coordinates)
                    # print("PRNU Time Taken: ", time.time() - prnu_start_time)

                    if len(overlay_words) > 0:
                        detection_method = "Sobel - PRNU"
                        print(f"Sobel PRNU Analysis detected {len(overlay_words)} tamperings")
                        print()
                    else:
                        print("It is a clean Image, no new text is found")
                        overlay_words = []
                        overlay_coords = []
            if len(overlay_words)> 10:
                overlay_words, overlay_coords = tampering_filter(overlay_words, overlay_coords, doctr_coordinates)
            return overlay_words, overlay_coords, detection_method
            
        else:
            overlay_words, overlay_coords = [], []
            if not png_jpg_check(image_path):
                print("Image format is not supported")
                
            elif not len(doctr_coordinates) > 10:
                print("Can't detect any text in given image")
                
            elif not (image_height > 400 and image_width > 400):
                print("Low resolution image")

            return overlay_words, overlay_coords, detection_method
        
    @staticmethod
    def copymove_refine_data(data):
        refined_list = []
        combined_entries = {}

        for item in data:
            image_1_key = item['image_1']
            if image_1_key not in combined_entries:
                combined_entries[image_1_key] = {
                    'image_1': item['image_1'],
                    'word_1': item['word_1'],
                    'coordinates_1': item['coordinates_1'],
                    'images_2': [item['image_2']],
                    'words_2': [item['word_2']],
                    'coordinates_2': [item['coordinates_2']]
                }
            else:
                combined_entries[image_1_key]['images_2'].append(item['image_2'])
                combined_entries[image_1_key]['words_2'].append(item['word_2'])
                combined_entries[image_1_key]['coordinates_2'].append(item['coordinates_2'])

        for key, value in combined_entries.items():
            if len(value['images_2']) > 1:
                new_item = {
                    'image_1': value['image_1'],
                    'word_1': value['word_1'],
                    'coordinates_1': value['coordinates_1'],
                }
                for i, img in enumerate(value['images_2']):
                    new_item[f'image_{i+2}'] = img
                    new_item[f'word_{i+2}'] = value['words_2'][i]
                    new_item[f'coordinates_{i+2}'] = value['coordinates_2'][i]
                refined_list.append(new_item)
            else:
                refined_list.append({
                    'image_1': value['image_1'],
                    'image_2': value['images_2'][0],
                    'word_1': value['word_1'],
                    'word_2': value['words_2'][0],
                    'coordinates_1': value['coordinates_1'],
                    'coordinates_2': value['coordinates_2'][0],
                })

        return refined_list

    @classmethod
    def overlay_entry(cls, image_path, overlay_output_image_path):

        finaloverlay_df = pd.DataFrame([]) 
        df_copymove = pd.DataFrame([])
        df_newtext = pd.DataFrame([])
        
        copymove_results, copymove_coordinates = cls.copymove(image_path, overlay_output_image_path)
        
        if len(copymove_results) < 10:
            refined_data = cls.copymove_refine_data(copymove_results)
            formatted_data = []
            for item in refined_data:
                coordinates = [item[key] for key in item if "coordinates" in key]
                formatted_data.append({
                    "Type": "Copy & Move",
                    "Tampering": item['word_1'],
                    "Coordinates": coordinates
                })
            df_copymove = pd.DataFrame(formatted_data)
        
        else:
            copymove_coordinates = []
            
        newtext_results, newtext_coordinates, newtext_detection_method = cls.new_text_detection_using_noise_pattern(image_path, overlay_output_image_path)
        
        if newtext_results:
            formatted_newtext_data = [
                {
                    "Type": "New Text " + newtext_detection_method,
                    "Tampering": item['words'],
                    "Coordinates": item['coords']
                }
                for item in newtext_results
            ]
            df_newtext  = pd.DataFrame(formatted_newtext_data)
            # print("--------------newtext--------------")
            # print(df_newtext)
            
        if len(df_copymove):
            finaloverlay_df = pd.concat([df_copymove, df_newtext], axis=0, ignore_index=True)
        else:
            finaloverlay_df = df_newtext
        
        if len(finaloverlay_df):
            overlay_report = pd.DataFrame(finaloverlay_df)
            check = overlay_report['Type'].isin(['Copy & Move','New Text ELA', 'New Text PRNU', 'New Text Sobel - PRNU']).any()
            #check if finaloverlay_df is empty or not
            if check:
                insights = {
                    'Copy & Move': 'Text has been copied and pasted else where in same document',
                    'New Text ELA': 'New Text added',
                    'New Text PRNU': 'New Text added',
                    'New Text Sobel - PRNU': 'New Text added'
                    
                }
                severity_levels = {
                    'Copy & Move': 'MEDIUM',
                    'New Text ELA': 'HIGH',
                    'New Text PRNU': 'HIGH',
                    'New Text Sobel - PRNU': 'MEDIUM'
                }
                overlay_report['Interaction Type'] = overlay_report['Type']
                overlay_report['Flag'] = 1  
                overlay_report['Severity_Level'] = overlay_report['Type'].map(severity_levels)
                overlay_report['Insight'] = overlay_report['Type'].map(insights)
                overlay_report_final = overlay_report[['Interaction Type', 'Flag', 'Severity_Level', 'Insight']]
            else:
                overlay_report_final = pd.DataFrame(columns=['Interaction Type', 'Flag', 'Severity_Level', 'Insight'])
        else:
            overlay_report_final = pd.DataFrame(columns=['Interaction Type', 'Flag', 'Severity_Level', 'Insight'])
            
        return finaloverlay_df, copymove_coordinates, newtext_coordinates, overlay_report_final, cls.overlay_error_list

if __name__ == "__main__":
    input_file_path = "test_img/test_image.png"
    overlay_output_image_path = os.path.join("output", "images", "overlay")
    overlay_df, copymove_coordinates, newtext_coordinates = Overlay.overlay_entry(input_file_path, overlay_output_image_path)
