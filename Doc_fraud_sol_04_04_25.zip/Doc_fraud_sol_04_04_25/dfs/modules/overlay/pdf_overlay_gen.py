import sys, os
import os
import openpyxl
import numpy as np
import pandas as pd
import fitz
import warnings
import io
from pandas.io.formats import excel
from dfs.commons import constants
warnings.filterwarnings('ignore')
excel.ExcelFormatter.header_style = None


class Overlay:
    overlay_error_list = []
    @staticmethod
    def get_iou(R1, R2):
        # Co-ordinate system origin is assumed to be on top left corner of the screen.
        # coordinates of the area of intersection. 
        x1 = np.maximum(R1[0], R2[0]) ;     y1 = np.maximum(R1[1], R2[1])
        x2 = np.minimum(R1[2], R2[2]) ;     y2 = np.minimum(R1[3], R2[3])

        # Different Areas    
        area_of_intersection = (np.maximum(y2 - y1 , np.array(0.0))) * (np.maximum(x2 - x1 , np.array(0.0)))

        A1 = ( (R1[3] - R1[1] ) * (R1[2] - R1[0] ) )
        A2 = ( (R2[3] - R2[1] ) * ( R2[2] - R2[0] ) ) 

        area_of_union = A1 + A2- area_of_intersection+1

        iou = area_of_intersection / area_of_union

        return [area_of_intersection/A1, area_of_intersection/A2]

    @staticmethod
    def Overall_Severity_Level(AreaPercentage1,AreaPercentage2,Interaction_type):
        if Interaction_type in ('Text on Image', 'Image on Text','Image on Image'):
            if AreaPercentage1< 0.5 and AreaPercentage2< 0.5:
                return('LOW')
            elif AreaPercentage1>=0.8 or AreaPercentage2>=0.8:
                return('HIGH')
            else:
                return('MEDIUM')
        elif Interaction_type == 'Text on Text':
            if AreaPercentage1>=0.8 or AreaPercentage2>=0.8:
                return('HIGH')
            else:
                return('MEDIUM')
        
    @staticmethod
    def get_expected_area(bankname):
        if bankname == '':
            return ''
        fileName = constants.OVERLAY_REPOSITORY_PATH_GEN   
        df = pd.read_excel(fileName,sheet_name='overlay suppression v3')
        df.set_index('Bank name',inplace=True)
        df = df.fillna('')
        # df = overlay_repo
        try:
            Expected_area = df.loc[bankname]['Area']
            return Expected_area.tolist()
        except:
            return ''  
    
    @staticmethod
    def get_expected_coord1(bankname):
        if bankname == '':
            return ''
        # df = overlay_repo
        fileName = constants.OVERLAY_REPOSITORY_PATH_GEN 
        df = pd.read_excel(fileName,sheet_name='overlay suppression v3')
        df = df.fillna('')
        try:
            Expected_coord1 = df.loc[bankname]['Coord1']
            return Expected_coord1.tolist()
        except:
            return '' 

    @staticmethod
    def get_expected_coord2(bankname):
        if bankname == '':
            return ''
        # df = overlay_repo
        fileName = constants.OVERLAY_REPOSITORY_PATH_GEN 
        df = pd.read_excel(fileName,sheet_name='overlay suppression v3')
        df = df.fillna('')
        try:
            Expected_coord2 = df.loc[bankname]['Coord2']
            return Expected_coord2.tolist()
        except:
            return '' 
        
    @staticmethod
    def is_within_threshold(value,threshold,exp_value):
        return exp_value - threshold <= value <= exp_value + threshold

    @staticmethod
    def is_within_threshold_percent(value,threshold,exp_value):
        return exp_value - threshold*exp_value <= value <= exp_value + threshold*exp_value

    @classmethod
    def check_threshold_range_area(cls,value, threshold,expected_value):
        result = [cls.is_within_threshold_percent(value,threshold,exp_value) for exp_value in expected_value]
        return any(x == True for x in result)

    @classmethod
    def check_threshold_range_coord(cls,value, threshold,expected_value):
        result = [cls.is_within_threshold(value,threshold,exp_value) for exp_value in expected_value]
        return any(x == True for x in result)

    @classmethod
    def draw_pdf(cls, annotations_output_pdf_path, pdf_highlighting_coordinates_overlay,
                 element_overlap_output_pdf_path):
        try:
            doc = fitz.open(annotations_output_pdf_path)
        except Exception as e:
            print(e)
            return
        for page_number, temp in pdf_highlighting_coordinates_overlay:
            page1 = doc[page_number]
            page1.draw_rect(temp, color=(1, 0, 0), width=1)

        doc.save(element_overlap_output_pdf_path)
        
    @classmethod
    def check_relative_position_n_Draw_Box(cls,doc1,bankname, temp, pn,image_output_dir, pdf_highlighting_coordinates):
        
        temp = temp.sort_values(by='BlockArea')


        df1 = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                   'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight','BoundingBlock1Area','Totalword1Area','BoundingBlock2Area','Totalword2Area'])


        PageNumber1=[]; Bbox1=[]; BBox1Type=[]; Bbox2=[]; BBox2Type=[]; Bbox1Cont=[]; Bbox2Cont=[]; InteractionType = []
        Flag =[]; Severity_Level=[]; Insight=[]
        BoundingBlock1Area1 = []; Totalword1Area1 =[]; BoundingBlock2Area1 = []; Totalword2Area1 =[]

        page1 = doc1[pn]
        Areas1 = temp.BlockArea 
        expected_area = cls.get_expected_area(bankname)
        expected_coord1 = cls.get_expected_coord1(bankname)
        expected_coord2 = cls.get_expected_coord2(bankname)
        word_list = ['Capitec','Bank','Device','Branch','DOCUMENT','Document','470010', '9003']

        
        def pullIMage(doc2,Page_Number,BIi,BIj,rcj,imgc,image_output_dir):

            save_location = image_output_dir
            ImageFileName = f"page_{Page_Number+1}_{imgc}_{BIi}_{BIj}.png"
            pix = doc2[Page_Number].get_pixmap(clip=rcj)
            pix.save(save_location + ImageFileName)
            return f"page_{Page_Number+1}_{imgc}_{BIi}_{BIj}.png"

        for i in range(temp.shape[0]-1):
            for j in range(i,temp.shape[0]):

                rci= fitz.Rect(temp.Bbox[i])
                rcj= fitz.Rect(temp.Bbox[j])

                image_counter=1

                if temp.BlockArea[i] < 0.8* temp.PageArea[i] and temp.BlockArea[j] < 0.8* temp.PageArea[j] :


                    if temp.TotalWordArea[i] > 0.3* temp.BlockArea[i] : 
                        iou = cls.get_iou(temp.Bbox[j], temp.Bbox[i])
                        #print(iou[0],iou[1],temp.BlockArea[i],temp.BlockArea[j], temp.PageArea[i], temp.PageArea[j])

                        if (iou[0] > 0.25 or iou[1] >0.25)   and (i!=j) :

                            #image_counter=1

                            if temp.BlockType[j]==0 and temp.BlockType[i] == 0 :
                                temp_words_i = temp.WordLevelData[i]
                                temp_words_j = temp.WordLevelData[j]
                                for words_i in temp_words_i:
                                    for words_j in temp_words_j :
                                        iou = iou = cls.get_iou(words_i[0:4],words_j[0:4])
                                        if (iou[0] > 0.3 or iou[1] >0.3) and (words_i[4] != words_j[4]) and words_i[4] not in word_list and words_j[4] not in word_list :
                                            print(iou[0],iou[1])
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                            Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                            BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                            Bbox1Cont.append(words_j[4])
                                            Bbox2Cont.append(words_i[4])
                                            InteractionType.append('Text on Text')
                                            Insight.append('Overlaid Text box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Text'))
                                            pdf_highlighting_coordinates.append((pn,words_j[0:4]))
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))
                                            # page1.draw_rect(words_j[0:4],  color = (1, 0, 0), width = 1) 
                                            # page1.draw_rect(words_i[0:4],  color = (1, 0, 0), width = 1)

                            if temp.BlockType[j]==0 and temp.BlockType[i] == 1 and not (cls.check_threshold_range_area(temp.BlockArea[i],0.1,expected_area)):
                            #if temp.BlockType[j]==0 and temp.BlockType[i] == 1 and round(temp.BlockArea[i],5) not in expected_area :
                                if not (cls.check_threshold_range_coord(temp.Bbox[i][0],5,expected_coord1))  :
                                    if not (cls.check_threshold_range_coord(temp.Bbox[i][1],5,expected_coord2))  :

                                        PageNumber1.append(temp.Page_Num[i]+1) ; 
                                        Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                        Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                        BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                        BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                        Bbox1Cont.append(temp.BlockText[j])
                                        Bbox2Cont.append(pullIMage(doc1,pn,temp.BlockId[j],temp.BlockId[i],rci,image_counter,image_output_dir))
                                        image_counter+=1
                                        if temp.BlockId[j]>temp.BlockId[i] :
                                            InteractionType.append('Text on Image')
                                            Insight.append('Overlaid Text box detected on existing Image')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))
                                        else:
                                            InteractionType.append('Image on Text')
                                            Insight.append('Overlaid Image box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_LevelOverall_Severity_Level(iou[0],iou[1],'Image on Text'))
                                            
                                        pdf_highlighting_coordinates.apped((pn,temp.Bbox[j]))
                                        pdf_highlighting_coordinates.apped((pn,temp.Bbox[i]))

                            if temp.BlockType[j]==1 and temp.BlockType[i] == 0 and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)):
                            #if temp.BlockType[j]==1 and temp.BlockType[i] == 0 and round(temp.BlockArea[j],5) not in expected_area :
                                if not (cls.check_threshold_range_coord(temp.Bbox[j][0],5,expected_coord1)) :
                                    if not (cls.check_threshold_range_coord(temp.Bbox[j][1],5,expected_coord2)) :

                                        PageNumber1.append(temp.Page_Num[i]+1) ; 
                                        Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                        Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                        BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                        BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                        Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                        Bbox2Cont.append(temp.BlockText[i])
                                        image_counter+=1
                                        if temp.BlockId[j]<temp.BlockId[i]:
                                            InteractionType.append('Text on Image')
                                            Insight.append('Overlaid Text box detected on existing Image')
                                            # print(temp.BlockArea[j],2)
                                            # print(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area))
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))
                                            #page1.draw_rect(temp.Bbox[j],  color = (1, 0, 0), width = 1) 
                                            #page1.draw_rect(temp.Bbox[i],  color = (1, 0, 0), width = 1)
                                        else:
                                            InteractionType.append('Image on Text')
                                            Insight.append('Overlaid Image box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Text'))
                                                                            
                                        pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))    
                                        pdf_highlighting_coordinates.append((pn,temp.Bbox[i]))                                    
                                        # page1.draw_rect(temp.Bbox[j],  color = (1, 0, 0), width = 1)
                                        #print(temp.Bbox[j],fitz.Rect(temp.Bbox[j][0:4]).get_area())
                                        #print(temp.BlockArea[j])
                                        # page1.draw_rect(temp.Bbox[i],  color = (1, 0, 0), width = 1)
                                        #print(temp.Bbox[i])

                            if temp.BlockType[j]==1 and temp.BlockType[i] == 1 and not(cls.check_threshold_range_area(temp.BlockArea[i],0.1,expected_area)) and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)):
                            #if temp.BlockType[j]==1 and temp.BlockType[i] == 1 and round(temp.BlockArea[i],5) not in expected_area and round(temp.BlockArea[j],5) not in expected_area:
                                if temp.BlockArea[i] < 0.45* temp.PageArea[i] and temp.BlockArea[j] < 0.45* temp.PageArea[j] and (iou[0] > 0.7 or iou[1] > 0.7) :
                                #To filter if both the images which are 50% of the page size
                                #In the above case a overlay is possible if atleast either of them is completely overlayed like iouu = 1(for safeleepinf we have kept 0.7

                                    if not (cls.check_threshold_range_coord(temp.Bbox[i][0],5,expected_coord1)) and not (cls.check_threshold_range_coord(temp.Bbox[j][0],5,expected_coord1)):
                                        if not (cls.check_threshold_range_coord(temp.Bbox[i][1],5,expected_coord2)) and not (cls.check_threshold_range_coord(temp.Bbox[j][1],5,expected_coord2)):

                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                            Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                            BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                            Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                            image_counter+=1
                                            Bbox2Cont.append(pullIMage(doc1,pn,temp.BlockId[j],temp.BlockId[i],rci,image_counter,image_output_dir))
                                            image_counter+=1
                                            InteractionType.append('Image on Image')
                                            Insight.append('Overlaid Image box detected on existing Image')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Image'))
                                            
                                            pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                            pdf_highlighting_coordinates.append((pn,temp.Bbox[i]))                                
                                            # page1.draw_rect(temp.Bbox[j],  color = (1, 0, 0), width = 1) 
                                            # page1.draw_rect(temp.Bbox[i],  color = (1, 0, 0), width = 1)

                    else:
                        #word vs block
                        temp_words_i = temp.WordLevelData[i]
                        for words_i in temp_words_i:
                            iou = iou = cls.get_iou(temp.Bbox[j],words_i[0:4])
                            if (iou[0] > 0.25 or iou[1] >0.25) and (i!=j) :              

                                if temp.BlockType[j]==0 :
                                    temp_words_j = temp.WordLevelData[j]
                                    words_i_list =[]
                                    for words_j in temp_words_j :
                                        iou = iou = cls.get_iou(words_i[0:4],words_j[0:4])
                                        if (iou[0] > 0.3 or iou[1] >0.3) and (i!=j) and (words_i[4] != words_j[4] and words_i[4] not in word_list and words_j[4] not in word_list) : 
                                            # print(iou[0],iou[1])
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            BBox1Type.append(temp.BlockType[j])
                                            BBox2Type.append('Word_text')
                                            BoundingBlock2Area1.append(temp.BlockArea[j]); Totalword2Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock1Area1.append(temp.BlockArea[i]); Totalword1Area1.append(temp.TotalWordArea[i])
                                            Bbox1.append(words_j[0:4])
                                            Bbox2.append(words_i[0:4]) 
                                            Bbox1Cont.append(words_j[4])
                                            words_i_list.append(words_i[4])
                                            Bbox2Cont.append(words_i[4])
                                            InteractionType.append('Text on Text')
                                            Insight.append('Overlaid Text box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Text'))
                                                                                
                                            pdf_highlighting_coordinates.append((pn,words_j[0:4]))
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))                                    
                                            # page1.draw_rect(words_j[0:4],  color = (1, 0, 0), width = 1)
                                            # page1.draw_rect(words_i[0:4],  color = (1, 0, 0), width = 1)

                                if temp.BlockType[j]==1 and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)):
                                #if temp.BlockType[j]==1 and round(temp.BlockArea[j],5) not in expected_area :
                                    if not(cls.check_threshold_range_coord(temp.Bbox[j][0],1,expected_coord1)):
                                        if not(cls.check_threshold_range_coord(temp.Bbox[j][1],1,expected_coord2)):
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            BBox1Type.append(temp.BlockType[j])
                                            BBox2Type.append('Word_text')
                                            BoundingBlock2Area1.append(temp.BlockArea[j]); Totalword2Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock1Area1.append(temp.BlockArea[i]); Totalword1Area1.append(temp.TotalWordArea[i] )
                                            Bbox1.append(temp.Bbox[j]) ;
                                            Bbox2.append(words_i[0:4]) ;
                                            Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                            Bbox2Cont.append(words_i[4])
                                            image_counter+=1
                                            if temp.BlockId[j]<temp.BlockId[i]:
                                                InteractionType.append('Text on Image')
                                                Insight.append('Overlaid Text box detected on existing Image')
                                                # print(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area))
                                                # print(temp.BlockArea[j],3)
                                                Flag.append(1)
                                                Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))
                                                #page1.draw_rect(temp.Bbox[j],  color = (1, 0, 0), width = 1)
                                                #page1.draw_rect(words_i[0:4],  color = (1, 0, 0), width = 1)
                                            else:
                                                InteractionType.append('Image on Text')
                                                Insight.append('Overlaid Image box detected on existing Text')
                                                Flag.append(1)
                                                Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Text'))
                                                                                
                                            pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))                                    
                                            # page1.draw_rect(temp.Bbox[j],  color = (1, 0, 0), width = 1)
                                            #print(temp.Bbox[j],fitz.Rect(temp.Bbox[j][0:4]).get_area())
                                            #print("4")
                                            # page1.draw_rect(words_i[0:4],  color = (1, 0, 0), width = 1)
                                            #print(temp.Bbox[i])




        df = pd.DataFrame(data={'Page_Num': PageNumber1,'Overlaid_Text_Bounding_Box':Bbox1,'Bounding_Box1_Type': BBox1Type,
                                'Original_Text_Bounding_Box':Bbox2,'Bounding_Box2_Type': BBox2Type,'Overlaid_Text':Bbox1Cont,
                                'Original_Text':Bbox2Cont,'Interaction_Type': InteractionType,
                                'Flag':Flag,'Severity_Level':Severity_Level,'Insight':Insight,'BoundingBlock1Area': BoundingBlock1Area1,
                                'Totalword1Area':Totalword1Area1,'BoundingBlock2Area':BoundingBlock2Area1,'Totalword2Area':Totalword2Area1})          

        return doc1, df
    @classmethod                                                                            
    def ElementOverlap(cls,filename,bankname,image_output_dir):
                                                                                
        try:
            doc = fitz.open(filename)
            # doc = fitz.open(stream = filename, filetype = 'pdf')
        except Exception as e:
            print(e)
            pass
            return 
        pdf_highlighting_coordinates = []

        df = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                   'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight'])
        
        final_temp = pd.DataFrame(columns=['Bbox','BlockText','BlockId','BlockType','Page_Num','BlockArea','TotalWordArea','WordLevelData','PageArea'])
        
        for Page_Number, Page in enumerate(doc):
            Page.wrap_contents()
            if Page.rotation==0:
                temp2 = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                    'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight','BoundingBlock1Area','Totalword1Area','BoundingBlock2Area','Totalword2Area'])

                BlockRect=[]; BlockText=[];BlockId=[]; BlockType = []; BlockPageno =[];BlockArea=[] ; TotalWordArea =[]; WordLevelData = [];PageArea = [];

                temp=pd.DataFrame(columns=['Bbox','BlockText','BlockId','BlockType','Page_Num','BlockArea','TotalWordArea','WordLevelData','PageArea'])
                image_block_counter = 0
                for text_block in Page.get_text('blocks'):
                    #print(Page_Number)
                    #print(Page.get_bboxlog())
                    if (text_block[-1]==0) and (len(set(text_block[4]).difference({'\n', ' '}))>0):
                        BlockPageno.append(Page_Number)
                        BlockRect.append(text_block[0:4])
                        BlockText.append(text_block[4])
                        BlockId.append(text_block[5])
                        BlockType.append(text_block[6])
                        BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                        WordAreaSum = 0
                        Word_block_list =[];
                        for word_block in Page.get_text('words'):
                            if word_block[5]+image_block_counter == text_block[5] and (len(set(text_block[4]).difference({'\n', ' '}))>0):
                                WordAreaSum = WordAreaSum + fitz.Rect(word_block[0:4]).get_area()
                                Word_block_list.append(word_block)
                        WordLevelData.append(Word_block_list)
                        TotalWordArea.append(WordAreaSum)
                        PageArea.append(Page.cropbox.get_area())

                    if (text_block[-1]==1):
                        BlockPageno.append(Page_Number)
                        BlockRect.append(text_block[0:4])
                        BlockText.append(text_block[4])
                        BlockId.append(text_block[5])
                        BlockType.append(1)
                        BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                        WordLevelData.append('It is an image')
                        TotalWordArea.append(fitz.Rect(text_block[0:4]).get_area())
                        image_block_counter +=1
                        PageArea.append(Page.cropbox.get_area())

                temp=pd.DataFrame(data={'Bbox': BlockRect, 'BlockText':BlockText,'BlockId':BlockId,'BlockType': BlockType,'Page_Num' : BlockPageno,'BlockArea': BlockArea,'TotalWordArea':TotalWordArea,'WordLevelData': WordLevelData,'PageArea':PageArea})
                #Page.wrap_contents()
                doc,temp2 = cls.check_relative_position_n_Draw_Box(doc, bankname, temp, Page_Number,image_output_dir,pdf_highlighting_coordinates)
                df = pd.concat([df, temp2], axis=0) 
                df.reset_index(inplace = True,drop=True)   
        return df, pdf_highlighting_coordinates

    @classmethod
    def OverlapMain(cls, filename, image_output_dir, bankname):
    # def OverlapMain(cls,filename,bank_name,path_intermediate,path_overlay,overlay_repo, final_report_insight,excel_df):
        a1=cls.ElementOverlap(filename,bankname,image_output_dir)
        if not (a1 is None):
            df1 = a1[0]
            pdf_highlighting_coordinates = a1[1]
            return df1,pdf_highlighting_coordinates
        else:
            print("overlay not detected")
            
    @classmethod
    def return_final_report(cls, df, final_report_insight):
        
        df1 = df
        df1['Module'] = 'Overlap'
        df1 = df1.drop(['Bounding_Box1_Type', 'Bounding_Box2_Type'], axis = 1)

        dfA = df1[['Page_Num','Overlaid_Text','Original_Text']]

        dfB = df1[['Interaction_Type','Flag','Severity_Level','Insight']]

        #generate json file for alerts
        df2 = df1[df1['Flag'] == 1][['Module','Insight','Severity_Level']]          
        df2.columns = ['Module','Alerts','Severity']        
        df2.drop_duplicates(keep= 'first', inplace=True)
        final_report_insight = pd.concat([final_report_insight,df2])
        final_report_insight.reset_index(inplace = True,drop=True)

        return dfA, dfB, final_report_insight, cls.overlay_error_list
    
    @classmethod
    def write_to_excel(cls, df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname, index=False)

            
            
if __name__ == '__main__':
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
    fraud_report_file_path = 'test/report.xlsx'
    image_overlap_dir = 'test/images/overlap'
    bank_names = ['Chase', 'Wells Fargo']
    bank_name = bank_names[1]
    element_overlap_output_pdf_path = 'test/pdf_files/element_overlap_output.pdf'
    df, pdf_highlighting_coordinates = Overlay.OverlapMain(input_next_module,
                                                            image_overlap_dir,bank_name)

    Overlay.draw_pdf(input_next_module, pdf_highlighting_coordinates,
                     element_overlap_output_pdf_path)
    
    df_a, df_b, final_report_insight = Overlay.return_final_report(
        df, final_report_insight)

    Overlay.write_to_excel(df_a, fraud_report_file_path,
                           'w', '5A.Overlay_Raw_Output')
    Overlay.write_to_excel(df_b, fraud_report_file_path,
                           'w', '5B.Overlay_Report')
    