import os
import numpy as np
import pandas as pd
import fitz
import warnings
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake


warnings.filterwarnings('ignore')


class Overlay:
    overlay_error_list = []
    
    @classmethod
    def get_iou(cls, r1, r2):

        try:
            # Co-ordinate system origin is assumed to be on top left corner of the screen.
            # coordinates of the area of intersection.
            x1 = np.maximum(r1[0], r2[0])
            y1 = np.maximum(r1[1], r2[1])
            x2 = np.minimum(r1[2], r2[2])
            y2 = np.minimum(r1[3], r2[3])

                # Different Areas
            area_of_intersection = (np.maximum(y2 - y1, np.array(0.0))) * (np.maximum(x2 - x1, np.array(0.0)))

            a1 = ((r1[3] - r1[1]) * (r1[2] - r1[0]))
            a2 = ((r2[3] - r2[1]) * (r2[2] - r2[0]))

            return [area_of_intersection/a1, area_of_intersection/a2, a1, a2]
        except:
            cls.overlay_error_list.append("Overlay: Input values are non numeric")
            # print('overlay_error_list-------',cls.overlay_error_list)
            return ''

    @staticmethod
    def Overall_Severity_Level(AreaPercentage1,AreaPercentage2,Interaction_type):
        if Interaction_type in ('Text on Image', 'Image on Text','Image on Image'):
            if AreaPercentage1< 0.5 and AreaPercentage2< 0.5:
                return('LOW')
            elif AreaPercentage1>=0.8 or AreaPercentage2>=0.8:
                return('HIGH')
            else:
                return('MEDIUM')
        elif Interaction_type == 'Text on Text':
            if AreaPercentage1>=0.8 or AreaPercentage2>=0.8:
                return('HIGH')
            else:
                return('MEDIUM')
        
    @staticmethod
    def get_expected_area(bankname, overlay_repo):
        if bankname == '':
            return ''
        
        df = overlay_repo
        try:
            Expected_area = df.loc[bankname]['Area']
            return Expected_area.tolist()
        except:
            return ''  
    
    @staticmethod
    def get_expected_coord1(bankname, overlay_repo):
        if bankname == '':
            return ''
        
        df = overlay_repo
        try:
            Expected_coord1 = df.loc[bankname]['Coord1']
            return Expected_coord1.tolist()
        except:
            return '' 

    @staticmethod
    def get_expected_coord2(bankname, overlay_repo):
        if bankname == '':
            return ''
        df = overlay_repo
        try:
            Expected_coord2 = df.loc[bankname]['Coord2']
            return Expected_coord2.tolist()
        except:
            return '' 
        
    @classmethod
    def is_within_threshold(cls, value,threshold,exp_value):
        try:
            return exp_value - threshold <= value <= exp_value + threshold
        except:
            cls.overlay_error_list.append("Overlay: Input values are non numeric")
            print('overlay_error_list-------',cls.overlay_error_list)
            return ''


    @classmethod
    def is_within_threshold_percent(cls, value,threshold,exp_value):
        try:
            return exp_value - threshold*exp_value <= value <= exp_value + threshold*exp_value
        
        except:
            cls.overlay_error_list.append("Overlay: Input values are non numeric")
            print('overlay_error_list-------',cls.overlay_error_list)
            return ''

            

    @classmethod
    def check_threshold_range_area(cls,value, threshold,expected_value):
        try:
            # print('-------value',value)
            result = [cls.is_within_threshold_percent(value,threshold,exp_value) for exp_value in expected_value]
            return any(x == True for x in result)
        except:
            cls.overlay_error_list.append("Overlay: Input values are non numeric")
            print('overlay_error_list-------',cls.overlay_error_list)
            return ''
          

    @classmethod
    def check_threshold_range_coord(cls,value, threshold,expected_value):
        try:
            result = [cls.is_within_threshold(value,threshold,exp_value) for exp_value in expected_value]
            return any(x == True for x in result)
        except:
            cls.overlay_error_list.append("Overlay: Input values are non numeric")
            print('overlay_error_list-------',cls.overlay_error_list)
            return ''

    @staticmethod
    def check_image_coordinates_within_20_percent_of_page_area(page_width, x1, x2):
        margin = 0.3 * page_width
        
        # if 0 <= x1 <= margin and (page_width - margin) <= x2 <= page_width:
        if x1 <= margin and (page_width - margin) <= x2:
            # print('-------1')
            return 1
        else:
            # print('-------0')
            # print('x1-----', x1)
            # print('margin-----', margin)
            # print('x2-----', x2)
            # print('(page_width - margin)-----', page_width - margin)
            
            return 0
    @staticmethod    
    def aspect_ratio(x1 , y1, x2, y2):
        width = x2 - x1
        height = y2 - y1
        min_value = min(width, height)
        if width == min_value:
            aspect_ratio = width/height
        else:
             aspect_ratio = height/width
        return aspect_ratio

        
    @classmethod
    def check_relative_position_n_Draw_Box(cls,doc1,bankname, temp, pn,image_output_dir, pdf_highlighting_coordinates,overlay_repo, PDF_type):
        
        temp = temp.sort_values(by='BlockArea')
        
        df1 = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                   'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight','BoundingBlock1Area','Totalword1Area','BoundingBlock2Area','Totalword2Area'])

        PageNumber1=[]; Bbox1=[]; BBox1Type=[]; Bbox2=[]; BBox2Type=[]; Bbox1Cont=[]; Bbox2Cont=[]; InteractionType = []
        Flag =[]; Severity_Level=[]; Insight=[]
        BoundingBlock1Area1 = []; Totalword1Area1 =[]; BoundingBlock2Area1 = []; Totalword2Area1 =[]
        page1 = doc1[pn]
        rect = page1.rect
        page_width = page1.rect.width
        
        Areas1 = temp.BlockArea 
        expected_area = cls.get_expected_area(bankname, overlay_repo)
        expected_coord1 = cls.get_expected_coord1(bankname, overlay_repo)
        expected_coord2 = cls.get_expected_coord2(bankname, overlay_repo)
        word_list = ['Capitec','Bank','Device','Branch','DOCUMENT','Document','470010', '9003', 'IN', 'OF', 'ERRORS', 'OR', 'QUESTIONS', 'ABOUT', 'NON-ELECTRONIC', 'FUNDS', 'TRANSFERS', '··', '·', '®', 'TRANSACTIONS:', '•', 'CASE', 'For', 'A', 'JOHNSON', 'Navigate', 'Business', 'Initiate', 'Deposits', '{', 'Additional', 'Your', 'Account', 'Checking', 'Statement', 'Deposits', '1', 'The Huntington National Bank is Member FDIC.\n', ', Huntington\n', 'and 24-Hour Grace\n', 'TM\n']
        
        def pullIMage(doc2,Page_Number,BIi,BIj,rcj,imgc,image_output_dir):
            save_location = image_output_dir
            ImageFileName = f"page_{Page_Number+1}_{imgc}_{BIi}_{BIj}.png"

            pix = doc2[Page_Number].get_pixmap(clip=rcj)
            
            if constants.IS_S3_PATH:
                image_bytes = pix.tobytes('png')
                write_to_data_lake(image_bytes,save_location + ImageFileName)
            else:
                pix.save(save_location + ImageFileName)

            return f"page_{Page_Number+1}_{imgc}_{BIi}_{BIj}.png"

        for i in range(temp.shape[0]-1):

            for j in range(i, temp.shape[0]):

                rci= fitz.Rect(temp.Bbox[i])
                rcj= fitz.Rect(temp.Bbox[j])

                bbaj = temp.BlockArea[j]; twaj = temp.TotalWordArea[j]
                bbai = temp.BlockArea[i]; twai = temp.TotalWordArea[i]
                image_counter = 1

                if temp.BlockArea[i] < 0.8* temp.PageArea[i] and temp.BlockArea[j] < 0.8* temp.PageArea[j]:
                    
                    if temp.TotalWordArea[i] > 0.3* temp.BlockArea[i] : 
                        iou = cls.get_iou(temp.Bbox[j], temp.Bbox[i])
                        if (iou[0] > 0.25 or iou[1] >0.25) and (i!=j) :
                            if temp.BlockType[j] == 0 and temp.BlockType[i] == 0:
                                
                                # print('i-------------------',temp.BlockText[i])
                                # print('j-------------------',temp.BlockText[j])
                                temp_words_i = temp.WordLevelData[i]
                                temp_words_j = temp.WordLevelData[j]
                                # print('i---',temp_words_i)
                                # print('j---',temp_words_j)
                                for words_i in temp_words_i:
                                    # iwa = temp.TotalWordArea[i]
                                    for words_j in temp_words_j :
                                        # jwa = temp.TotalWordArea[i]
                                        # if pn==0:
                                            # print('i-------------------',temp.BlockText[i])
                                            # print('j-------------------',temp.BlockText[j])
                                            # print('i---',words_i[4:5])
                                            # print('-----------')
                                            # print('j---',words_j[4:5])
                                        # print('coor---',words_i[0:4],words_j[0:4])
                                        iou = cls.get_iou(words_i[0:4],words_j[0:4])
                                        i_word_area = iou[2]
                                        j_word_area = iou[3]
                                        
                                        if i_word_area < j_word_area:
                                            thresh_i = 0.4 ; thresh_j = 0.3
                                        elif i_word_area > j_word_area:
                                            thresh_i = 0.3 ; thresh_j = 0.4
                                        else:
                                            thresh_i = thresh_j = 0.3
                                            
                                            
                                        if (iou[0] > thresh_i or iou[1] > thresh_j) and (words_i[4] != words_j[4]) and words_i[4] not in word_list and words_j[4] not in word_list:
                                            # print('-----------------------------1')
                                            # if pn == 1:
                                            # iwa, jwa = cls.get_iou_t(words_i[0:4],words_j[0:4]) 
                                            # print('words_i[4]------------------',[words_i[4]])
                                            # print('words_j[4]------------------',[words_j[4]])
                                            # print('iou[0]i------------------',iou[0])
                                            # print('iou[1]j------------------',iou[1])
                                            # print(iou[0],iou[1])
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                            Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                            BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                            Bbox1Cont.append(words_j[4])
                                            Bbox2Cont.append(words_i[4])
                                            InteractionType.append('Text on Text')
                                            Insight.append('Overlaid Text box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Text'))
                                            pdf_highlighting_coordinates.append((pn,words_j[0:4]))
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))
                                            temp.Bbox[i][0], temp.Bbox[i][2]

                            if temp.BlockType[j] == 0 and temp.BlockType[i] == 1 and not (cls.check_threshold_range_area(temp.BlockArea[i],0.1,expected_area)) and cls.aspect_ratio(temp.Bbox[i][0], temp.Bbox[i][1], temp.Bbox[i][2], temp.Bbox[i][3]
) > 0.03: # and temp.BlockArea[i]> = 65:
                                if not (cls.check_image_coordinates_within_20_percent_of_page_area(page_width, temp.Bbox[i][0], temp.Bbox[i][2])):
                                    # print('----------------------1',page1)
                                    if not (cls.check_threshold_range_coord(temp.Bbox[i][0],5,expected_coord1)):
                                        if not (cls.check_threshold_range_coord(temp.Bbox[i][1],5,expected_coord2)):
                                            temp_words_j = temp.WordLevelData[j]
                                            for words_j in temp_words_j:
                                                iou = iou = cls.get_iou(words_j[0:4],temp.Bbox[i])
                                                if (iou[0] > 0.3 or iou[1] >0.3):
                                                    PageNumber1.append(temp.Page_Num[i]+1) ; 
                                                    Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                                    Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                                    BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                                    BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                                    Bbox1Cont.append(words_j[4])
                                                    Bbox2Cont.append(pullIMage(doc1,pn,temp.BlockId[j],temp.BlockId[i],rci,image_counter,image_output_dir))
                                                    image_counter+=1
                                                    if temp.BlockId[j]>temp.BlockId[i] :
                                                        InteractionType.append('Text on Image')
                                                        Insight.append('Overlaid Text box detected on existing Image')
                                                        Flag.append(1)
                                                        Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))

                                                    else:
                                                        InteractionType.append('Image on Text')
                                                        Insight.append('Overlaid Image box detected on existing Text')
                                                        Flag.append(1)
                                                        Severity_Level.append(cls.Overall_Severity_LevelOverall_Severity_Level(iou[0],iou[1],'Image on Text'))

                                                    # pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                                    pdf_highlighting_coordinates.append((pn,words_j[0:4]))
                                                    pdf_highlighting_coordinates.append((pn,temp.Bbox[i]))
                                                    # print('-----------------------',temp.Bbox[i])


                            if temp.BlockType[j] == 1 and temp.BlockType[i] == 0 and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)) and cls.aspect_ratio(temp.Bbox[i][0], temp.Bbox[i][1], temp.Bbox[i][2], temp.Bbox[i][3]
) > 0.03:# and temp.BlockArea[j]>=65:
                                if not (cls.check_image_coordinates_within_20_percent_of_page_area(page_width, temp.Bbox[j][0], temp.Bbox[j][2])):
                                    # print('----------------------2',page1)
                                    if not (cls.check_threshold_range_coord(temp.Bbox[j][0],5,expected_coord1)) :
                                        # 
                                        if not (cls.check_threshold_range_coord(temp.Bbox[j][1],5,expected_coord2)) :
                                            
                                            temp_words_i = temp.WordLevelData[i]
                                            for words_i in temp_words_i:
                                                iou = iou = cls.get_iou(words_i[0:4],temp.Bbox[j])
                                                if (iou[0] > 0.3 or iou[1] >0.3):

                                                    PageNumber1.append(temp.Page_Num[i]+1) ; 
                                                    Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                                    Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                                    BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                                    BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                                    Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                                    # Bbox2Cont.append(temp.BlockText[i])
                                                    
                                                    Bbox2Cont.append(words_i[4])
                                                    image_counter+=1
                                                    if temp.BlockId[j]<temp.BlockId[i]:
                                                        InteractionType.append('Text on Image')
                                                        Insight.append('Overlaid Text box detected on existing Image')
                                                        Flag.append(1)
                                                        Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))
                                                    else:
                                                        InteractionType.append('Image on Text')
                                                        Insight.append('Overlaid Image box detected on existing Text')
                                                        Flag.append(1)
                                                        Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Text'))

                                                    pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                                    # print('-----------------------',temp.Bbox[j])
                                                    pdf_highlighting_coordinates.append((pn,words_i[0:4]))

                            if temp.BlockType[j] == 1 and temp.BlockType[i] == 1 and not PDF_type =='Scanned' and cls.aspect_ratio(temp.Bbox[i][0] , temp.Bbox[i][1], temp.Bbox[i][2], temp.Bbox[i][3]
) > 0.03 and cls.aspect_ratio(temp.Bbox[i][0] , temp.Bbox[i][1], temp.Bbox[i][2], temp.Bbox[i][3]
) > 0.03:# and temp.BlockArea[j]>=65 and temp.BlockArea[i]>=65:
                                if not(cls.check_threshold_range_area(temp.BlockArea[i],0.1,expected_area)) and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)):

                                    if temp.BlockArea[i] < 0.45* temp.PageArea[i] and temp.BlockArea[j] < 0.45* temp.PageArea[j] and (iou[0] > 0.7 or iou[1] > 0.7) :

                                        if not (cls.check_threshold_range_coord(temp.Bbox[i][0],5,expected_coord1)) and not (cls.check_threshold_range_coord(temp.Bbox[j][0],5,expected_coord1)):
                                            if not (cls.check_threshold_range_coord(temp.Bbox[i][1],5,expected_coord2)) and not (cls.check_threshold_range_coord(temp.Bbox[j][1],5,expected_coord2)):

                                                PageNumber1.append(temp.Page_Num[i]+1) ; 
                                                Bbox1.append(temp.Bbox[j]) ; BBox1Type.append(temp.BlockType[j])
                                                Bbox2.append(temp.Bbox[i]) ; BBox2Type.append(temp.BlockType[i])
                                                BoundingBlock1Area1.append(temp.BlockArea[j]); Totalword1Area1.append(temp.TotalWordArea[j])
                                                BoundingBlock2Area1.append(temp.BlockArea[i]); Totalword2Area1.append(temp.TotalWordArea[i])
                                                Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                                image_counter+=1
                                                Bbox2Cont.append(pullIMage(doc1,pn,temp.BlockId[j],temp.BlockId[i],rci,image_counter,image_output_dir))
                                                image_counter+=1
                                                InteractionType.append('Image on Image')
                                                Insight.append('Overlaid Image box detected on existing Image')
                                                Flag.append(1)
                                                Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Image'))

                                                pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                                pdf_highlighting_coordinates.append((pn,temp.Bbox[i]))
                                                # print('-----------------------',temp.Bbox[j])
                                                # print('-----------------------',temp.Bbox[i])

                    else:
                        #word vs block
                        temp_words_i = temp.WordLevelData[i]
                        for words_i in temp_words_i:
                            iou = iou = cls.get_iou(temp.Bbox[j],words_i[0:4])
                            if (iou[0] > 0.25 or iou[1] >0.25) and (i!=j) :              

                                if temp.BlockType[j]==0 :
                                    temp_words_j = temp.WordLevelData[j]
                                    words_i_list =[]
                                    for words_j in temp_words_j :
                                        iou = iou = cls.get_iou(words_i[0:4],words_j[0:4])
                                        if (iou[0] > 0.3 or iou[1] >0.3) and (i!=j) and (words_i[4] != words_j[4] and words_i[4] not in word_list and words_j[4] not in word_list) :
                                            # print('-----------------------------2')
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            BBox1Type.append(temp.BlockType[j])
                                            BBox2Type.append('Word_text')
                                            BoundingBlock2Area1.append(temp.BlockArea[j]); Totalword2Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock1Area1.append(temp.BlockArea[i]); Totalword1Area1.append(temp.TotalWordArea[i])
                                            Bbox1.append(words_j[0:4])
                                            Bbox2.append(words_i[0:4]) 
                                            Bbox1Cont.append(words_j[4])
                                            words_i_list.append(words_i[4])
                                            Bbox2Cont.append(words_i[4])
                                            InteractionType.append('Text on Text')
                                            Insight.append('Overlaid Text box detected on existing Text')
                                            Flag.append(1)
                                            Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Text'))
                                                                                
                                            pdf_highlighting_coordinates.append((pn,words_j[0:4]))
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))                                    

                                if temp.BlockType[j]==1 and not(cls.check_threshold_range_area(temp.BlockArea[j],0.1,expected_area)):
                                    # print('---------3',temp.BlockType[j]==1)
                                    if not(cls.check_threshold_range_coord(temp.Bbox[j][0],1,expected_coord1)):
                                        if not(cls.check_threshold_range_coord(temp.Bbox[j][1],1,expected_coord2)):
                                            PageNumber1.append(temp.Page_Num[i]+1) ; 
                                            BBox1Type.append(temp.BlockType[j])
                                            BBox2Type.append('Word_text')
                                            BoundingBlock2Area1.append(temp.BlockArea[j]); Totalword2Area1.append(temp.TotalWordArea[j])
                                            BoundingBlock1Area1.append(temp.BlockArea[i]); Totalword1Area1.append(temp.TotalWordArea[i] )
                                            Bbox1.append(temp.Bbox[j]) ;
                                            Bbox2.append(words_i[0:4]) ;
                                            Bbox1Cont.append(pullIMage(doc1,pn,temp.BlockId[i],temp.BlockId[j],rcj,image_counter,image_output_dir))
                                            Bbox2Cont.append(words_i[4])
                                            image_counter+=1
                                            if temp.BlockId[j]<temp.BlockId[i]:
                                                InteractionType.append('Text on Image')
                                                Insight.append('Overlaid Text box detected on existing Image')
                                                Flag.append(1)
                                                Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Text on Image'))

                                            else:
                                                InteractionType.append('Image on Text')
                                                Insight.append('Overlaid Image box detected on existing Text')
                                                Flag.append(1)
                                                Severity_Level.append(cls.Overall_Severity_Level(iou[0],iou[1],'Image on Text'))
                                                                                
                                            pdf_highlighting_coordinates.append((pn,temp.Bbox[j]))
                                            # print('-----------------------@@',temp.Bbox[j])
                                            pdf_highlighting_coordinates.append((pn,words_i[0:4]))                                    


        df = pd.DataFrame(data={'Page_Num': PageNumber1,'Overlaid_Text_Bounding_Box': Bbox1,'Bounding_Box1_Type': BBox1Type,
                                'Original_Text_Bounding_Box': Bbox2,'Bounding_Box2_Type': BBox2Type,'Overlaid_Text': Bbox1Cont,
                                'Original_Text': Bbox2Cont,'Interaction_Type': InteractionType,
                                'Flag': Flag,'Severity_Level': Severity_Level,'Insight': Insight,'BoundingBlock1Area': BoundingBlock1Area1,
                                'Totalword1Area': Totalword1Area1,'BoundingBlock2Area': BoundingBlock2Area1,'Totalword2Area': Totalword2Area1})          
        
        if len(df[df['Interaction_Type'] == 'Text on Text']) > 50:
            df = pd.DataFrame()
            pdf_highlighting_coordinates = []
        # if pn == 0:
        #     display(df)
        #     print(pdf_highlighting_coordinates)

        return df, pdf_highlighting_coordinates
    
    @classmethod                                                                            
    def ElementOverlap(cls,filename,bankname,image_output_dir,overlay_repo,PDF_type):
                                                                                
        try:
            doc = read_from_data_lake(filename)
            # PDF_type = pdf_type(filename)
        except Exception as e:
            print(e)
            pass
            return 
        pdf_highlighting_coordinates = []

        df = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                   'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight'])
        
        final_temp = pd.DataFrame(columns=['Bbox','BlockText','BlockId','BlockType','Page_Num','BlockArea','TotalWordArea','WordLevelData','PageArea'])
        certify_words = ["THE", "ORIGINAL", "OF", "THIS", "DOCUMENT", "WAS", "SEEN"]
        def skip_block(text_block, certify_words):
            # Check if all words in certify_words are present in text_block[4]
            for word in certify_words:
                if word not in text_block[4]:
                    return False
            return True
        for Page_Number, Page in enumerate(doc):
            Page.wrap_contents()
            if Page.rotation==0:
                temp2 = pd.DataFrame(columns=['Page_Num','Overlaid_Text_Bounding_Box','Bounding_Box1_Type','Original_Text_Bounding_Box',
                                    'Bounding_Box2_Type','Overlaid_Text','Original_Text','Interaction_Type','Flag','Severity_Level','Insight','BoundingBlock1Area','Totalword1Area','BoundingBlock2Area','Totalword2Area'])

                BlockRect=[]; BlockText=[];BlockId=[]; BlockType = []; BlockPageno =[];BlockArea=[] ; TotalWordArea =[]; WordLevelData = [];PageArea = []; certify_flag = [];

                temp=pd.DataFrame(columns=['Bbox','BlockText','BlockId','BlockType','Page_Num','BlockArea','TotalWordArea','WordLevelData','PageArea','certify_flag1'])
                
                
                
                
                # z = []
                # y = []
                image_block_counter = 0
                skip_next_three = 0
                
                word_block_id_count = len(set([item[5] for item in Page.get_text('words')]))
                # word_block_id_count = len(word_block_id)
                # text_block_id_count = Page.get_text('blocks')[-1][5]
                f_text_block_id = [item for item in Page.get_text('blocks') if '<image:' not in item[4] and (len(set(item[4]).difference({'\n', ' '}))>0)]
                text_block_id_count1 = len(f_text_block_id)
                # diff = abs(text_block_id_count1 - word_block_id_count)

                # print('word_block_id_count----------------', word_block_id_count)
                # print('text_block_id_count ---------------', text_block_id_count)   
                # print('text_block_id_count1 ---------------', text_block_id_count1)
                if text_block_id_count1 == word_block_id_count:
                    for text_block in Page.get_text('blocks'):
                        # print('---------------------',text_block[4])
                        if (text_block[-1]==0) and (len(set(text_block[4]).difference({'\n', ' '}))>0) and '*end*' not in text_block[4] and '*start*' not in text_block[4]:
                            if skip_next_three > 0:
                                skip_next_three -= 1
                                certify_flag.append(1)
                            else:
                                if skip_block(text_block, certify_words):
                                    skip_next_three = 2
                                    certify_flag.append(1)
                                else:
                                    certify_flag.append(0)
                            BlockPageno.append(Page_Number)
                            BlockRect.append(text_block[0:4])
                            BlockText.append(text_block[4])
                            BlockId.append(text_block[5])
                            BlockType.append(text_block[6])
                            BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                            WordAreaSum = 0
                            Word_block_list = []
                            for word_block in Page.get_text('words'):
                                if word_block[5]+image_block_counter == text_block[5] and (len(set(text_block[4]).difference({'\n', ' '}))>0):
                                    # if word_block[4] == t2 and (len(set(text_block[4]).difference({'\n', ' '}))>0):
                                    WordAreaSum = WordAreaSum + fitz.Rect(word_block[0:4]).get_area()
                                    Word_block_list.append(word_block)

                            WordLevelData.append(Word_block_list)
                            TotalWordArea.append(WordAreaSum)
                            PageArea.append(Page.cropbox.get_area())

                        if (text_block[-1]==1):
                            if skip_next_three > 0:
                                skip_next_three -= 1
                                certify_flag.append(1)
                            else:
                                if skip_block(text_block, certify_words):
                                    skip_next_three = 2
                                    certify_flag.append(1)
                                else:
                                    certify_flag.append(0)  

                            BlockPageno.append(Page_Number)
                            BlockRect.append(text_block[0:4])
                            BlockText.append(text_block[4])
                            BlockId.append(text_block[5])
                            BlockType.append(1)
                            BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                            WordLevelData.append('It is an image')
                            TotalWordArea.append(fitz.Rect(text_block[0:4]).get_area())
                            image_block_counter +=1
                            PageArea.append(Page.cropbox.get_area())
                           
                # elif text_block_id_count1 != word_block_id_count and diff<=1:
                else:
                    # print("check2--------------------------------")
                    for text_block in Page.get_text('blocks'):
                        if (text_block[-1]==0) and (len(set(text_block[4]).difference({'\n', ' '}))>0) and '*end*' not in text_block[4] and '*start*' not in text_block[4]:
                            if skip_next_three > 0:
                                skip_next_three -= 1
                                certify_flag.append(1)
                            else:
                                if skip_block(text_block, certify_words):
                                    skip_next_three = 2
                                    certify_flag.append(1)
                                else:
                                    certify_flag.append(0)
                            BlockPageno.append(Page_Number)
                            BlockRect.append(text_block[0:4])
                            BlockText.append(text_block[4])
                            BlockId.append(text_block[5])
                            BlockType.append(text_block[6])
                            BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                            WordAreaSum = 0
                            Word_block_list = []

                            Word_block_list = [text_block]
                            TotalWordArea.append(fitz.Rect(text_block[0:4]).get_area())
                            WordLevelData.append(Word_block_list)
                            PageArea.append(Page.cropbox.get_area())

                        if (text_block[-1]==1):
                            if skip_next_three > 0:
                                skip_next_three -= 1
                                certify_flag.append(1)
                            else:
                                if skip_block(text_block, certify_words):
                                    skip_next_three = 2
                                    certify_flag.append(1)
                                else:
                                    certify_flag.append(0)  

                            BlockPageno.append(Page_Number)
                            BlockRect.append(text_block[0:4])
                            # print('-----------------------------------------------',text_block[0:4])
                            BlockText.append(text_block[4])
                            BlockId.append(text_block[5])
                            BlockType.append(1)
                            BlockArea.append(fitz.Rect(text_block[0:4]).get_area())
                            WordLevelData.append('It is an image')
                            TotalWordArea.append(fitz.Rect(text_block[0:4]).get_area())
                            image_block_counter +=1
                            PageArea.append(Page.cropbox.get_area())
                    

                temp=pd.DataFrame(data={'Bbox': BlockRect, 'BlockText':BlockText,'BlockId':BlockId,'BlockType': BlockType,'Page_Num' : BlockPageno,'BlockArea': BlockArea,'TotalWordArea':TotalWordArea,'WordLevelData': WordLevelData,'PageArea':PageArea, 'certify_flag1':certify_flag})
                try:
                    temp1 = temp[temp['certify_flag1']==0]
                    temp1.reset_index(drop=True, inplace=True)
                except:
                    temp1 = temp.copy()
                # if Page_Number == 0:
                #     temp1.to_excel('ovarlay1.xlsx')
                temp2, pdf_highlighting_coordinates = cls.check_relative_position_n_Draw_Box(doc,bankname, temp1, Page_Number,image_output_dir,pdf_highlighting_coordinates,overlay_repo,PDF_type)
                
                df = pd.concat([df, temp2], axis=0) 
                df.reset_index(inplace = True, drop=True)
                # df.to_excel('ovarlay2.xlsx')
        return df,pdf_highlighting_coordinates
    
    @staticmethod
    def highlight_pdf(input_filename, highlight_coords, overlay_output_pdf_path):
        doc = read_from_data_lake(input_filename)
        for t in highlight_coords:
            page1 = doc[t[0]]
            page1.draw_rect(t[1],  color=(1, 0, 0), width=1)

        pdf_bytes = doc.write()
        write_to_data_lake(pdf_bytes, overlay_output_pdf_path)
    
    @classmethod
    def overlay_entry(cls, input_next_module, bank_name, path_overlay, PDF_type):

        final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
        excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
        # PDF_type = PDF_type
        try:
            
            try:
                overlay_repo = read_from_data_lake(constants.OVERLAY_REPOSITORY_PATH)
                # display(overlay_repo)
                overlay_repo.set_index('Bank name', inplace=True)
                overlay_repo = overlay_repo.fillna('')
                # display(overlay_repo)
            except:
                cls.overlay_error_list.append("Overlay: Overlay Repository excel is not present at path")
                print('overlay_error_list-------',cls.overlay_error_list)
                overlay_repo = pd.DataFrame(columns=['Bank name', 'Coordinate', 'Rounded_Coord1', 'Coord1', 'Coord2', 'Coord3', 'Coord4', 'Rounded_Area', 'Area', 'Image Analysis'])
                overlay_repo.set_index('Bank name',inplace = True)

            if len(bank_name) == 0:
                bank_name = 'default'

            a1 = cls.ElementOverlap(input_next_module, bank_name, path_overlay, overlay_repo, PDF_type)

            if not (a1 is None):
                # Get the DataFrame having the highlighting details.
                df1 = a1[0]
                df1['Module'] = 'Overlap'
                df1 = df1.drop(['Bounding_Box1_Type', 'Bounding_Box2_Type'], axis = 1)
                dfA = df1[['Page_Num','Overlaid_Text','Original_Text']]
                dfB = df1[['Interaction_Type','Flag','Severity_Level','Insight']]
                # display(dfA)
                # display(dfB)

                #generate json file for alerts
                df2 = df1[df1['Flag'] == 1][['Module','Insight','Severity_Level']]          
                df2.columns = ['Module','Alerts','Severity']        
                df2.drop_duplicates(keep= 'first', inplace=True)
                final_report_insight = pd.concat([final_report_insight,df2])
                final_report_insight.reset_index(inplace = True,drop=True)

                excel_df.loc[len(excel_df.index)] = [dfA, '5A.Overlay_Raw_Output']
                excel_df.loc[len(excel_df.index)] = [dfB, '5B.Overlay_Report']
            else:
                print("overlay not detected")
        except Exception as e:
            print(f"Error in Overlay module: {e}")
            cls.overlay_error_list.append(f"Overlay: Error {e}")
            final_report_insight = pd.DataFrame(columns=['Module', 'Alerts', 'Severity'])
            dfA = pd.DataFrame(columns=['Page_Num','Overlaid_Text','Original_Text'])
            dfB = pd.DataFrame(columns=['Interaction_Type','Flag','Severity_Level','Insight'])
            excel_df.loc[len(excel_df.index)] = [dfA, '4A.Overlay_Raw_Output']
            excel_df.loc[len(excel_df.index)] = [dfB, '4B.Overlay_Report']
            a1 = ['', []]
            

        return final_report_insight, excel_df, a1[1], cls.overlay_error_list
            
            
if __name__ == '__main__':
    import os
    path_overlay = 'output/Images/Overlay/'
    path_intermediate = 'output/Intermediate/'

    os.makedirs(os.path.dirname(path_overlay), exist_ok=True)
    os.makedirs(os.path.dirname(path_intermediate), exist_ok=True)

    input_next_module = os.path.join(
        path_intermediate, "annotation_output.pdf")
    overlay_output_pdf_path = os.path.join(
        path_intermediate, "overlay_output.pdf")
    pdf_filename_file = "wells fargo input.pdf"

    # input_next_module = os.path.join(
    #     constants.S3_DATA_PREFIX, 'input_data', 'Wells Fargo Tampered Input.pdf')
    # overlay_output_pdf_path = os.path.join(
    #     constants.S3_DATA_PREFIX, path_intermediate, "overlay_output.pdf")
    # path_overlay = os.path.join(
    #     constants.S3_DATA_PREFIX, "output", "Images", "Overlay")

    bank_names = ['wells fargo']
    final_report_insight, excel_df, highlight_coords = Overlay.overlay_entry(
        input_next_module, bank_names, path_overlay)
    Overlay.highlight_pdf(
        input_next_module, highlight_coords, overlay_output_pdf_path)
    print(final_report_insight)
    print(excel_df)
    