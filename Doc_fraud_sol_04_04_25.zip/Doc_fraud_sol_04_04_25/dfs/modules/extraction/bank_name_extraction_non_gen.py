import pandas as pd
import io
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, list_dir_files, write_to_data_lake

def bankname(input_json_filename, bankname=None):
    if bankname:
        return bankname

    try:
        input_json_data = read_from_data_lake(input_json_filename)
        json_pdf_bank_name_df = pd.DataFrame([])
        json_filename_col = input_json_data['job_id']
        pdf_filename_col = input_json_data['documents'][0]['filename'].split("/", 1)[0]
    except:
        bank_name_col = ''

    try:
        bank_name_col = input_json_data['results']['Account level'][0]['Bank_Name']
    except:
        bank_name_col = ''
    # file_df = pd.DataFrame(columns=['pdf_col', 'json_col', 'bank_name_col'])
    # file_df.loc[len(file_df.index)] = [pdf_filename_col, json_filename_col, bank_name_col]
    # json_pdf_bank_name_df = pd.concat([file_df, json_pdf_bank_name_df], axis=0)
    
    return bank_name_col


# def bankname(bankname):    
#     if bankname = None:
#         bank_name_col = None 
#     else:
#         bank_name_col = bankname 
#     return bank_name_col


def bankname_json_mapping(json_file_location, output_bank_excel_filename):
    s3_object_iterator = list_dir_files(json_file_location)
    keywordFilter = '.json'
    json_pdf_bank_name_df = pd.DataFrame([])

    for s3_object in s3_object_iterator:
        s3_object_key0 = s3_object.key
        if keywordFilter in s3_object_key0:
            data = read_from_data_lake(s3_object)

            json_filename_col = data['job_id']
            pdf_filename_col = (data['documents'][0]['filename'].split(
                "/", 1)[1]).split("/", 1)[1]
            try:
                bank_name_col = data['results']['Account level'][0]['Bank_Name']
            except:
                bank_name_col = ''
            file_df = pd.DataFrame(
                columns=['pdf_col', 'json_col', 'bank_name_col'])
            file_df.loc[len(file_df.index)] = [pdf_filename_col,
                                               json_filename_col, bank_name_col]
            json_pdf_bank_name_df = pd.concat(
                [file_df, json_pdf_bank_name_df], axis=0)

    json_pdf_bank_name_df = json_pdf_bank_name_df.fillna('')
    json_pdf_bank_name_df[''] = 0
    json_pdf_bank_name_df = json_pdf_bank_name_df.set_index('')

    with io.BytesIO() as bytes_io:
        json_pdf_bank_name_df.to_excel(bytes_io, index=False)
        bytes_data = bytes_io.getvalue()

    write_to_data_lake(bytes_data, output_bank_excel_filename)


if __name__ == '__main__':
    import os
    input_json_filename = 'core_v2/Bank_Statement_1.json'
    output_excel_filename = 'output/excel/bank_name.xlsx'
    os.makedirs(os.path.dirname(output_excel_filename), exist_ok=True)

    
    bank_names = bankname(input_json_filename)
    print(bank_names)
