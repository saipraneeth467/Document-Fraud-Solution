
# facebook vectorizationfrom langchain.chains.question_answering import load_qa_chain
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings  # for using HugginFace models
from langchain.document_loaders import TextLoader  # for textfiles
from pdf2image import convert_from_bytes
import cv2
import numpy as np
from transformers import pipeline
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain import HuggingFaceHub
from langchain.chains.question_answering import load_qa_chain
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
import fitz
import tempfile
import pandas as pd
from dfs.commons import constants
os.environ["HUGGINGFACEHUB_API_TOKEN"] = constants.HUGGINGFACEHUB_API_TOKEN

# Vectorstore: https://python.langchain.com/en/latest/modules/indexes/vectorstores.html
# Embeddings
# Create the vectorized db

os.environ["TOKENIZERS_PARALLELISM"] = constants.TOKENIZERS_PARALLELISM
embeddings = HuggingFaceEmbeddings()


def document_qa_flan(pdf, prompt, page='first'):

    extracted_text = ''
    with fitz.open(pdf) as doc:
        num_pages = doc.page_count
        if page == 'first':
            page = doc.load_page(0)
            extracted_text += page.get_text()
        elif page == 'last':
            page = doc.load_page(num_pages-1)
            extracted_text += page.get_text()
        else:
            for num in range(num_pages):
                page = doc.load_page(num)
                extracted_text += page.get_text()

    # Write the extracted text to a text file
    tmp = tempfile.NamedTemporaryFile()
    with open(tmp.name, 'w', encoding='utf-8') as f:
        f.write(extracted_text)
        f.seek(0)

    # Document Loader
    loader = TextLoader(tmp.name)
    documents = loader.load()
    # Text Splitter

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=300, chunk_overlap=10)

    docs = text_splitter.split_documents(documents)
    db = FAISS.from_documents(docs, embeddings)

    # Flan-t5-xxl
    llm = HuggingFaceHub(repo_id="google/flan-t5-xxl",
                         model_kwargs={"temperature": 0.05, "max_length": 1024})

    chain = load_qa_chain(llm, chain_type="stuff")

    docs = db.similarity_search(prompt)
    try:
        answer = chain.run(input_documents=docs, question=prompt)
    except:
        answer = ""
    return answer


def document_qa_layout(pdf, prompt):

    nlp = pipeline(
        "document-question-answering",
        model="impira/layoutlm-document-qa",
    )

    def pdf_to_image(pdf_path, page_number, dpi=300):
        images = convert_from_bytes(open(pdf_path, 'rb').read(), dpi=dpi)
        if 1 <= page_number <= len(images):
            cv_image = np.array(images[page_number - 1])
            return cv_image

    selected_image = pdf_to_image(pdf, 1)
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp_file:
        temp_file_path = temp_file.name

        if selected_image is not None:
            cv2.imwrite(temp_file_path, selected_image)

    result1 = nlp(temp_file_path, prompt)
    answer = result1[0]['answer']
    return answer


def get_LLM_outputs(pdf, prompt):
    outputs = []
    try:
        output1 = document_qa_flan(pdf, prompt, 'first')
        outputs.append(output1)
    except:
        print('first page failed')
    try:
        output2 = document_qa_flan(pdf, prompt, 'last')
        outputs.append(output2)
    except:
        print('last page failed')
    try:
        output3 = document_qa_layout(pdf, prompt)
        outputs.append(output3)
    except:
        print('image recognition failed')
    return outputs


def bankname(pdf, prompt):
    outputs = get_LLM_outputs(pdf, prompt)
    df = pd.read_excel(constants.BANK_REPOSITORY_PATH_GEN)
    df['LLM Output'] = df['LLM Output'].apply(lambda x: x.split(','))
    dics = df.set_index('Bank Name').T.to_dict('list')
    bank_name = []
    for key in dics.keys():
        values = dics[key][0]
        for output in outputs:
            for value in values:
                if value.lower() in output.lower() or value.replace(" ", "") in output.lower():
                    bank_name.append(key)
    if bank_name == []:
        print('Bank name not recognized')
        return ''
    result = []
    for bank in bank_name:
        if bank_name.count(bank) > 1:
            result.append(bank)
            return result
    for bank in bank_name:
        if bank_name.count(bank) == 1:
            result.append(bank)
    return result


if __name__ == '__main__':
    prompt = 'What bank is this?'
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    bank_names = bankname(input_next_module, prompt)
