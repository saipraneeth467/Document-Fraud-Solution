import os
import fitz
import pandas as pd
import re
from dfs.commons import constants
import numpy as np


class FontAnalysis:
    font_error_list = []
    @staticmethod
    def highlight(doc, df, page_num):
        from flair.data import Sentence
        from flair.models import SequenceTagger
        tagger = SequenceTagger.load("flair/ner-english")
        page = doc[page_num]
        for j in range(len(df['bbox'])):
            if 'Enespañd:' not in df['text'][j]:
                st = Sentence(df['text'][j])
                tagger.predict(st)
                et = list(df['bbox'][j])
                # if st.get_spans('ner') != []:
                highlight = page.add_highlight_annot(et)
                highlight.set_colors({"stroke":(1, 1, 0)})    # YELLOW
                highlight.update()        
        return doc

    @staticmethod
    def get_score(list_of_tags):
        if len(list_of_tags) == 0:
            return 1
        else:
            return 5

    @staticmethod
    def anomaly_insights(df_row):
        if df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1  :
            value = 'Style, size, and color anomaly detected in the same line'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Style and size anomaly detected in the same line'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 0:
            value = 'Style anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Style and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1:
            value = 'Size and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Color anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Size anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        else:
            value = ''
            severity_value = ''


        return value
    
    @staticmethod
    def severity_value(df_row):

        # df_row: anomaly dataframe with elements column
        # objective: to generate the final sheet with the type of anomaly flag set

        if df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1  :
            value = 'Style, size, and color anomaly detected in the same line'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Style and size anomaly detected in the same line'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 0:
            value = 'Style anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Style and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1:
            value = 'Size and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Color anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 0 and df_row['size_flag'] == 1 and df_row['color_flag'] == 0:
            value = 'Size anomaly detected'
            if df_row['Page'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        else:
            value = ''
            severity_value = ''


        return severity_value
    

    @classmethod
    def font_excel_format(cls, df):
        # df: final dataframe with all lines with anamoly for segment 1 and greater
        # objective: to create FONT REPORT excel with severity and elements anomaly flag for each row

        # filter the df for the below set of columns
        df = df[['ID', 'Page', 'Line', 'Num_Of_Segments', 'Text', 'Font', 'Size', 'Color']]
        df = df.iloc[::-1]
        df.reset_index(drop=True, inplace=True)

        # create a temp dataframe to group by the elements of each segment 
        df1 = df[df['Num_Of_Segments']!=1]
        df1['idx'] = df1.groupby('ID').cumcount()+1
        df1 = df1.pivot_table(index=['ID', 'Page', 'Line', 'Num_Of_Segments'], columns='idx', 
                                values=['Font', 'Size', 'Color', 'Text'], aggfunc='first')
        df1 = df1.sort_index(axis=1, level=1)
        df1.columns = [f'{x}_{y}' for x,y in df1.columns]
        df1 = df1.reset_index()

        df2 = df[df['Num_Of_Segments'] ==1]
        df2['idx'] = df2.groupby('ID').cumcount()+1
        df2 = df2.pivot_table(index=['ID', 'Page', 'Line', 'Num_Of_Segments'], columns='idx', 
                                values=['Font', 'Size', 'Color', 'Text'], aggfunc='first')
        df2 = df2.sort_index(axis=1, level=1)
        df2.columns = [f'{x}_{y}' for x,y in df2.columns]
        df2 = df2.reset_index()

        #creating final df
        df3 = pd.concat([df1, df2], ignore_index=True)

        df3['Font_Anomaly_Flag'] = df3['Num_Of_Segments'].apply(lambda x: 0 if x == 0 else 1)  

        # style flag
        df_style = df3.filter(like = 'Font', axis = 1)
        df_style = df_style.T.ffill().T
        df3['Font_Flag'] = df_style.eq(df_style.iloc[:, 0], axis=0).all(axis=1).astype(int)
        df3['Font_Flag'] = 1 - df3['Font_Flag']

        # size flag    
        df_size = df3.filter(like = 'Size', axis = 1)
        df_size = df_size.T.ffill().T
        df3['Size_Flag'] = df_size.eq(df_size.iloc[:, 0], axis=0).all(axis=1).astype(int)
        df3['Size_Flag'] = 1 - df3['Size_Flag']

        # color flag
        df_color = df3.filter(like = 'Color', axis = 1)
        df_color = df_color.fillna(0.0)
        df3['Color_Flag'] = (df_color.iloc[:,:-1] == 0.0).all(1).astype(int)
        df3['Color_Flag'] = 1 - df3['Color_Flag']

        # severity level along with the eloborated insights column which is generated using the anomaly_insights function
        #df3['severity_level'] = df3['font_anomaly_flag'].apply(lambda x: 'HIGH' if x == 1 else "")
        df3['Insight'] = 'Font Anomaly Detected'
        df3['Severity_Level']= df3.apply(cls.severity_value, axis = 1)
        df3['Insight_Elaborated'] = df3.apply(cls.anomaly_insights, axis = 1)

        return df3

    @staticmethod
    def get_expected_value(bankname):
        df = pd.read_excel(constants.FONT_REPOSITORY_PATH_GEN,
                           sheet_name='bank_level')
        df.set_index('Bank', inplace=True)
        df = df.fillna('')
        # all the repository values stored at backend
        try:
            expected_value = [df.loc[bankname]['font_style'],
                              df.loc[bankname]['font_size'], df.loc[bankname]['font_color']]
            return expected_value
        except Exception:
            x = ''
            y = ''
            z = ''
            return x, y, z

    @staticmethod
    def supressione(df,bankname):

        df['group_number'] = df.groupby(['line','page']).ngroup()

        string_list = ['*',' fnb.co.za','capitecbank.co.za','Customer VAT Registration Number','Bank VAT Registration Number','standardbank.co']
        df['flag'] = df['text'].apply(lambda x: any(substring in x for substring in string_list))
        df = df.groupby('group_number').filter(lambda x: not any ((x['flag'] ==1)))
        del df['flag']

        check_list = ['Cr','Kt',' Cr']
        df['flag'] = df['text'].apply(lambda x: 1 if x in check_list else 0)
        df = df.groupby('group_number').filter(lambda x: not any ((x['flag'] ==1) & (x['num_of_segments'] ==2)))

        # fileName = "/home/cai/anlsts_exl_isc_minerva_Sol_26_Document_fraud/anlsts_exl_isc_minerva_sol_dev_dfs/Sitaram/exl-ds-document-fraud-core_v2/document_fraud_detection/commons/config_files/supression_excel.xlsx"    
        sup_df = pd.read_excel(constants.SUPPRESION_EXCEL_PATH ,sheet_name='font')        
        sup_df = sup_df.fillna('')
        sup_df = sup_df[sup_df['Bank'] == f'{bankname}']
        sup_df.reset_index(drop=True, inplace=True)

        df = pd.merge(df, sup_df[['color', 'font', 'size', 'text']], how='left', indicator=True)
        #df['match'] = np.where(((df['color'].isin(sup_df['color'])) & (df['font'].isin(sup_df['font'])) & (df['size'].isin(sup_df['size'])) & (df['text'].isin(sup_df['text']))),1,0)
        df2 = df.groupby('group_number').filter(lambda x: not any ((x['_merge'] =='both') & (x['num_of_segments'] ==2)))
        df2 = df2[df2['_merge']!='both']
        del df2['_merge']

        if bankname == 'standard bank':
            sup_df = sup_df[sup_df['y1'] != '']
            df2['match'] = np.where((df2['y1'].isin(sup_df['y1'])),1,0)
            df2 = pd.merge(df2, sup_df[['y1']], how='left', indicator=True) 
            df2 = df2.groupby('group_number').filter(lambda x: not any (x['_merge'] =='both'))
            del df2['group_number'], df2['_merge']
        else:
            df2 = df2
            del df2['group_number']       
        return df2
        

    @staticmethod
    def font_analysis_seg(pdf_file):

        # pdf_file: the bank statement will go as in input for this function
        # objective: the objective is to analyse the font properties from a given pdf document and detect any inconsistency in a line and store the lines with the inconsistency into a dataframe

        # intializing
        page_num = []
        page_num_2 = []
        ids = []
        full_text = []
        num_of_segs = []

        # creating empty df
        df = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df1 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df2 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])

        # using FITZ library to read the pdf document
        doc = fitz.open(pdf_file)
        d1 = doc
        i = 0
        # Iterate over each page in the documentm
        page_count = 0
        id_count = 1
        for page in doc:
            page_count += 1
            blocks = page.get_text("dict")["blocks"]
            # Iterate over each block in the page
            for block in blocks:
                # Iterate over each line in the block
                try:
                    for line in block["lines"]:
                        count = 0
                        for elements in line['spans']:
                            if elements['text'] == ' ':
                                count += 1
                        text = ''
                        count_segments = 0
                        # when there is some change in the element property within in a line (count of segement > 1)
                        for elements in line['spans']:
                            if abs(len(line['spans']) - count) > 1:
                                #print(line['spans'])
                                if elements['text'] != ' ':
                                    count_segments += 1
                                    text = text + elements['text']
                                    df = pd.concat([pd.DataFrame([elements], columns=df.columns), df], ignore_index=True)



                                    # adding this page column to further call the document page wise at the highlight library highlight the anomaly in the document based on the page number passed
                                    df['page'] = page_count

                                    df2 = pd.concat([pd.DataFrame([elements], columns=df2.columns), df2], ignore_index=True)


                                    page_num.append(page_count)    


                        # appending line, page and segment information for each iteration across the document to further use to generate the output excel
                        if text != '':
                            for segments in range(count_segments):
                                full_text.append(text)
                                ids.append(str(page_count)+str(id_count))
                                page_num_2.append(page_count)
                                num_of_segs.append(count_segments)
                            id_count += 1
                except:
                    pass

            i += 1
            df1 = pd.concat([df, df1], axis=0)
            df1 = df1.assign(line = list(reversed(full_text)))

            df1.reset_index(drop=True, inplace=True)        
            df = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])

        # below condition for, when there will be no anomaly then also the function should return an empty df
        #df1 = df1.assign(line = list(reversed(full_text)))

        if not df1.empty:
            df1 = df1.copy()
        else:
            df1 = df1.iloc[:0].copy()
            df1.reset_index(drop=True, inplace=True)

        df1['font'] = df1['font'].apply(lambda x: re.sub('-Bold','',x))
        df1['font'] = df1['font'].apply(lambda x: re.sub(',Bold','',x))
        df1['font'] = df1['font'].apply(lambda x: re.sub('-Italic','',x))
        df1['font'] = df1['font'].apply(lambda x: re.sub('-Regular','',x))

        df1['size'] = df1['size'].round(2)
        df1 = df1.assign(num_of_segments = list(reversed(num_of_segs)))
        df1 = df1.assign(ID = list(reversed(ids)))
        df1 = df1.assign(page = list(reversed(page_num_2)))        


        return df1
    
    @staticmethod
    def check_value(x,ch_column,target_column):
        return str(x[ch_column]) in str(x[target_column])

    @classmethod
    def font_analysis_seg1(cls, pdf_file, bankname,font_repo):
        # pdf_file: the bank statement will go as in input for this function
        # bankname: the bank name input will come from the bank name extraction module and based on the bank name repository value will be used in the function
        # objective: the objective is to analyse the font properties from a given pdf document and detect any inconsistency in a line with respect to the repository value mainted at backend 
        # (in this function there will not be any change in the element style within a line and segemnt is always equals 1)

        # intializing
        page_num = []
        page_num_2 = []
        ids = []
        full_text = []
        num_of_segs = []

        # creating empty df
        df = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df2 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df1 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df3 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
        df4 = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])

        # using FITZ library to read the pdf document
        doc = fitz.open(pdf_file)
        d1 = doc
        i = 0
        # Iterate over each page in the document
        page_count = 0
        id_count = 1
        for page in doc:
            page_count += 1
            blocks = page.get_text("dict")["blocks"]
            # Iterate over each block in the page
            for block in blocks:
                # Iterate over each line in the block
                try:
                    for line in block["lines"]:
                        count = 0
                        for elements in line['spans']:
                            if elements['text'] == ' ':
                                count += 1
                        text = ''
                        count_segments = 0
                        # when there no change in the element property within a line (count of segement = 1)
                        for elements in line['spans']:
                            if abs(len(line['spans']) - count) == 1:
                                if elements['text'] != ' ': 
                                    count_segments += 1
                                    df = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])
                                    df = pd.DataFrame([elements], columns=df.columns)

                                    # adding this page column to further call the document page wise at the highlight library highlight the anomaly in the document based on the page number passed
                                    df['page'] = page_count

                                    # calling the get_expected_value function to get the repository value mainted for the bank at backend
                                    df['style_expected_value'] = cls.get_expected_value(bankname,font_repo)[0]
                                    df['size_expected_value'] = cls.get_expected_value(bankname,font_repo)[1]
                                    df['colour_expected_value'] = cls.get_expected_value(bankname,font_repo)[2]
                                    df['size'] = df['size'].round(2)

                                    #df['repo_ano_flag'] = df.apply(lambda x: repo_comp(x), axis=1)
                                    df['repo_ano_flag'] = (df.apply(cls.check_value,axis=1,args=('font','style_expected_value')) & df.apply(cls.check_value,axis=1,args=('size','size_expected_value')) & df.apply(cls.check_value,axis=1,args=('color','colour_expected_value')))


                                    df = df[(df['repo_ano_flag']==False) & (df['style_expected_value']!='') & (df['size_expected_value']!='') & (df['colour_expected_value']!='')]

                                    df = df.drop(['repo_ano_flag','style_expected_value','size_expected_value','colour_expected_value'], axis=1)
                                    text = elements['text']
                                    page_num.append(page_count)


                                    # below condition for, when there will be no anomaly then a new dataframe df3 gets created
                                    if not df.empty:
                                        df1 = pd.concat([df, df1], axis=0)
                                        df1.reset_index(drop=True, inplace=True)
                                        df2 = df1.copy()
                                    else:
                                        df3 = df

                        # appending line, page and segment information for each iteration across the document to further use to generate the output excel                
                        if text != '':
                            if not df.empty:
                                for segments in range(count_segments):
                                    full_text.append(text)
                                    ids.append(str(page_count)+str(id_count))
                                    page_num_2.append(page_count)
                                    num_of_segs.append(count_segments)
                                id_count += 1

                except:
                    pass

            i += 1
            df = pd.DataFrame(columns = ['size', 'flags', 'font', 'color', 'ascender', 'descender', 'text', 'origin', 'bbox'])

        # below condition for, when there will be no anomaly then also the function should return an empty df
        df1 = df1.assign(line = list(reversed(full_text)))    
        if not df1.empty:
            df4 = df1.copy()
            df4.reset_index(drop=True, inplace=True)
        else:
            df4 = df3.iloc[:0].copy()
            df4.reset_index(drop=True, inplace=True)

        df4['font'] = df4['font'].apply(lambda x: re.sub('-Bold','',x))
        df4['font'] = df4['font'].apply(lambda x: re.sub(',Bold','',x))
        df4['font'] = df4['font'].apply(lambda x: re.sub('-Italic','',x))
        df4['font'] = df4['font'].apply(lambda x: re.sub('-Regular','',x))

        df4 = df4.assign(num_of_segments = list(reversed(num_of_segs)))
        df4 = df4.assign(ID = list(reversed(ids)))
        df4 = df4.assign(page = list(reversed(page_num_2)))     

        return df4
    
    
    @staticmethod
    def font_sup(df):

        df1 = pd.DataFrame()
        df['group_number'] = df.groupby(['line','page']).ngroup()
        df['flag'] = np.where(((df['line'].shift(-1) == df['line']) &(df['size'].shift(-1) == df['size']) &(df['font'].shift(-1) == df['font']) &(df['color'].shift(-1) == df['color']) &(df['page'].shift(-1) == df['page'])), 1, 0)
        df['flag_1'] = np.where(((df['line'].shift() == df['line']) &(df['size'].shift() == df['size']) &(df['font'].shift() == df['font']) &(df['color'].shift() == df['color']) &(df['page'].shift() == df['page'])), 1, 0)    

        #display(df)

        for group in range (df['group_number'].nunique()):
            a = []
            b = []
            a_new = []
            b_new = []
            d = []
            c = []
            i = 0
            j = 0
            df2 = pd.DataFrame()
            df3 = pd.DataFrame()
            df2 = df[df['group_number']==group] 
            a = df2['flag'].to_list()
            b = df2['flag_1'].to_list()       
            for j in range(df2.shape[0]):
                c += [j]
            while i < (len(a)):
                if len(a)==2:
                    if a[i] == 1:
                        a_new = []
                        b_new = []
                        d = []
                        break
                    else:
                        a_new = a
                        b_new = b
                        d = c
                        break
                elif (i!=(len(a)-1)):
                    if a[i] == 0:
                        a_new += [a[i]]
                        b_new += [b[i]]
                        d += [c[i]]
                        i += 1
                    else:
                        if (i==(len(a)-2)):
                            a_new += [a[i]]
                            b_new += [b[i]]
                            d += [c[i]]
                            i += 1
                        else:
                            a_new += [a[i]]
                            b_new += [b[i]]
                            d += [c[i]]
                            i += 2
                else:
                    if b[i] == 1:
                        a_new.pop(len(a_new)-1)
                        b_new.pop(len(b_new)-1)
                        d.pop(len(d)-1)
                    else:
                        a_new += [a[i]]
                        b_new += [b[i]]
                        d += [c[i]]
                    break

            #del df['flag'], df['flag_1']

            df3 = df2.iloc[d]
            df1 = pd.concat([df3, df1], axis=0)
            df1.reset_index(drop=True, inplace=True)
        return df1    
    

    @classmethod
    def font_analysis(cls, input_file_path, bankname):
        #bank_name = bank_name[0]
        if bankname=='':
            bankname = 'default'
        else:
            bankname = bankname

        print(bankname)
        
        fileName_1 = '/home/cai/anlsts_exl_isc_minerva_Sol_26_Document_fraud/anlsts_exl_isc_minerva_sol_dev_dfs/Sitaram/exl-ds-document-fraud-core_v2/document_fraud_detection/commons/config_files/Font_Repository.xlsx'    
        font_repo = pd.read_excel(constants.FONT_REPOSITORY_PATH_GEN, sheet_name='bank_level') 
                

        # calling font_analysis_seg1 function to store the dataframe to highlight the anomaly related to segment 1 ( where the line elements are not matching with the font repo)         
        df_seg1 = cls.font_analysis_seg1(input_file_path,bankname,font_repo)
        if not df_seg1.empty:
            df_seg1 = df_seg1
        else:
            df_seg1 = df_seg1.iloc[:0].copy()

        df_seg = cls.font_analysis_seg(input_file_path)
        if not df_seg.empty:
            df_seg = df_seg
        else:
            df_seg = df_seg.iloc[:0].copy()        

        # creating final highlight and excel output dataframe
        df = pd.concat([df_seg, df_seg1], axis=0)
        df.reset_index(drop=True, inplace=True)


        if not df.empty:
            df['origin'] = df['origin'].astype(str)
            df['origin_1'] = df['origin'].str.replace(r'\(|\)', '', regex=True)
            df['y1'] = df['origin_1'].str.split(',').str[1].str.strip()
            df['y1'] = df['y1'].astype(float)
            df['y1'] = df['y1'].round(2)
            df = cls.supressione(df,bankname)
            del df['y1'], df['origin_1']
        else:
            df = df.iloc[:0].copy()   


        if not df.empty:
            df = cls.font_sup(df)
        else:
            df = df.iloc[:0].copy()

        df2 = df    
        return df, df2

    @classmethod
    def highlight_pdf(cls, input_file_path, df, highlighted_pdf_file_path):
        # using FITZ library to read the document
        doc = fitz.open(input_file_path)
        d1 = doc

        i = 0
        # Iterate over each page in the document
        k = 1
        for page in doc:
            df1 = df[df['page'] == k]
            df1.reset_index(drop=True, inplace=True)
            # calling the Highlight function for each of the page
            d1 = cls.highlight(d1, df1, i)
            i += 1
            k += 1

        # saving the highlighted pdf in the intermediate folder
        d1.save(highlighted_pdf_file_path)

    @classmethod
    def write_to_excel(cls, df, font_report, sheetnames, mode, fraud_report_file_path):
        # display(df)
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        font_report.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetnames[0], index=False)
            font_report.to_excel(writer, sheet_name=sheetnames[1], index=False)
            

    @classmethod
    def calculate_final_report_insight(cls, df2, final_report_insight, bankname):

        df2.reset_index(drop=True, inplace=True)

        if not df2.empty:
            df2.columns  = ['Size', 'Flags', 'Font', 'Color', 'Ascender', 'Descender', 'Text', 'Origin', 'Bbox', 'Page', 'Line', 'Num_Of_Segments', 'ID','Flag', 'group_number', 'flag_1']

            df2 = cls.font_excel_format(df2)
            # display(df2)        


            # calling the get_expected_value function to get the repository value to show in the final excel output
            df2['Style_Expected_Value'] = cls.get_expected_value(bankname)[0]
            df2['Size_Expected_Value'] = cls.get_expected_value(bankname)[1]
            df2['Colour_Expected_Value'] = cls.get_expected_value(bankname)[2]
            # display(df2)
            # fetching the required column
            font_report = df2[['ID','Page', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated']]
            #adding new column-Sr_no to the dataframe
            # font_report = font_report.rename_axis('Sr_No').reset_index()
            # font_report['Sr_No'] = font_report['Sr_No']+1


            df2 = df2.drop(['Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'], axis = 1)
            #adding new column-Sr_no to the dataframe
            # df2 = df2.rename_axis('Sr_No').reset_index()
            # df2['Sr_No'] = df2['Sr_No']+1
            #adding new column-Sr_no to the dataframe
            # df2 = df2.rename_axis('Sr_no').reset_index()
            # df2['Sr_no'] = df2['Sr_no']+1 

            # storing the output for the final excel workbook
            df3 = font_report[font_report['Font_Anomaly_Flag']== 1][['Insight', 'Severity_Level']]
            df3['Module'] = 'Font'
            df3 = df3.drop_duplicates('Insight', keep='first')
            df3.columns = ['Alerts','Severity','Module']
            df3 = df3[['Module','Alerts', 'Severity']]
            final_report_insight = pd.concat([final_report_insight,df3])
            return df2, font_report, final_report_insight, cls.font_error_list

        else:
            font_report = pd.DataFrame(columns = ['ID','Page', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'])
            #adding new column-Sr_no to the dataframe
            # font_report = font_report.rename_axis('Sr_No').reset_index()
            # font_report['Sr_No'] = font_report['Sr_No']+1

            #adding new column-Sr_no to the dataframe
            # df2 = df2.rename_axis('Sr_No').reset_index()
            # df2['Sr_No'] = df2['Sr_No']+1 

            df3 = font_report[font_report['Font_Anomaly_Flag']== 1][['Insight', 'Severity_Level']]
            df3['Module'] = 'Font'
            df3 = df3.drop_duplicates('Insight', keep='first')
            df3.columns = ['Alerts','Severity','Module']
            df3 = df3[['Module','Alerts', 'Severity']]
            final_report_insight = pd.concat([final_report_insight,df3])
            return df3, font_report, final_report_insight, cls.font_error_list


if __name__ == '__main__':
    final_report_insight_tst = pd.DataFrame(columns=['Alerts', 'Severity'])

    df, df2_seg, df2_seg1 = FontAnalysis.font_analysis(
        'document_fraud_detection/Wells_Fargo_Input.pdf',
        final_report_insight_tst,
        ['Chase', 'Wells Fargo'],
        'test/report.xlsx',
        'test/report.pdf'
    )
    sheetnames = ['3A.Font_Raw_Output', '3B.Font_Report'] #['2A.Font_Raw_Output', '2B.Font_Report']

    FontAnalysis.highlight_pdf(
        'document_fraud_detection/Wells_Fargo_Input.pdf', df, 'test/report.pdf')
    df3, font_report, final_report_insight = FontAnalysis.calculate_final_report_insight(df2_seg, df2_seg1,
                                                                                         'test/report.xlsx', final_report_insight_tst, ['Chase', 'Wells Fargo'])
    FontAnalysis.write_to_excel(
        df3, font_report, sheetnames, 'test/report.xlsx')
