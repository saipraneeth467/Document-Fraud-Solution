import os
import cv2
import math
import time
import tempfile
import pytesseract
import numpy as np
import pandas as pd
from PIL import Image
from io import BytesIO
from PIL import ImageDraw
from collections import Counter
from doctr.io import DocumentFile
from dfs.commons import constants
from doctr.models import ocr_predictor
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake

model = ocr_predictor(det_arch = 'db_resnet50',reco_arch = 'crnn_vgg16_bn', pretrained = True)
custom_config = r'--oem 3 --psm 6'

class FontAnalysis:
    font_error_list = []
    
    @staticmethod
     #Function to check if 2 words belong to same line or not
    def same_line_check(y1_current, y1_comparison, threshold):
        return abs(y1_current - y1_comparison) <= threshold

    @classmethod
    # Functio to convert all text extracted from image into dictionary. Each item corresponds to each line in image
    def image_info_to_lines_dict(cls,image_info_dict):
        
        lines_dict = {}
        line_number = 1

        # Sorting the words from text extracted from top to bottom
        words = list(image_info_dict.values())
        words.sort(key=lambda x: x['coordinates'][1])

        lines = []
        current_line = []
        threshold = 0

        for word in words:
            if not current_line:
                current_line = [word]
                threshold = (current_line[0]['height']) * 0.8
            else:
                if cls.same_line_check(word['coordinates'][1], current_line[0]['coordinates'][1], threshold = 50):
                    current_line.append(word)
                else:
                    lines.append(current_line)
                    current_line = [word]
                    threshold = (current_line[0]['height']) * 0.8

        if current_line:
            lines.append(current_line)

        for line in lines:
            line.sort(key=lambda x: x['coordinates'][0])
            for word_number, word in enumerate(line, start=1):
                lines_dict.setdefault(line_number, []).append({
                    'line_number': line_number,
                    'word_number': word_number,
                    'word_id': word.get('word_id', None), 
                    'word': word['word'],
                    'coordinates': word['coordinates'],
                    'height': word['height']
                })
            line_number += 1

        return lines_dict
    
    @staticmethod
    #Function to get the avg width of alphabet in a given word. Which can be used in threshold for space btw words
    def space_per_alphabet(lines_dict):
        for line in lines_dict.values():
            for word_dict in line:
                x1, y1, x2, y2 = word_dict['coordinates']
                space = abs(x2 - x1)
                space_per_alphabet = space / len(word_dict['word'])
                word_dict['space_per_alphabet'] = int(space_per_alphabet)
                
        return lines_dict
    
    @classmethod
    def lines_dict_to_sublines_dict(cls, lines_dict):
        
        # Sometimes each line contains multiple sublines 
        sublines_dict = {}
        
        # Space btw words determine whether they belong same subline or not
        lines_dict = cls.space_per_alphabet(lines_dict)
        
        # Creating sublines_dict
        for line_number, words in lines_dict.items():
            current_sub_line_number = 1
            current_line_words = []
            last_x2 = 0
            last_space_per_alphabet = 0

            for word_info in words:
                if not current_line_words:
                    current_line_words.append(word_info)
                else:
                    distance = word_info['coordinates'][0] - last_x2
                    threshold = last_space_per_alphabet * 3
                    if distance > threshold:
                        for word in current_line_words:
                            word['subline_number'] = f"{line_number}.{current_sub_line_number}"
                            sublines_dict.setdefault(line_number, []).append(word)
                        current_sub_line_number += 1
                        current_line_words = [word_info]
                    else:
                        current_line_words.append(word_info)

                last_x2 = word_info['coordinates'][2]
                last_space_per_alphabet = word_info['space_per_alphabet']

            for word in current_line_words:
                word['subline_number'] = f"{line_number}.{current_sub_line_number}"
                sublines_dict.setdefault(line_number, []).append(word)

        return sublines_dict

    @staticmethod
    def calculate_average_line_height(sublines_dict):
        distances = []
        keys = sorted(sublines_dict.keys())
        for i in range(len(keys) - 1):
            current_line_bottom_y = sublines_dict[keys[i]][-1]['coordinates'][3]
            next_line_top_y = sublines_dict[keys[i + 1]][0]['coordinates'][1]
            distance = next_line_top_y - current_line_bottom_y
            distances.append(distance)
        average_line_height = abs(sum(distances) / len(distances)) if distances else 0    
        return average_line_height

    @staticmethod
    #Function to group nearby lines into paragraphs
    def group_into_paragraphs(lines_dict, average_line_height):
        
        paragraph_number = 1
        
        #Sorting lines in dictionary based on line number
        keys = sorted(lines_dict.keys())
        
        # Threshold on horizontal side to differentiate paragraphs
        x_threshold = 60
        
        lines_dict_v1 = {}
    
        for key in keys:
            if lines_dict[key]:
                lines_dict_v1[key] = lines_dict[key]

        keys = sorted(lines_dict_v1.keys())

        for i, key in enumerate(keys):
            if i == 0:
                current_paragraph_number = paragraph_number
            else:
                # vertical and horizontal distances
                current_line_bottom_y = lines_dict_v1[keys[i-1]][0]['coordinates'][3]
                next_line_top_y = lines_dict_v1[key][0]['coordinates'][1]
                y_distance = abs(next_line_top_y - current_line_bottom_y)

                current_line_x1 = lines_dict_v1[keys[i-1]][0]['coordinates'][0]
                next_line_x1 = lines_dict_v1[key][0]['coordinates'][0]
                x_distance = abs(next_line_x1 - current_line_x1)

                # either the vertical or horizontal distance exceeds the thresholds
                y_threshold = average_line_height
                
                if y_distance > y_threshold or x_distance > x_threshold:
                    paragraph_number += 1

                current_paragraph_number = paragraph_number

            for word in lines_dict_v1[key]:
                word['paragraph_number'] = current_paragraph_number

        return lines_dict_v1

    @staticmethod
    def average_space(sublines_dict):
        spaces = []
        current_word_lengths = []
        keys = sorted(sublines_dict.keys())
        for i in range(len(keys)):

            current_line = sublines_dict[keys[i]]
            first_word = current_line[0]['word']

            current_word_x1 = current_line[0]['coordinates'][0] 
            current_word_x2 = current_line[0]['coordinates'][2]

            current_word_length = len(first_word)
            space = current_word_x2 - current_word_x1
            spaces.append(space)
            current_word_lengths.append(current_word_length)

        average_space_per_alphabet = abs(space / current_word_length) if current_word_length else 0
        return average_space_per_alphabet
    
    @staticmethod
    # Function to get avg color of the given word
    def word_color(image, word_cord):
        x1,y1,x2,y2 = word_cord
        # Extract the region of the document corresponding to the word
        word_region = image[y1:y2, x1:x2]
        # Calculate the average color
        avg_color = np.mean(image[y1:y2, x1:x2], axis=(0, 1), dtype=np.float32).astype(int)
        return avg_color
    
    @staticmethod
    def doctr_extremes(image):
        
        # Loading Doctr model and architechture that we will be using for extracting text
        #Saving the image in temporary location. So we can use this file_path for doctr
        with tempfile.NamedTemporaryFile(suffix=".png", delete=True) as tmp_file:
            image.save(tmp_file, format="PNG")
            tmp_image_path = tmp_file.name

        # Pass the temporary file path to Doctr for text extraction
            doc = DocumentFile.from_images([tmp_image_path])
        
        result = model(doc)
        output = result.export()
        width, height = image.size
        def convert_coordinates(geometry, page_dim):
            len_x = page_dim[1]
            len_y = page_dim[0]
            (x_min, y_min) = geometry[0]
            (x_max, y_max) = geometry[1]
            x_min = math.floor(x_min * len_x)
            x_max = math.ceil(x_max * len_x)
            y_min = math.floor(y_min * len_y)
            y_max = math.ceil(y_max * len_y)
            return [x_min, y_min, x_max,y_max]
        def get_coordinates(output):
            page_dim = output['pages'][0]["dimensions"]
            text_coordinates = []
            for obj1 in output['pages'][0]["blocks"]:
                for obj2 in obj1["lines"]:
                    for obj3 in obj2["words"]:                
                        converted_coordinates = convert_coordinates(obj3["geometry"],page_dim)

                        if len(obj3["value"])>1:
                            text_coordinates.append([converted_coordinates,obj3["value"]])
            return text_coordinates
        
        # Getting the coordinates of the text extracted from doctr
        coordinates = get_coordinates(output)
        
        # Getting the extreme coordinates out of the coordinates of text etxracted
        # These extreme coordinates are used for supressing any kind of anamolies we are getting from pytesseract due to its inaccurate text extraction
        
        if len(coordinates)>2:
            x1,y1 = min([i[0][0] for i in coordinates]), min([i[0][1] for i in coordinates])
            x2,y2 = max([i[0][2] for i in coordinates]), max([i[0][3] for i in coordinates])
        else:
            x1, y1, x2, y2 = 0,0,width,height
        
        extreme_coor = [x1,y1,x2,y2]
        return extreme_coor

    @classmethod
    def detect_misalignment(cls, cropped_image, sublines_dict, average_space_per_alphabet, no_words_list, extreme_coor):
        
        # Function to get average width of alphabet of given word
        def word_average_space(line):
            first_word = line[0]['word']
            current_word_x1 = line[0]['coordinates'][0] 
            current_word_x2 = line[0]['coordinates'][2]

            current_word_length = len(first_word)
            space = current_word_x2 - current_word_x1

            average_space_per_alphabet = abs(space / current_word_length) if current_word_length else 0
            return average_space_per_alphabet

        # Function to check if given words misaligning or not in the image
        def words_misalign_check(cropped_image, word1, word2):
            current_word_x1 = word1['coordinates'][0] 
            current_word_x2 = word1['coordinates'][2]
            space = current_word_x2 - current_word_x1
            average_space_per_alphabet = abs(space / len(word1)) if len(word1) else 0
            
            # Threshold to say if 2 words are misaligning or not
            threshold = average_space_per_alphabet

            #To check if they are same color
            color_check = "Different Color"
            word1_color = cls.word_color(cropped_image, word1["coordinates"])
            word2_color = cls.word_color(cropped_image, word2["coordinates"])

            if (abs(word1_color[0] - word2_color[0]) < 10) and (abs(word1_color[1] - word2_color[1]) < 10) and (abs(word1_color[2] - word2_color[2]) < 10):
                color_check = "Same Color"

            #To check if they are same size
            word_height_check = "Different Height"
            word1_height = word1['coordinates'][3] - word1['coordinates'][1]
            word2_height = word2['coordinates'][3] - word2['coordinates'][1]

            if abs(word1_height - word2_height) < 0.15*word1_height:
                word_height_check = "Same Height"

            word1_para = word1['paragraph_number']
            word2_para = word2['paragraph_number']

            x1_current = word1['coordinates'][0]
            x1_next = word2['coordinates'][0]
            x2_current = word1['coordinates'][2]
            x2_next = word2['coordinates'][2]

            text1 = word1['word']
            text2 = word2['word']

            # For checking if 2 words misaligning or not, we will check if they are left aligning or not based on x1 coordinate
            misalignment_difference = abs(x1_current - x1_next)
            
            #Conditions for checking misalignment btw 2 words
            """ 
            1. They should belong to same para
            2. Both words should be in similar color
            3. Both words should be in similar height
            
            If all these condtions meet then only we check for misalignment btw them using the threshold we define
            """
            
            if (misalignment_difference > threshold) and (word1_para == word2_para) and (misalignment_difference < 0.6*(x2_current + x2_next - x1_current - x1_next)):
                if abs(x2_next - x2_current) > 0.7*threshold and color_check == "Same Color" and word_height_check == "Same Height" and len(text2)>1 and (text1 != text2):
                    return True
                else:
                    return False
            else:
                return False
        
        # Fucntion to check if detected misaligned word is within doctr boundary or not. Because sometimes pytesseract reads random text and mark it as alert. So it is kind of supression
        def doctr_check(extreme_coor, word2_coordinates):
            i,j = word2_coordinates, extreme_coor
            if (i[0] > j[0] and i[2] < j[2]) and (i[1] > j[1] and i[3] < j[3]):
                return True
            else:
                return False
        
        # Defining all the lists that we save the misaligned coordinates and alerts 
        
        misaligned_lines = []
        alerts = []
        misaligned_coordinates = []
        misaligned_line_number = []
        paragraphs = {}
        # old_threshold = average_space_per_alphabet * 0.6
        lag = 2
        previous_misalignment_difference = None 

        # Organize lines into paragraphs
        for line_number, words in sublines_dict.items():
            paragraph_number = words[0]['paragraph_number']
            if paragraph_number not in paragraphs:
                paragraphs[paragraph_number] = []
            paragraphs[paragraph_number].append(words)

        # We check misalignment only btw 1st words of sublines. Because that only makes sense.
        # So creating a list contains these partcular words and info related to them.
        all_sublines_first_words = []
        for paragraph_number, paragraph_lines in paragraphs.items():
            paragraph_lines.sort(key=lambda line: line[0]['line_number'])
            for line in paragraph_lines:
                sublines_in_line = []
                subline_numbers = []
                for word in line:
                    subline_number = int(str(word["subline_number"]).split('.')[1])
                    if subline_number not in subline_numbers:
                        sublines_in_line.append(word)
                    subline_numbers.append(subline_number)
                all_sublines_first_words.append(sublines_in_line)

        line_no = 0
        
        while line_no < len(all_sublines_first_words)-1:
            
            current_line = all_sublines_first_words[line_no]
            next_line = all_sublines_first_words[line_no+1]
            
            # Checking if both lines have same no of sublines or not.
            if len(current_line) == len(next_line):
                for i in range(len(current_line)):
                    word1 = current_line[i]
                    word2 = next_line[i]
                    if words_misalign_check(cropped_image, word1, word2):
                        if word2['word'].lower() not in no_words_list and doctr_check(extreme_coor, word2['coordinates']):
                            misaligned_lines.append({
                                'current_line_text': ' '.join([word['word'] for word in current_line]),
                                'current_line_number': word1['line_number'],
                                'current_paragraph_number': word1['paragraph_number'],
                                'next_line_text': ' '.join([word['word'] for word in next_line]),
                                'next_line_number': word2['line_number'],
                                'next_paragraph_number': word2['paragraph_number'],
                                'x1_current': word1['coordinates'][0],
                                'x1_next':word2['coordinates'][0]
                            })
                            alerts.append([word1['word'],word2['word']])
                            misaligned_coordinates.append(word2['coordinates'])
                            misaligned_line_number.append(word2['subline_number'])
                        
            else:
                word1 = current_line[0]
                word2 = next_line[0]
                if words_misalign_check(cropped_image, word1, word2):
                    if word2['word'].lower() not in no_words_list and doctr_check(extreme_coor, word2['coordinates']):
                        misaligned_lines.append({
                            'current_line_text': ' '.join([word['word'] for word in current_line]),
                            'current_line_number': word1['subline_number'],
                            'current_paragraph_number': word1['paragraph_number'],
                            'next_line_text': ' '.join([word['word'] for word in next_line]),
                            'next_line_number': word2['subline_number'],
                            'next_paragraph_number': word2['paragraph_number'],
                            'x1_current': word1['coordinates'][0],
                            'x1_next':word2['coordinates'][0]
                        })
                        alerts.append([word1['word'],word2['word']])
                        misaligned_coordinates.append(word2['coordinates'])
                        misaligned_line_number.append(word2['subline_number'])
            line_no += 1

        return misaligned_line_number, misaligned_lines, alerts, misaligned_coordinates
                
    @classmethod
     # Function to identify all misalignments in the given image
    def misalignment(cls, image_path, cropped_image, image_blur_check,top_crop,pytess_output, font_output_image_path, extreme_coor):
        
        #Loading the image
        image = read_from_data_lake(image_path) 

        word_id = 0
        image_info_dict = {}
        
        result = pytess_output

        # Creating the dictionary based on pytesseract text extraction with words and coordinates
        for i in range(len(result['text'])):
            if not result['text'][i].strip():
                continue

            if int(result['conf'][i]) > 0 and len(result['text'][i]) > 1:
                x, y, w, h = result['left'][i], result['top'][i], result['width'][i], result['height'][i]
                word = result['text'][i]
                word_id += 1

                image_info_dict[word_id] = {
                    'word': word,
                    'coordinates': (x, y, x + w, y + h),
                    'height': h,
                    'word_id': word_id
                }

        # Creating lines_dict and sublines_dict
        lines_dict = cls.image_info_to_lines_dict(image_info_dict)
        sublines_dict = cls.lines_dict_to_sublines_dict(lines_dict)
        
        # In case no text is present or image is blurred. Then we dont perform detect_misalignment function
        if not lines_dict or not sublines_dict or image_blur_check == "Blurred":
            misaligned_line_number = []
            alerts = []
            misaligned_coordinates = []
            print("Misalignment: No text extracted from document")
            return misaligned_line_number, alerts, misaligned_coordinates

        average_line_height = cls.calculate_average_line_height(sublines_dict)

        final_lines_dict = cls.group_into_paragraphs(sublines_dict, average_line_height)
        # final_sublines_dict = cls.group_into_paragraphs(final_sublines_dict, average_line_height)

        average_space_per_alphabet = cls.average_space(sublines_dict)

        # Supression words list
        no_words_list = ["ending", "withdrawals", "withdrawals/debits", "10"]
        
        # Calling the detect_misalignment function, which detects all the misalignments in the image
        misaligned_line_number, misaligned_lines_dict, alerts, misaligned_coordinates = cls.detect_misalignment(cropped_image, final_lines_dict, average_space_per_alphabet, no_words_list, extreme_coor)
        
        #Supression Logics
        indices_to_remove = set()
        for i in range(len(misaligned_lines_dict)):
            for j in range(len(misaligned_lines_dict)):       
                #Logic to remove consecutive misalignments if they are in same paragraph
                subline1 = float(misaligned_lines_dict[i]["current_line_number"])
                subline2 = float(misaligned_lines_dict[j]["current_line_number"])
                para1 = float(misaligned_lines_dict[i]["current_paragraph_number"])
                para2 = float(misaligned_lines_dict[i]["current_paragraph_number"])
                if (i != j and para1 == para2 and abs(subline1 - subline2) == 1):
                    indices_to_remove.add(i) 

                # Logic to remove if same word is repeating in below other
                text1_1 = alerts[i][0]
                text1_2 = alerts[i][1]
                text2_1 = alerts[j][0]
                text2_2 = alerts[j][1]
                
                word_letter_space = (misaligned_coordinates[i][2] - misaligned_coordinates[i][0])/len(text1_1)
                x1_diff = abs(misaligned_coordinates[j][0] - misaligned_coordinates[i][0])
                x2_diff = abs(misaligned_coordinates[j][2] - misaligned_coordinates[i][2])
                if i != j and (text1_1 == text2_1 or text1_2 == text2_2) and (x1_diff < 2*word_letter_space and x2_diff < 2*word_letter_space):
                    indices_to_remove.add(i) 

        misaligned_line_number = [lst for k, lst in enumerate(misaligned_line_number) if k not in indices_to_remove]
        misaligned_lines_dict = [lst for k, lst in enumerate(misaligned_lines_dict) if k not in indices_to_remove]
        alerts = [lst for k, lst in enumerate(alerts) if k not in indices_to_remove]
        misaligned_coordinates = [lst for k, lst in enumerate(misaligned_coordinates) if k not in indices_to_remove]

        # If no of misalignments are more than 5. Then most likely it is template issue. Not highlighting any misalignments in those kind of images
        if len(alerts) > 5:
            misaligned_line_number = []
            alerts = []
            misaligned_coordinates = []
        
        draw = ImageDraw.Draw(image)
        adjusted_misaligned_coordinates = []
        for coordinates in misaligned_coordinates:
            adjusted_coordinates = (
                coordinates[0], coordinates[1] + top_crop,
                coordinates[2], coordinates[3] + top_crop
            )
            draw.rectangle(adjusted_coordinates, outline='yellow', width=5)
            adjusted_misaligned_coordinates.append(adjusted_coordinates)

        # image.save('output.png', format='PNG')
        new_output_folder = os.path.join(font_output_image_path, "Font_Output")
        if not constants.IS_S3_PATH:
            os.makedirs(new_output_folder, exist_ok=True)

        _, filename = os.path.split(image_path)
        file_base, file_extension = os.path.splitext(filename)
        new_filename = f"{file_base}_output{file_extension}"
        new_image_path = os.path.join(new_output_folder, new_filename)

        image_bytes = BytesIO()
        image.save(image_bytes, format='PNG')
        image_bytes.seek(0)
        write_to_data_lake(image_bytes.getvalue(), new_image_path)
        
        return misaligned_line_number, alerts, adjusted_misaligned_coordinates

    
    #=================================================================================================================================================

    @classmethod
    def extra_spaces(cls,cropped_image,image_blur_check,top_crop,pytess_output, font_output_image_path, extreme_coor):
        
        # Pytesseract Text extraction result
        result = pytess_output 
        word_coordinates = []

        for i in range(len(result['text'])):
            if not result['text'][i].strip():
                continue
        
            if int(result['conf'][i]) > 0:
                x, y, w, h = result['left'][i], result['top'][i], result['width'][i], result['height'][i]
                word = result['text'][i]
                word_coordinates.append({
                    'word': word,
                    'coordinates': (x, y, x + w, y + h),
                    'height' : h
                    })

         # Creating the dictionary based on pytesseract text extraction with words and coordinates
        image_info_dict = {}
        for idx, word_info in enumerate(word_coordinates):
            image_info_dict[f'word_{idx}'] = {
                'word': word_info['word'],
                'coordinates': word_info['coordinates'],
                'height': word_info['height']
            }
            
        # Function to convert lines into sublines and save them to dictionary
        def sub_lines_dict(lines_dict):

            new_lines_dict = {}  
            lines_dict = cls.space_per_alphabet(lines_dict)
            for line_number, words in lines_dict.items():
                current_sub_line_number = line_number
                sub_line_increment = 1  
                current_line_words = []  
                last_x2 = 0  
                last_space_per_alphabet = 0 

                for word_info in words:
                    if not current_line_words:
                        current_line_words.append(word_info)
                    else:
                        # Calculate the distance between the current word and the previous word
                        distance = word_info['coordinates'][0] - last_x2
                        # Set threshold to classify as same span(line) or not
                        threshold = last_space_per_alphabet * 4.5
                        if distance > threshold:
                            new_lines_dict[float(f"{line_number}.{sub_line_increment}")] = current_line_words
                            sub_line_increment += 1
                            current_line_words = [word_info]
                        else:
                            # else add the word to the current sub-line
                            current_line_words.append(word_info)

                    #Update for next loop
                    last_x2 = word_info['coordinates'][2]
                    last_space_per_alphabet = word_info['space_per_alphabet']

                new_lines_dict[float(f"{line_number}.{sub_line_increment}")] = current_line_words
            return new_lines_dict
        
        # Creating lines_dict and sub lines dict
        lines_dict = cls.image_info_to_lines_dict(image_info_dict)
        sub_lines_dict = sub_lines_dict(lines_dict)

        for key, words in sub_lines_dict.items():
            new_line_number = key
            for word in words:
                word['line_number'] = new_line_number 

        sub_lines_list = list(sub_lines_dict.values())
        
        def convert_coordinates_to_bounding_box(cord):
            (x1, y1), (x2, y2) = cord
            return x1, y1, x2, y2       
        
        def compare_bounding_box_with_adjacent_lines(bounding_box, line_number, words_data):
            # Extract bounding box coordinates
            x_min, y_min, x_max, y_max = bounding_box

            # Prepare a list to store the results
            results = []

            adjacent_lines = []
            if line_number - 1 in words_data:
                adjacent_lines.append(line_number - 1)
            if line_number + 1 in words_data:
                adjacent_lines.append(line_number + 1)

            # Check if there are any adjacent lines to process
            if not adjacent_lines:
                print(f"No adjacent lines found for line number {line_number}.")
                return pd.DataFrame()  # Return an empty DataFrame if no adjacent lines are found
            else:
                # Process each adjacent line
                # print(words_data)
                for adjacent_line in adjacent_lines:
                    word_data = words_data.get(adjacent_line, {})
                    for adjacent_line in adjacent_lines:
                        for word_data in words_data.get(adjacent_line, []):
                            word = word_data['word']
                            x1, y1, x2, y2 = word_data['coordinates']  # Unpack coordinates

                            # Compute differences
                            if adjacent_line < line_number:
                                diff_x_min = abs(x1 - x_min)
                                diff_y_min = abs(y_min - y2)
                                diff_x_max = abs(x2 - x_max)
                                # diff_y_max = abs(y_min - y2)
                            elif adjacent_line > line_number:
                                diff_x_min = abs(x1 - x_min)
                                diff_y_min = abs(y_max - y1)
                                diff_x_max = abs(x2 - x_max)

                            height_bbox, width_bbox = abs(y_max - y_min), abs(x_max - x_min)

                            # Store in results list
                            results.append({
                                "bounding_box": bounding_box, "line_number": adjacent_line,
                                "word": word, "word_coords": (x1, y1, x2, y2),
                                "diff_x_min": diff_x_min, "diff_y_min": diff_y_min,
                                "diff_x_max": diff_x_max,
                                # "diff_y_max": diff_y_max,
                                "height_bbox": height_bbox, "width_bbox": width_bbox
                            })

                    # Convert results to a DataFrame
                    df = pd.DataFrame(results)
                    return df


        def split_tampering(tampering_text):
            words = tampering_text.split()  # Split by space
            if len(words) >= 2:
                return words[0], words[1]
            else:
                return words[0], None
                
                # Filtering based on width and height of the words coming in above and below line of the extra space box
                df = df[(df['diff_y_min'] < df['height_bbox']*5)] # | (df['diff_x_max'] < df['width_bbox'])]
                df = df[(df['diff_x_min'] < df['width_bbox']*0.8) | (df['diff_x_max'] < df['width_bbox']*0.8)]
                
                return df

        def detect_extra_spaces(extreme_coor, new_lines_list, no_words_list):
            
            def doctr_check(extreme_coor, word2_coordinates):
                i,j = word2_coordinates, extreme_coor
                if (i[0] > j[0] and i[2] < j[2]) and (i[1] > j[1] and i[3] < j[3]):
                    return True
                else:
                    return False
            
            extra_space_btw_text = []
            Line_number = []
            extra_space_word = []
            Type = []
            Interaction_type = []
            Flag = []
            Severity_Level = []
            Insight = []
            Line_number_test = []
            extra_space_btw_text_test = []
            word_num = []
            word = []
            word_1 = []
            word_2 = []
            for i in new_lines_list:
                 # Perform spatial analysis to identify extra spaces between text
                if len(i) > 1:
                    for j in range(len(i) - 1):
                        Line_number_test.append(i[j]['line_number'])
                        word.append(i[j]['word'])
                        word_num.append(i[j]['word_number'])
                        
                        if len(i[j]['word'])>1 and len(i[j+1]['word'])>1 and not '|' in i[j]['word']:
                            max_space_threshold = int(i[j]['space_per_alphabet'])*1.6 #*1.8
                        else:
                            continue
                        x1, y1, x2, y2 = list(i[j]['coordinates'])
                        x1_next, y1_next,x2_next, y2_next = list(i[j+1]['coordinates'])
                        space_width = x1_next - x2
                        height_current = y2 - y1
                        height_next = y2_next - y1_next
                        height_diff = abs(height_current - height_next)
                        extra_space_btw_text_test.append([x1, y1 + top_crop, x2, y2 + top_crop])

                        # Check if the distance exceeds the threshold for extra space between text
                        if (space_width > max_space_threshold) and (height_diff < 5) and doctr_check(extreme_coor, list(i[j]['coordinates'])):
                            first_word = i[j]['word'].replace(".","").replace(",","")
                            if (len(first_word) <= 2 and first_word.isalpha()) or (first_word.lower() in no_words_list):
                                continue
                            if i[j]['word'][-1] == ":" and i[j+1]['word'].isalpha():
                                continue
                            # Add the coordinates of the extra space between text
                            extra_space_btw_text.append([(x2, y1 + top_crop), (x1_next, y2 + top_crop)])
                            word_1.append([x1, y1, x2, y2])
                            word_2.append([x1_next, y1_next,x2_next, y2_next])
                            Line_number.append(i[j]['line_number'])
                            extra_space_word.append(f"{i[j]['word']} {i[j+1]['word']}")
                            Type.append("Extra Space")
            
            df1 = pd.DataFrame({'Type' :Type , 'Line_number' :Line_number , 'Tampering' : extra_space_word, 'extra_space_btw_text_coor' : extra_space_btw_text,'Extra_space_genuinity': ["False" for i in range(len(extra_space_word))],'word_1_cord' : word_1,'word_2_cord' : word_2})                      
            df1['x1'] = df1['extra_space_btw_text_coor'].apply(lambda x: x[0][0])
            df1['x2'] = df1['extra_space_btw_text_coor'].apply(lambda x: x[1][0])

            df1 = df1.drop_duplicates(subset=['x1', 'x2'], keep=False)
            df1.reset_index(drop=True, inplace=True)

            df1=df1.sort_values(by='x1',ascending=True)
            
            df1 = df1.groupby('Line_number').filter(lambda x: len(x) < 3).sort_values(by='Line_number').reset_index(drop=True)

            df1['area'] = df1['x2'] - df1['x1']
            df1 = df1[df1["area"] >= 15]            
                        
            df1.drop(columns=['area'], inplace=True)
            df1 = df1.drop_duplicates(subset=['Tampering'], keep=False)

            line_anomalies = df1.values.tolist()
            
            anomalies = []
            extra_space_no = 0
            for i in line_anomalies:
                anomaly_line = int(i[1])
                cord = i[3]
                (x1, y1), (x2, y2) = cord
                # x, y, w, h = convert_coordinates_to_bounding_box(cord)
                x_min, y_min, x_max, y_max = convert_coordinates_to_bounding_box(cord)
                
                modified_dict = {}

                for key, value in lines_dict.items():
                    # Create a new list to store the modified data for this key
                    modified_list = []
                    for inner_dict in value:
                        line_number = float(inner_dict['line_number'])
                        inner_dict['line_number'] = int(line_number)
                        modified_list.append(inner_dict)
                    modified_dict[key] = modified_list                               
                
                df = compare_bounding_box_with_adjacent_lines(convert_coordinates_to_bounding_box(cord), anomaly_line, modified_dict)
                # if len(df) > 0:
                if not df1.empty:    
                    df1['Extra_space_genuinity'][extra_space_no] = "True"
                else:
                    df1['Extra_space_genuinity'][extra_space_no] = "False"
                extra_space_no += 1
                    
            df1 = df1[df1['Extra_space_genuinity']!= "False"]
            
            # not highlighting extra spaces if the number is alerts are more than 4 on a page
            if len(df1) > 4:
                df1 = pd.DataFrame()
            
            if not df1.empty:    
                extra_space_coor = list(df1['extra_space_btw_text_coor'])
            else:
                extra_space_coor = []
            
            if not df1.empty:
                df1[['word1', 'word2']] = df1['Tampering'].apply(lambda x: pd.Series(split_tampering(x)))
            else:
                df1 = df1.iloc[:0].copy()
                df1.reset_index(drop=True, inplace=True)            
            
            final_extra_space_coor = []
            words_color_check = []
            word1_colors = []
            word2_colors = []
            for index, row in df1.iterrows():
                word1_cord = row["word_1_cord"]
                word1_color = [int(i) for i in list(cls.word_color(cropped_image, word1_cord))]
                word1_colors.append(word1_color)
                
                word2_cord = row["word_2_cord"]
                word2_color = [int(i) for i in list(cls.word_color(cropped_image, word2_cord))]
                word2_colors.append(word2_color)
                
                if (abs(word1_color[0] - word2_color[0]) < 15) and (abs(word1_color[1] - word2_color[1]) < 15) and (abs(word1_color[2] - word2_color[2]) < 15):
                    words_color_check.append("Same Color")
                    final_extra_space_coor.append(extra_space_coor[index-1])
                else:
                    words_color_check.append("Different Color")
                    
            
            df1['words_color_check'] = words_color_check
            
            df1 = df1[df1['words_color_check']!= "Different Color"]
            
            for i in range(len(df1)):
                Interaction_type.append("Extra Space")
                Flag.append(1)
                Severity_Level.append('MEDIUM')
                Insight.append('Extra space found between two words')
            df2 = pd.DataFrame({'Interaction_Type' :Interaction_type , 'Flag' :Flag , 'Severity_Level' : Severity_Level, 'Insight': Insight})
            return final_extra_space_coor, df1, df2

        no_words_list = ["if", "it", "is", "po"]
        if image_blur_check == "Blurred":
            print("Extra Space: No text extracted from document")
            extra_space_coor = []
            df1 = pd.DataFrame()
            df2 = pd.DataFrame()
        else:
            extra_space_coor, df1, df2 = detect_extra_spaces(extreme_coor, sub_lines_list, no_words_list)

        return extra_space_coor, df1, df2
    

    @classmethod
    def font_data_entry(cls, input_next_module, font_output_image_path):
        
        misaligned_line_number_list = []
        alerts_list = []
        misaligned_coordinates_list = []
        extra_spaces_coor_list = []
        page_num = []
        df3 = pd.DataFrame()
        df4 = pd.DataFrame()

        for i, img_path in  enumerate(input_next_module):
            print('page_num: ', i+1)
            
            #Reading the image
            image = read_from_data_lake(img_path[2])   

            width, height = image.size
            height_non_cropped = height

            #Checking if the image is blurred or not based on resolution
            image_blur_check = "Blurred" if (width < 400 and height < 400) else "Not Blurred"

            # Cropping out the top 10% and bottom 10% of image before processing 
            top_crop, bottom_crop = height * 0.1, height * 0.9

            cropped_image_pil = image.crop((0, top_crop, width, bottom_crop))

            width, height = cropped_image_pil.size
            height_cropped = height

            # Using Pytesseract to extract text and coordinates. W
            pytess_output = pytesseract.image_to_data(cropped_image_pil, lang='eng', config=custom_config, output_type=pytesseract.Output.DICT)
        
            #Doctr to extract text. 
            extreme_coor = cls.doctr_extremes(cropped_image_pil)

            # Converting the copped image from PIL format to cv2 numpy array image 
            cropped_image = cv2.cvtColor(np.array(cropped_image_pil), cv2.COLOR_RGB2BGR)

            # Mislaignment detection
            misaligned_line_number, alerts, misaligned_coordinates = cls.misalignment(img_path[2], cropped_image,image_blur_check,top_crop,pytess_output, font_output_image_path, extreme_coor)
            
            print('misaligned_coordinates: ',misaligned_coordinates)
            
            #Extra space detection
            extra_spaces_coor, df1, df2 = cls.extra_spaces(cropped_image,image_blur_check,top_crop,pytess_output, font_output_image_path, extreme_coor)
            
            print('extra_spaces_coordinates: ', [[x1, y1, x2, y2] for [(x1, y1), (x2, y2)] in extra_spaces_coor])
            print()
            
            # collating result
            if misaligned_line_number:
                page_num.extend([int(i+1)]*len(misaligned_line_number))
                misaligned_line_number_list.extend(misaligned_line_number)
            if alerts:
                alerts_list.extend(alerts)
            if misaligned_coordinates:
                misaligned_coordinates1 = [(i, [x1 * img_path[0], y1 * img_path[1], x2 * img_path[0], y2 * img_path[1]]) for (x1, y1, x2, y2) in misaligned_coordinates]
                misaligned_coordinates_list.extend(misaligned_coordinates1)
            if extra_spaces_coor:
                extra_spaces_coor1 = [(i, [x1 * img_path[0], y1 * img_path[1], x2 * img_path[0], y2 * img_path[1]]) for [(x1, y1), (x2, y2)] in extra_spaces_coor]
                extra_spaces_coor_list.extend(extra_spaces_coor1)
            if len(df1):
                df1['Page_Num'] = [int(i+1)]*len(df1)
                df11 = df1[['Page_Num', 'Type', 'Line_number', 'Tampering']]
                df3 = pd.concat([df3, df11], ignore_index=True)
                del df1
            if len(df2):
                df2['Page_Num'] = [int(i+1)] * len(df2)
                df4 = pd.concat([df4, df2], ignore_index=True)
                
        
        if not extra_spaces_coor_list:
            extra_spaces_coor_list = []
        
        font_df = pd.DataFrame([])
        if misaligned_line_number_list and alerts_list:
            font_df['Line_number'] = misaligned_line_number_list
            font_df['Tampering'] = alerts_list
            font_df['Type'] = 'Misalignment'
            font_df['Page_Num'] = page_num
            font_df = font_df[['Page_Num', 'Type', 'Line_number', 'Tampering']]
        
        if len(font_df):
            font_report = pd.DataFrame({
            'Page_Num' : page_num,
            'Interaction_Type': font_df['Type'],
            'Flag': [1] * len(font_df),  
            'Severity_Level': ['MEDIUM'] * len(font_df), 
            'Insight': ['Text Misaligned'] * len(font_df)                
            })
            
        else:
            font_df = pd.DataFrame(columns=['Page_Num', 'Type', 'Line_number', 'Tampering'])
            font_report = pd.DataFrame(columns=['Interaction_Type', 'Flag', 'Severity_Level', 'Insight'])
            
        font_df = pd.concat([font_df, df3], ignore_index=True).sort_values(by='Page_Num').reset_index(drop=True)
        font_report = pd.concat([font_report, df4], ignore_index=True).sort_values(by='Page_Num').reset_index(drop=True)
        font_report = font_report[['Interaction_Type', 'Flag', 'Severity_Level', 'Insight']]
        
        return font_df, misaligned_coordinates_list, font_report, extra_spaces_coor_list, cls.font_error_list


if __name__ == "__main__":
    import os
    font_output_image_path = os.path.join("output", "images", "font")
    