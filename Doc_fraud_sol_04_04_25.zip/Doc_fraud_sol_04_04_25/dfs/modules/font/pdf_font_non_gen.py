import traceback
import time

import numpy as np
import pandas as pd
import fitz
from flair.data import Sentence
# from flair.models import SequenceTagger
import re
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake, bert_ner
from lingua import Language, LanguageDetectorBuilder
detector = LanguageDetectorBuilder.from_all_languages().build()
# tagger = SequenceTagger.load("flair/ner-english")


class FontAnalysis:
    font_error_list = []
    
    @staticmethod
    def extract_text(pdf_file):
        columns = ["size", "flags", "font","color", "ascender", "descender","text", "origin", "bbox","page", "line", "num_of_segments","ID"]
        
        df_basic = pd.DataFrame(columns=columns)
        # df1 = pd.DataFrame(columns=["size", "flags", "font","color", "ascender", "descender","text", "origin", "bbox", "page", "line", "ID"])

        # using FITZ library to read the pdf document
        doc = read_from_data_lake(pdf_file)
        
        process_all_pages = False
        first_page_df = pd.DataFrame(columns=columns)
        page = doc[0]
        blocks = page.get_text("dict")["blocks"]
        
        words_lt_3, words_gt_3 = 0,0
        # page_count = 0
        id_count = 1
        # num_segments = 1
        line_counter = 1
        
        for block in blocks:
            lines = block.get("lines", [])
            # Iterate over each line in the block
            # try:
            for line_idx, line in enumerate(lines):
                spans = line.get("spans", [])
                line_text = " ".join([span['text'] for span in spans])
                valid_spans = [span for span in spans if span['text'].strip()]
                total_valid_spans = len(valid_spans)
                
                # words = [word for word in line_text.split() if word.strip()]
                # all_words.extend(words)
                line_counter += 1

                for span_idx, span in enumerate(line.get("spans", []), start= 1):
                    if span["text"].strip():
                        word_length = len(span['text'].strip())
                        if word_length <3 :
                            words_lt_3 += 1
                        else:
                            words_gt_3 += 1

                        first_page_df = pd.concat([first_page_df, pd.DataFrame([{
                            'size' : round(span['size'], 2),
                            # 'span no.' : span_idx,
                            'flags' : span['flags'],
                            'font' : span['font'],
                            'color' : span['color'],
                            'ascender' : span['ascender'],
                            'descender' : span['descender'],
                            'text' : span['text'],
                            'origin' : span['origin'],
                            'bbox' : span['bbox'],
                            'page' : 1,
                            'line' : line_text,
                            'num_of_segments' : span_idx,
                            'ID' : line_counter
                        }])], ignore_index = True)
                            
        ratio = (words_lt_3/words_gt_3 if words_gt_3 else 1)
        
        if ratio <= 1:
            process_all_pages = True
            
        df_basic = pd.concat([df_basic, first_page_df], ignore_index = True)

        # Iterate over each page in the documentm

        
        for page_count, page in enumerate(doc):
            if ratio > 1 or page_count == 0:
                continue
            # page_count += 1
            blocks = page.get_text("dict")["blocks"]
            # Iterate over each block in the page
            for block in blocks:
                lines = block.get("lines", [])
                # Iterate over each line in the block
                # try:
                for line_idx, line in enumerate(lines):
                    spans = line.get("spans", [])
                    line_text = " ".join([span['text'] for span in spans])
                    line_counter += 1
                    
                    for span_idx, span in enumerate(line.get("spans", []), start= 1):
                        if span["text"].strip():
                            df_basic = pd.concat([df_basic, pd.DataFrame([{
                                'size' : round(span['size'], 2),
                                # 'span no.' : span_idx,
                                'flags' : span['flags'],
                                'font' : span['font'],
                                'color' : span['color'],
                                'ascender' : span['ascender'],
                                'descender' : span['descender'],
                                'text' : span['text'],
                                'origin' : span['origin'],
                                'bbox' : span['bbox'],
                                'page' : page_count + 1,
                                'line' : line_text,
                                'num_of_segments' : span_idx,
                                'ID' : line_counter,
                            }])], ignore_index = True)

        return df_basic, ratio
        
    @staticmethod
    def highlight(doc, df, page_num):
        page = doc[page_num]
        for j in range(len(df['bbox'])):
            if 'Enespañd:' not in df['text'][j]:
                st = Sentence(df['text'][j])
                # tagger.predict(st)
                et = list(df['bbox'][j])
                # if st.get_spans('ner') != []:
                highlight = page.add_highlight_annot(et)
                highlight.set_colors({"stroke": (1, 1, 0)})
                highlight.update()
        return doc

    @staticmethod
    def anomaly_insights(df_row):

        # df_row: anomaly dataframe with elements column
        # objective: to generate the final sheet with the type of anomaly flag set

        if df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1  :
            value = 'Style, size, and color anomaly detected in the same line'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Style and size anomaly detected in the same line'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 0:
            value = 'Style anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Style and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1:
            value = 'Size and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Color anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Size anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        else:
            value = ''
            severity_value = ''


        return value
    
    
    @staticmethod
    def severity_value(df_row):

        # df_row: anomaly dataframe with elements column
        # objective: to generate the final sheet with the type of anomaly flag set

        if df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1  :
            value = 'Style, size, and color anomaly detected in the same line'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 0:
            value = 'Style and size anomaly detected in the same line'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 0:
            value = 'Style anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 1 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Style and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 1 and df_row['Color_Flag'] == 1:
            value = 'Size and color anomaly detected in the same line'
            severity_value = 'MEDIUM'
        elif df_row['Font_Flag'] == 0 and df_row['Size_Flag'] == 0 and df_row['Color_Flag'] == 1:
            value = 'Color anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        elif df_row['Font_Flag'] == 0 and df_row['size_flag'] == 1 and df_row['color_flag'] == 0:
            value = 'Size anomaly detected'
            if df_row['Page_Num'] == 1:
                severity_value = 'HIGH'
            else:
                severity_value = 'LOW'
        else:
            value = ''
            severity_value = ''


        return severity_value
    

    @classmethod

        # filter the df for the below set of columns
    def font_excel_format(cls, df):

        # filter the df for the below set of columns
        df = df[['ID', 'Page_Num', 'Line', 'Num_Of_Segments', 'Text', 'Font', 'Size', 'Color', 'Tag']]
        df = df.iloc[::-1]
        df.reset_index(drop=True, inplace=True)

        # create a temp dataframe to group by the elements of each segment 
        df1 = df[df['Num_Of_Segments']!=1]
        df1['idx'] = df1.groupby('ID').cumcount()+1
        df1 = df1.pivot_table(index=['ID', 'Page_Num', 'Line', 'Num_Of_Segments', 'Tag'], columns='idx', 
                                values=['Font', 'Size', 'Color', 'Text'], aggfunc='first')
        df1 = df1.sort_index(axis=1, level=1)
        df1.columns = [f'{x}_{y}' for x,y in df1.columns]
        df1 = df1.reset_index()

        df2 = df[df['Num_Of_Segments'] ==1]
        df2['idx'] = df2.groupby('ID').cumcount()+1
        df2 = df2.pivot_table(index=['ID', 'Page_Num', 'Line', 'Num_Of_Segments', 'Tag'], columns='idx', 
                                values=['Font', 'Size', 'Color', 'Text'], aggfunc='first')
        df2 = df2.sort_index(axis=1, level=1)
        df2.columns = [f'{x}_{y}' for x,y in df2.columns]
        df2 = df2.reset_index()

        #creating final df
        df3 = pd.concat([df1, df2], ignore_index=True)
        

        df3['Font_Anomaly_Flag'] = df3['Num_Of_Segments'].apply(lambda x: 0 if x == 0 else 1)  


        # style flag
        df_style = df3.filter(like = 'Font', axis = 1)
        df_style = df_style.T.ffill().T
        df3['Font_Flag'] = df_style.eq(df_style.iloc[:, 0], axis=0).all(axis=1).astype(int)
        df3['Font_Flag'] = 1 - df3['Font_Flag']

        # size flag    
        df_size = df3.filter(like = 'Size', axis = 1)
        df_size = df_size.T.ffill().T
        df3['Size_Flag'] = df_size.eq(df_size.iloc[:, 0], axis=0).all(axis=1).astype(int)
        df3['Size_Flag'] = 1 - df3['Size_Flag']

        df_color = df3.filter(like = 'Color', axis = 1)
        df_color = df_color.fillna(0.0)
        df3['Color_Flag'] = (df_color.iloc[:,:-1] == 0.0).all(1).astype(int)
        df3['Color_Flag'] = 1 - df3['Color_Flag']

        # severity level along with the eloborated insights column which is generated using the anomaly_insights function
        df3['Insight'] = 'Font Anomaly Detected'
        df3['Severity_Level']= df3.apply(cls.severity_value, axis = 1)
        # Adding the 'severity' column
        # df3['Severity_Level'] = df3.apply(lambda row: 'HIGH' if pd.notna(row['Tag']) else row['Severity_Level'], axis=1)
        df3['Severity_Level'] = df3.apply(lambda row: 'HIGH' if row['Tag'] else row['Severity_Level'], axis=1)

        # Delete the column 'Tag' from DataFrame
        # df3.drop(columns=['Tag'], inplace=True)
        
        df3['Insight_Elaborated'] = df3.apply(cls.anomaly_insights, axis = 1)

        return df3

    @staticmethod
    def get_expected_value(bank_name, font_repo):
        df = font_repo
        try:
            expected_value = [df.loc[bank_name]['font_style'],
                              df.loc[bank_name]['font_size'], df.loc[bank_name]['font_color']]
            return expected_value
        except:
            x = ''
            y = ''
            z = ''
            return x, y, z
                

    @staticmethod
    def supressione(df, bank_name, sup_df):
        
        # rule specific to two banks to suppress the false +ve
        if bank_name == 'bok financial' or 'bank of oklahoma':
            pattern = r'^\d{2}-\d{2}$'
            # Drop rows where the 'details' column contains any text in the MM-DD format
            df = df[~df['text'].str.contains(pattern, na=False)]
        else:
            df = df    

        df['group_number'] = df.groupby(['line','page']).ngroup()

        string_list = ['*',' fnb.co.za','capitecbank.co.za','Customer VAT Registration Number','Bank VAT Registration Number','standardbank.co']
        df['flag'] = df['text'].apply(lambda x: any(substring in x for substring in string_list))
        df = df.groupby('group_number').filter(lambda x: not any ((x['flag'] ==1)))
        del df['flag']

        check_list = ['Cr','Kt',' Cr']
        df['flag'] = df['text'].apply(lambda x: 1 if x in check_list else 0)
        df = df.groupby('group_number').filter(lambda x: not any ((x['flag'] ==1) & (x['num_of_segments'] ==2)))
                    
        # if not sup_df.empty:
        df = pd.merge(df, sup_df[['color', 'font', 'size', 'text']], how='left', indicator=True)

        df2 = df.groupby('group_number').filter(lambda x: not any ((x['_merge'] =='both') & (x['num_of_segments'] ==2)))
        groups_to_drop = df2[df2['_merge'] == 'both']['group_number'].unique()
        df2 = df2[~df2['group_number'].isin(groups_to_drop)]
        # df2 = df2[df2['_merge']!='both']
        del df2['_merge'], df2['flag']

        if bank_name == 'standard bank':
            sup_df = sup_df[sup_df['y1'] != '']
            df2['match'] = np.where((df2['y1'].isin(sup_df['y1'])),1,0)
            df2 = pd.merge(df2, sup_df[['y1']], how='left', indicator=True) 
            df2 = df2.groupby('group_number').filter(lambda x: not any (x['_merge'] =='both'))
            del df2['group_number'], df2['_merge'], df2['match']
        else:
            df2 = df2
            del df2['group_number']       
        return df2
    
    @staticmethod    
    def remove_after_delimiters(word):
        # Split the word at the first occurrence of either '-' or ','
        split_char = None
        if '-' in word:
            split_char = '-'
        elif ',' in word:
            split_char = ','
        elif '_' in word:
            split_char = '_'
        elif ' ' in word:
            split_char = ' '            

        if split_char:
            # Split the word based on the detected delimiter
            parts = word.split(split_char, 1)
            # Return the part before the delimiter
            return parts[0]
        else:
            # If neither '-' nor ',' is present, return the original word
            return word

    @classmethod
    def font_analysis_seg(cls,df_basic):
        
        df1 = pd.DataFrame(columns=df_basic.columns)
         
        for line_text, line_df in df_basic.groupby('line'):
            unique_fonts = line_df['font'].nunique()
            unique_sizes = line_df['size'].nunique()
            unique_colors = line_df['color'].nunique()

            if unique_fonts > 1 or unique_sizes > 1 or unique_colors > 1:
                df1 = pd.concat([df1, line_df], ignore_index = True)
            
        return df1

    @staticmethod
    def check_value(x, ch_column, target_column):
        return str(x[ch_column]) in str(x[target_column])

    @classmethod
    def font_analysis_seg1(cls, df_basic, bank_name, font_repo, ratio):

        # pdf_file: the bank statement will go as in input for this function
        # bankname: the bank name input will come from the bank name extraction module and based on the bank name repository value will be used in the function
        # objective: the objective is to analyse the font properties from a given pdf document and detect any inconsistency in a line with respect to the repository value mainted at backend
        # (in this function there will not be any change in the element style within a line and segemnt is always equals 1)

        # intializing
        page_num = []
        page_num_2 = []
        ids = []
        full_text = []
        num_of_segs = []
        id_count = 1
        
        # d1f, df1, ratio = cls.font_analysis_seg(pdf_file)
        if df_basic.empty:
            return df_basic
        
        if ratio > 1 :
            return pd.DataFrame()
        

        # calling the get_expected_value function to get the repository value mainted for the bank at backend
        df_basic['original index'] = df_basic.index
        df_basic['style_expected_value'] = cls.get_expected_value(bank_name, font_repo)[0]
        df_basic['size_expected_value'] = cls.get_expected_value(bank_name, font_repo)[1]
        df_basic['colour_expected_value'] = cls.get_expected_value(bank_name,font_repo)[2]
        # df1['size'] = df1['size']
 
                                    # df['repo_ano_flag'] = df.apply(lambda x: repo_comp(x), axis=1)
        df_basic['repo_ano_flag'] = df_basic.apply(cls.check_value, axis=1, args=('font', 'style_expected_value')) & df_basic.apply(
                                        cls.check_value, axis=1, args=('size', 'size_expected_value')) & df_basic.apply(cls.check_value, axis=1, args=('color', 'colour_expected_value'))

        
        filtered_indexes = df_basic[(df_basic['repo_ano_flag'] == False) & (df_basic['style_expected_value'] != '') & (
            df_basic['size_expected_value'] != '') & (df_basic['colour_expected_value'] != '')]
        
        df4 = filtered_indexes.copy()
        df4 = df4.drop(['repo_ano_flag', 'style_expected_value','size_expected_value', 'colour_expected_value', 'original index'], axis=1)

        for index, row in df4.iterrows():
            text = row['text']
            page_count = row['page']
            # if text.strip() != '':
            num_of_segments = 1
            full_text.append(text)
            ids.append(str(page_count)+ str(id_count))
            page_num_2.append(page_count)
            num_of_segs.append(num_of_segments)
            id_count +=1                         
        
        df4['font'] = df4['font'].apply(cls.remove_after_delimiters)
        # num_of_segs = num_of_segs[:len(df4)]
        df4 = df4.assign(num_of_segments=num_of_segs)
        df4 = df4.assign(ID=ids)
        df4 = df4.assign(page=page_num_2)
        return df4

    @staticmethod
    def font_sup(df):

        # Sort the DataFrame based on group_number and other relevant columns
        df['group_number'] = df.groupby(['line','page']).ngroup()
        # Specify columns to compare
        columns_to_compare = ['size', 'font','color','page','line']
        # Iterate over each group
        for group_name, group_data in df.groupby('group_number'):
            previous_row = None
            rows_to_drop = []
            # Iterate over rows within the group
            for index, row in group_data.iterrows():
                # Check if the current row is the same as the previous row in the specified columns
                if previous_row is not None and all(row[col] == previous_row[col] for col in columns_to_compare):
                    # If yes, mark the current row to be dropped
                    rows_to_drop.append(index)
                # Update previous_row for the next iteration
                previous_row = row
            # Drop the rows marked for deletion
            df.drop(rows_to_drop, inplace=True)
            
        #drop rows where superscript word found..(logic-if the ratio of highest to lowest value from size columns is in the range of 1.6 to 1.71 drop that group from df)
        grouped = df.groupby('group_number')['size'].agg(['max', 'min'])
        grouped['ratio'] = grouped['max'] / grouped['min']
        valid_groups = grouped[~grouped['ratio'].between(1.5, 1.71)].index
        df = df[df['group_number'].isin(valid_groups)]
        # Reset index
        df.reset_index(drop=True, inplace=True)
        group_counts = df['group_number'].value_counts()
        df['group_count'] = df['group_number'].map(group_counts)
        # apply condition to drop the rows if the group count is 1 and segment is greater than 1
        df1 = df[~((df['num_of_segments'] > 1) & (df['group_count'] == 1))]
 
        return df1  
    
    @staticmethod
    def is_invalid_text(text):
        text = text.strip()
        if pd.isna(text) or text.strip() == '':
            return True
        if len(text) == 1:
            return True
 
        if len(text) == 1 and re.fullmatch(r'[!~\-:\'\s,]', text):
            return True
        # Define patterns to exclude from special character check
        exclude_patterns = [r'\baccount number\b']
 
        # Check for exclusion patterns
        for pattern in exclude_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return False
 
        if re.search(r'[[!~\-]]', text):
            return True        
 
        return False

    @staticmethod
    def should_drop(text):
        if isinstance(text, str):  # Ensure the value is a string
            text_cleaned = text.strip().replace(' ', '')  # Clean spaces
            condition1 = text_cleaned.isupper() and len(text_cleaned) in [2]
            condition2 = '®' in text
            condition3 = '®' in text
            return condition1 or condition2 or condition3
        return False

    @staticmethod
    def determine_lang(text):
        filtered_text = re.sub(r'\b\d+\b', '', text)
        filtered_text = re.sub(r'\b\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}\b', '', filtered_text)
        filtered_text = re.sub(r'[^a-zA-Z\s]', '', filtered_text)
        try:
            language = detector.detect_language_of(filtered_text)
        except Exception as e:
            print(f"An error occurred: {e}")
        return language.name if language else 'Unknown'
        
    @classmethod
    def process_pdf(cls, file_path):
        doc = read_from_data_lake(file_path)
        first_page = doc.load_page(0)
        page_height = first_page.rect.height
        page_width = first_page.rect.width  

        top_bbox = fitz.Rect(0, 0, page_width, page_height * 0.2)
        middle_bbox = fitz.Rect(0, page_height * 0.4, page_width, page_height * 0.6)
        bottom_bbox = fitz.Rect(0, page_height * 0.8, page_width, page_height)

        top_text = first_page.get_text("text", clip=top_bbox)
        middle_text = first_page.get_text("text", clip=middle_bbox)
        bottom_text = first_page.get_text("text", clip=bottom_bbox)

        top_20_words = ' '.join(top_text.split()[:20])
        middle_20_words = ' '.join(middle_text.split()[:20])
        bottom_20_words = ' '.join(bottom_text.split()[:20])
        
        top_language = cls.determine_lang(top_20_words)
        middle_language = cls.determine_lang(middle_20_words)
        bottom_language = cls.determine_lang(bottom_20_words)
        # Select majority language
        languages = [top_language, middle_language, bottom_language]
        # if unknown count is 2 then select third one else majority
        unknown_count = languages.count('Unknown')
        if unknown_count == 2:
            language = next((lang for lang in languages if lang != 'Unknown'), 'Unknown')
        else:
            language = 'Unknown' if len(set(languages))==3 else max(set(languages), key=languages.count)

        # Match top 40% text with the afrikaans word list  
        if language == 'Unknown' and word_count >= 50:
            top_40_bbox = fitz.Rect(0, 0, page_width, page_height * 0.4)
            top_40_text = first_page.get_text("text", clip=top_40_bbox).lower()
            afrikaans_words = {"terug","stuur","tjekrekeningnommer","vereffenin",
                                "saldo","oorgedra","krediete","debiete","transaksie",
                                "debietrente","privaatsak"}
            if any(word in top_40_text for word in afrikaans_words):
                language = 'Afrikaans'
                
        return language
    
    
    @staticmethod
    def extract_entities(words):
        tags = []
        date_pattern = re.compile(r'(\b(?:\d{1,2}/\d{1,2}|\d{1,2}/\d{2,4}|\d{1,2}\s[A-Za-z]{3}|\d{1,2}\s[A-Za-z]{3,9},\s?\d{1,2},\s\d{4}|[A-Za-z]{3,9}\s\d{1,2},\s\d{4}|[A-Za-z]{3,9}\s\d{4})\b)')
        money_pattern = re.compile(r'(\$?\d{1,3}(?:[ ,]\d{3})*\.\d{2}(?!\d)|\$\d{1,3}(?:[ ,]\d{3})*)')
        percent_pattern = re.compile(r'\d+(\.\d+)?%')
        pobox_pattern = re.compile(r'P\s?\.\s?O\s?\.\s?Box')
        acc_no_pattern = re.compile(r'^^X{8}(\s|-)\d{4}$|^X-\d{3}-\d{4}-\d{4}$')

        for word in words:
            date_matches = date_pattern.findall(word)
            money_matches = money_pattern.findall(word)
            percent_matches = percent_pattern.findall(word)
            pobox_matches = pobox_pattern.findall(word)
            acc_no_matches = acc_no_pattern.findall(word)
            
            if acc_no_matches:
                tags.append("Account Number")
            elif date_matches:
                tags.append("DATE")
            elif money_matches:
                tags.append("MONEY")
            elif pobox_matches:
                tags.append("I-LOC")
            else:
                entities = bert_ner(word)
                if entities:
                    main_entity = entities[0]
                    tags.append(main_entity['entity'])
                else:
                    tags.append("")
        return tags

    @classmethod
    def font_analysis(cls, pdf_file, final_report_insight, bank_name, excel_df):

        if len(bank_name) == 0:
            bank_name = 'default'
            
        # else:
        #     bank_name = bank_name[0]

        #font_repo = constants.FONT_REPOSITORY_PATH
        try:      
            font_repo = read_from_data_lake(constants.FONT_REPOSITORY_PATH, sheet_name='repo')
            font_repo.set_index('bank',inplace = True)
            font_repo = font_repo.fillna('')
        except:
            cls.font_error_list.append("Font: Font Repository excel is not present at path")
            font_repo = pd.DataFrame(columns=['bank', 'font_style', 'font_size', 'font_color'])
            font_repo.set_index('bank',inplace = True)
            
        try:
            sup_df = read_from_data_lake(constants.SUPPRESION_EXCEL_PATH, sheet_name='font')
            sup_df = sup_df.fillna('')
            sup_df = sup_df[sup_df['Bank'] == f'{bank_name}']
            sup_df.reset_index(drop=True, inplace=True)
        except:
            cls.font_error_list.append("Font: Font Supression excel is not present at path")
            sup_df = pd.DataFrame(columns=['Bank','color', 'font', 'size', 'text','y1'])
            sup_df = sup_df[sup_df['Bank'] == f'{bank_name}']
            sup_df.reset_index(drop=True, inplace=True)
        
        highlighting_coords = []
        # calling font_analysis_seg1 function to store the dataframe to highlight the anomaly related to segment 1 ( where the line elements are not matching with the font repo)
        df_basic, ratio = cls.extract_text(pdf_file)
        df_seg= cls.font_analysis_seg(df_basic)        
        if not df_seg.empty:
            # Drop rows where the text column meets the invalid criteria
            df_seg = df_seg[~df_seg['text'].apply(cls.is_invalid_text)]
            #after dropping the invalid text updating the segment
            df_seg['group_number'] = df_seg.groupby(['line','page','ID']).ngroup()
            group_counts = df_seg['group_number'].value_counts()
            df_seg['num_of_segments'] = df_seg['group_number'].map(group_counts)
            #if the number of segment = 1 then that means there is no alerts related to segment 2 so dropping it
            df_seg = df_seg[df_seg['num_of_segments'] != 1]
            del df_seg['group_number']
            # df_seg = df_seg
        else:
            df_seg = df_seg.iloc[:0].copy()
        
        df_seg1 = cls.font_analysis_seg1(df_basic, bank_name, font_repo, ratio)        
        if len(df_seg1) > 100:
            df_seg1 = pd.DataFrame(columns=df_seg1.columns)        
        if not df_seg1.empty:
            df_seg1 = df_seg1
        else:
            df_seg1 = df_seg1.iloc[:0].copy()        
   
        # creating final highlight and excel output dataframe
        df = pd.concat([df_seg, df_seg1], axis=0)
        df.reset_index(drop=True, inplace=True) 
        
        if not df.empty:
        
            df = df[~df['text'].apply(cls.should_drop)]
            df['origin'] = df['origin'].astype(str)
            df['origin_1'] = df['origin'].str.replace(r'\(|\)', '', regex=True)
            df['y1'] = df['origin_1'].str.split(',').str[1].str.strip()
            df['y1'] = df['y1'].astype(float)
            df['y1'] = df['y1'].round(2)
            df = cls.supressione(df, bank_name, sup_df)
            del df['y1'], df['origin_1']
            
            #supression based on the rules
            df = cls.font_sup(df)
            #ignoring the scanned font style
            df = df[~df['font'].str.contains('Unnamed-T3')]   
            #updating the group number based on the above operations
            group_counts = df['group_number'].value_counts()
            df['num_of_segments'] = df['group_number'].map(group_counts)
            del df['group_number'], df['group_count']
            
        else:
            df = df.iloc[:0].copy()
        # display(df)    
        line_counts = df['line'].value_counts()
        lines_to_remove = line_counts[line_counts > 4].index
        # Remove rows where 'line' is in the list of lines to remove
        df = df[~df['line'].isin(lines_to_remove)]            
        df2 = df
        df['tag'] = cls.extract_entities(df['line'].tolist())
        # # Adding the 'severity' column
        # df['severity'] = df['tag'].apply(lambda x: 'HIGH' if pd.notna(x) else 'LOW')
        # display(df)
        # using FITZ library to read the document
        
        doc = read_from_data_lake(pdf_file)
        i = 0
        # Iterate over each page in the document
        page_count = 0
        k = 1
        if not df.empty:
            for page in doc:
                df1 = df[df['page'] == k]
                df1.reset_index(drop=True, inplace=True)
                # calling the highlight function for each of the page
                highlighting_coords.append((df1, i))
                # d1 = cls.highlight(d1, df1 , i)
                page_count += 1
                i += 1
                k += 1
        if not df2.empty:
            # calling the font_excel_format function to get the output excel with anomaly flag against the elements and with the final insights
            df2.columns  = ['Size', 'Flags', 'Font', 'Color', 'Ascender', 'Descender', 'Text', 'Origin', 'Bbox','Page_Num' , 'Line', 'Num_Of_Segments', 'ID', 'Tag']              
            df2 = cls.font_excel_format(df2)

            # calling the get_expected_value function to get the repository value to show in the final excel output
            df2['Style_Expected_Value'] = cls.get_expected_value(bank_name, font_repo)[0]
            df2['Size_Expected_Value'] = cls.get_expected_value(bank_name, font_repo)[1]
            df2['Colour_Expected_Value'] = cls.get_expected_value(bank_name, font_repo)[2]


            # fetching the required column
            font_report = df2[['ID','Page_Num', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated', 'Tag' ]] #'Tag'
            df2 = df2.drop(['Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'], axis = 1)
            excel_df.loc[len(excel_df.index)] = [df2, '3A.Font_Raw_Report']
            excel_df.loc[len(excel_df.index)] = [font_report, '3B.Font_Report']
            # storing the output for the final excel workbook
            df3 = font_report[font_report['Font_Anomaly_Flag']== 1][['Insight', 'Severity_Level']]
            df3['Module'] = 'Font'
            df3 = df3.drop_duplicates('Insight', keep='first')
            df3.columns = ['Alerts','Severity','Module']
            df3 = df3[['Module','Alerts', 'Severity']]
            final_report_insight = pd.concat([final_report_insight, df3])           
        else:
            df2  = pd.DataFrame(columns =['ID','Page_Num','Line', 'Num_Of_Segments','Color','Font','Size','Text', 'Style_Expected_Value', 'Size_Expected_Value', 'Colour_Expected_Value'])
            font_report = pd.DataFrame(columns = ['ID','Page_Num', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'])
            excel_df.loc[len(excel_df.index)] = [df2, '3A.Font_Raw_Report']
            excel_df.loc[len(excel_df.index)] = [font_report, '3B.Font_Report']
            df3 = font_report[font_report['Font_Anomaly_Flag']== 1][['Insight', 'Severity_Level']]
            df3['Module'] = 'Font'
            df3 = df3.drop_duplicates('Insight', keep='first')
            df3.columns = ['Alerts','Severity','Module']
            df3 = df3[['Module','Alerts', 'Severity']]
            final_report_insight = pd.concat([final_report_insight, df3])
        return final_report_insight, excel_df, highlighting_coords

    @classmethod
    def highlight_pdf(cls, input_filename, highlighting_coords, font_output_pdf_path):
        doc = read_from_data_lake(input_filename)
        d1 = doc
        for t in highlighting_coords:
            d1 = cls.highlight(d1, t[0], t[1])
        highlight_bytes = d1.write()
        # saving the highlighted pdf in the intermediate folder
        write_to_data_lake(highlight_bytes, font_output_pdf_path)

    @staticmethod
    def font_repo_value(bank_name, pdf_filename, pdf_filename_file):
        font_details = pd.DataFrame(
            columns=['bank', 'file_name', 'font_style', 'font_size', 'font_color'])
        font_style = []
        font_size = []
        font_color = []
        font_styles = []
        font_sizes = []
        font_colors = []
        doc = read_from_data_lake(pdf_filename)
        for page in doc:
            blocks = page.get_text("dict")["blocks"]
            for block in blocks:
                try:
                    for line in block["lines"]:
                        for elements in line['spans']:
                            font_style.append(elements['font'])
                            font_size.append(elements['size'])
                            font_color.append(elements['color'])
                except:
                    pass
        font_styles.append(list(set(font_style)))
        font_sizes.append(list(set(font_size)))
        font_colors.append(list(set(font_color)))
        font_details['bank'] = bank_name
        font_details['file_name'] = pdf_filename_file
        font_details = font_details.assign(font_style=font_styles)
        font_details = font_details.assign(font_size=font_sizes)
        font_details = font_details.assign(font_color=font_colors)
        return font_details

    @classmethod
    def font_data_entry(cls, input_next_module, bank_names, pdf_filename_file):
        try:
            language = cls.process_pdf(input_next_module)
            if language == "ENGLISH":
                df_final_font = pd.DataFrame()
                final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
                excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
                font_details = cls.font_repo_value(bank_names, input_next_module, pdf_filename_file)
                df_final_font = pd.concat([df_final_font, font_details], axis=0)
                final_report_insight, excel_df, highlight_coords = cls.font_analysis(input_next_module, final_report_insight, bank_names, excel_df)
                return final_report_insight, excel_df, df_final_font, highlight_coords, cls.font_error_list

            else:
                df_final_font = pd.DataFrame(columns=['bank', 'file_name', 'font_style', 'font_size', 'font_color'])
                df2  = pd.DataFrame(columns =['ID','Page_Num','Line', 'Num_Of_Segments','Color','Font','Size','Text', 'Style_Expected_Value', 'Size_Expected_Value', 'Colour_Expected_Value'])
                font_report = pd.DataFrame(columns = ['ID','Page_Num', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'])
                excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
                excel_df.loc[len(excel_df.index)] = [df2, '3A.Font_Raw_Report']
                excel_df.loc[len(excel_df.index)] = [font_report, '3B.Font_Report']
                final_report_insight = pd.DataFrame(columns=['Module','Alerts', 'Severity'])           
                highlight_coords = []
                
        except Exception as e:
            # Print the error message and the line where the error occurred
            print(f"Error in Font module: {e}")
            traceback.print_exc()
            cls.font_error_list.append("Font: Error")
            df_final_font = pd.DataFrame(columns=['bank', 'file_name', 'font_style', 'font_size', 'font_color'])

            df2  = pd.DataFrame(columns =['ID','Page_Num','Line', 'Num_Of_Segments','Color','Font','Size','Text', 'Style_Expected_Value', 'Size_Expected_Value', 'Colour_Expected_Value'])

            font_report = pd.DataFrame(columns = ['ID','Page_Num', 'Font_Anomaly_Flag', 'Font_Flag', 'Size_Flag', 'Color_Flag', 'Severity_Level', 'Insight','Insight_Elaborated'])
            excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
            excel_df.loc[len(excel_df.index)] = [df2, '3A.Font_Raw_Report']
            excel_df.loc[len(excel_df.index)] = [font_report, '3B.Font_Report']

            final_report_insight = pd.DataFrame(columns=['Module','Alerts', 'Severity'])           

            highlight_coords = []

        return final_report_insight, excel_df, df_final_font, highlight_coords, cls.font_error_list
            

if __name__ == "__main__":
    import os
    path_intermediate = 'output/Intermediate/'
    input_next_module = os.path.join(path_intermediate, "logo_output.pdf")
    font_output_pdf_path = os.path.join(path_intermediate, "font_output.pdf")
    pdf_filename_file = "wells fargo input.pdf"

    bank_names = ['wells fargo']
    final_report_insight, excel_df, _, highlight_coords = FontAnalysis.font_data_entry(
        input_next_module, bank_names, pdf_filename_file)
    FontAnalysis.highlight_pdf(
        input_next_module, highlight_coords, font_output_pdf_path)
    print(final_report_insight)
    print(excel_df)
