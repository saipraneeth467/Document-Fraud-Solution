import os
import warnings
warnings.filterwarnings('ignore')
from PyPDF2 import PdfReader
import pandas as pd
from datetime import datetime
import re
import json
import fitz
from pandas.io.formats import excel
excel.ExcelFormatter.header_style = None
from dfs.commons import constants


class MetadataAnalyzer:
    meta_error_list = []
    @staticmethod
    def get_expected_value(bank_name):

        # bank_name: the output from the bank name extraction module will go as in input for this func
        # objective: to get the repository values against the elements which bank uses genuinely    
        fileName = constants.METADATA_REPOSITORY_PATH_GEN
        # genuine producer/creator/author list
        df = pd.read_excel(fileName, sheet_name='Producer_bank_level')
        df.set_index('Bank', inplace=True)
        df = df.fillna('')
        
        # df = meta_repo
        metadata_list = ['/Author','/Creator','/CreationDate','/ModDate','/Producer']
        try:

            Expected_Value = [df.loc[bank_name]['Author'],df.loc[bank_name]['Creator'],'','',df.loc[bank_name]['Producer']]
            return Expected_Value
        except:
            return ''
    
    @staticmethod
    def datefun(date1_str,date2_str):
        
        from datetime import datetime
        if date1_str.startswith("D:"):
            # Remove the single quotes around the timezone offset
            date1_str = date1_str.replace("'", "")
            date2_str = date2_str.replace("'", "")

            # Convert the date strings to datetime objects
            date1 = datetime.strptime(date1_str, 'D:%Y%m%d%H%M%S%z')
            date2 = datetime.strptime(date2_str, 'D:%Y%m%d%H%M%S%z')

        elif '/' in date1_str:
            # Convert the date strings to datetime objects
            date_format = "%m/%d/%Y %H:%M:%S"
            date1 = datetime.strptime(date1_str, date_format)
            date2 = datetime.strptime(date2_str, date_format)

        else:
            # Remove the single quotes around the timezone offset
            date1_str = date1_str.replace("'", "")
            date2_str = date2_str.replace("'", "")

            # Convert the date strings to datetime objects
            date_format = "%Y%m%d%H%M%S%z"
            date1 = datetime.strptime(date1_str, date_format)
            date2 = datetime.strptime(date2_str, date_format)


        # Calculate the time difference
        time_difference = date1 - date2 

        # Extract the number of days, hours, and minutes
        total_seconds = time_difference.total_seconds()
        days, remainder = divmod(total_seconds, 24 * 3600)
        hours, remainder = divmod(remainder, 3600)
        minutes, _ = divmod(remainder, 60)

        # print(f"Time difference: {int(days)} days, {int(hours)} hours, and {int(minutes)} minutes")

        return f"Time difference: {int(days)} days, {int(hours)} hours, and {int(minutes)} minutes"

        
    @classmethod
    def metadata_main(cls,input_file_path, bankname): #(filename, bank_names, u_id, Output_path):rotation
        # get metadata from filez

        # get metadata from file
        # from PyPDF2 import PdfReader
        # from io import BytesIO
        # bytes_stream = BytesIO(filename)
        try:
            file = PdfReader(input_file_path)
            print('pdf file is detected')
        except Exception as e:
            print('Metadata Analysis failed -- Please make sure a pdf file is uploaded')
            return

        if type(file.metadata) == None.__class__:
            metadata = {'/Producer': '', '/CreationDate': '', '/ModDate': '', '/Author': '', '/Creator': '', '/Keywords': '', '/Subject': '', '/Title': ''}
        else:
            metadata = file.metadata


        metadata_list = ['/Author','/Creator','/CreationDate','/ModDate','/Producer']
        Metadata_Name = []
        Metadata_Value = []
        metadata_dic = {}
        bank_name = ''

        #try:
        for m in metadata_list:
            Metadata_Name.append(m)
            if m in metadata.keys():
                Metadata_Value.append(metadata[m])
            else:
                Metadata_Value.append('')
        df = pd.DataFrame(list(zip(Metadata_Name, Metadata_Value)), columns = ['Metadata', 'Value'])

        metadata_dic = dict(zip(df['Metadata'], df['Value']))
    # get expected metadata
        # expected_values = bankname(filename)
        expected_values = bankname
        if expected_values =='':
            expected_values = 'Default'
            
        if expected_values:
            if len(expected_values) == 1:
                df['Expected_Value'] = cls.get_expected_value(expected_values[0])
                # display(df)
                bank_name = expected_values[0]
            elif len(expected_values) > 1:
                real_bank = ''
                matching_num = 0
                for each_value in expected_values:
                    df['Expected_Value'] = cls.get_expected_value(each_value)
                    for i in range(len(df)):
                        temp = 0
                    if df['Expected_Value'].iloc[i] in df['Value'].iloc[i]:
                        temp += 1
                    if temp > matching_num:
                        matching_num = temp
                        real_bank = each_value
                df['Expected_Value'] = cls.get_expected_value(real_bank)
                bank_name = real_bank


            Match = []
            #print(df['Match'])
            for i in range(len(df)):

                if df['Expected_Value'].iloc[i] != '':
                    if df['Expected_Value'].iloc[i] in df['Value'].iloc[i]:
                        Match.append('Yes')
                    else:
                        Match.append('No')
                        #else:
                            #Match.append('')
                else:
                    Match.append('')

            df['Match'] = Match
            doc = fitz.open(input_file_path)
            for Page_Number in range(doc.page_count):
                page = doc.load_page(Page_Number) #load page
                text = page.get_text()
                if text.strip():
                    pdf_type = "Input PDF is text based"
                    break
                elif page.get_pixmap():
                    pdf_type = "Input PDF is image based"
                    break
            doc.close()
            
            df.loc[5,['Metadata', 'Value']]=['Doc_Type',pdf_type]
            creation_date = metadata_dic['/CreationDate'] 
            modification_date = metadata_dic['/ModDate']
            if creation_date!="" and modification_date!="":
                diff = cls.datefun(modification_date,creation_date)
                # print(diff)
            elif creation_date!="" and modification_date== "":
                diff = "Mod_Date is not present"
            elif creation_date=="" and modification_date!= "":
                diff = "Creation_Date is not present"
            else:
                diff = "Creation_Date and Mod_Date is not present in doc"

            df.loc[6,['Metadata', 'Value']]=['Difference b/w Mod_Date and Creation_Date',diff]

            # pdf_type_1 = pdf_type
            # df['doc_type'] = pdf_type_1    

        # excel_df.loc[len(excel_df.index)] = [df, '1A.Metadata_Report']
        # df.insert(0, 'Sr_no', range(1, len(df) + 1))
        return metadata_dic,bank_name,df
    
    @classmethod
    def metadata_rules(cls, metadata, final_report_insight):

        if metadata == {}:
            print('Metadata Analysis failed -- No metadata detected from file')
            return

        # initiating final output columns
        Insight = ['']*14
        num_of_alerts = 0
        Severity_Level = ['']*14
        Flag = [0]*14


        # df = meta_repo
        fileName = constants.METADATA_REPOSITORY_PATH_GEN
        # genuine producer/creator/author list
        df = pd.read_excel(fileName, sheet_name='Producer_bank_level')
        df.set_index('Bank', inplace=True)
        df = df.fillna('')
        
        producer_list = list(df['Producer'])
        producer_list = [n for n in producer_list if n != '']

        creator_list = list(df['Creator'])
        creator__list = [n for n in creator_list if n != '']

        author_list = list(df['Author'])
        author_list = [n for n in author_list if n != '']

        # scanners list
        df1 = pd.read_excel(fileName, sheet_name='Scanner_List')
        scanner_list = list(df1['Scanner_List'])
        scanner_list = [n for n in scanner_list if n != '']

        # editing software list
        df2 = pd.read_excel(fileName, sheet_name='Editing_software')
        pdf_software = list(df2['Editing_software'])
        pdf_software = [n for n in pdf_software if n != '']

        # rule 1: producer isn't in the list of scanner brands & producer is not an engine
        in_list = False
        for scanner in scanner_list:
            if scanner in metadata['/Producer']:
                in_list = True

        for producer in producer_list:
            if producer in metadata['/Producer']:
                in_list = True

        if in_list == False:
            num_of_alerts += 1
            Flag[0] = 1
            Severity_Level[0] = 'MEDIUM'
            Insight[0] = 'Suspicious producer found in metadata'


        # rule 2: producer is in the list of commonly used pdf editing software
        for software in pdf_software:
            if software in metadata['/Producer']:
                num_of_alerts += 1
                Flag[1] = 1
                Severity_Level[1] = 'HIGH'
                Insight[1] = 'Editing software as producer detected in metadata'


        # rule 3: producer is blank
        if metadata['/Producer'] == '':
            num_of_alerts += 1
            Flag[2] = 1
            Severity_Level[2] = 'MEDIUM'
            Insight[2] = 'Producer missing in metadata'


        # rule 4: Creator is in the list of commonly used pdf editing software
        for software in pdf_software:
            if software in metadata['/Creator']:
                num_of_alerts += 1
                Flag[3] = 1
                Severity_Level[3] = 'HIGH'
                Insight[3] = 'Editing software as creator detected in metadata'

        # rule 5: creator is blank
        if metadata['/Creator'] == '':
            num_of_alerts += 1
            Flag[4] = 1
            Severity_Level[4] = 'HIGH'
            Insight[4] = 'Creator missing in metadata'


        # rule 6: Author is in the list of commonly used pdf editing software
        for software in pdf_software:
            if software in metadata['/Author']:
                num_of_alerts += 1
                Flag[5] = 1
                Severity_Level[5] = 'HIGH'
                Insight[5] = 'Editing software as author detected in metadata'
                
        # rule 7: creation date != modification date
        if metadata['/CreationDate'] != metadata['/ModDate']:
            num_of_alerts += 1
            Flag[6] = 1
            #Severity_Level[6] = 'LOW'
            Severity_Level[6] = 'HIGH'
            Insight[6] = 'The file was modified after creation'

        today_datetime = datetime.now()


        # rules regarding creation date
        if metadata['/CreationDate'] != '':

            current_dateTime = datetime.now()
            year = str(current_dateTime.year)
            if current_dateTime.month < 10:
                month = '0' + str(current_dateTime.month)
            else:
                month = str(current_dateTime.month)
            if current_dateTime.day < 10:
                day = '0' + str(current_dateTime.day)
            else:
                day = str(current_dateTime.day)


            creationdate = metadata['/CreationDate']
            # get the date string
            match = re.search(r'\d+', creationdate)
            if match:
                creationdate = creationdate[match.start():]

            if creationdate.startswith("D:"):
                created_year = int(creationdate[2:6])
                created_month = int(creationdate[6:8])
                created_day = int(creationdate[8:10])
                creationdate = f"{created_year:04d}-{created_month:02d}-{created_day:02d}"
                creationdate = pd.to_datetime(creationdate)
            elif '/' in creationdate:
                date_format = "%m/%d/%Y %H:%M:%S"
                creationdate = datetime.strptime(creationdate,date_format)
                creationdate = creationdate.strftime("%Y-%m-%d")  
                created_year = int(creationdate[:4])
                created_month = int(creationdate[5:7])
                created_day = int(creationdate[8:10])
                creationdate = pd.to_datetime(creationdate)
            else:
                created_year = int(creationdate[:4])
                created_month = int(creationdate[4:6])
                created_day = int(creationdate[6:8])
                creationdate = f"{created_year:04d}-{created_month:02d}-{created_day:02d}"
                creationdate = pd.to_datetime(creationdate)


            created_datetime = datetime(int(created_year),int(created_month),int(created_day))
            # rule 8: today's date - creation date > 3 months
            if (today_datetime-created_datetime).days > 90:
                num_of_alerts += 1
                Flag[7] = 1
                #Severity_Level[7] = 'LOW'
                Severity_Level[7] = 'LOW'
                Insight[7] = 'The file was created more than three months ago'

            # rule 10: today's date - mod date < 3 days
            if (today_datetime-created_datetime).days < 3:
                num_of_alerts += 1
                Flag[9] = 1
                #Severity_Level[9] = 'LOW'
                Severity_Level[9] = 'HIGH'
                Insight[9] = 'The file was last created within three days'


        # rules regarding modification date
        if metadata['/ModDate'] != '':

            moddate = metadata['/ModDate']
            match1 = re.search(r'\d+', moddate)
            if match1:
                moddate = moddate[match1.start():]

            if moddate.startswith("D:"):
                mod_year = int(moddate[2:6])
                mod_month = int(moddate[6:8])
                mod_day = int(moddate[8:10])
                moddate = f"{mod_year:04d}-{mod_month:02d}-{mod_day:02d}"
                moddate = pd.to_datetime(moddate)
            elif '/' in moddate:
                date_format = "%m/%d/%Y %H:%M:%S"
                moddate = datetime.strptime(moddate,date_format)
                moddate = moddate.strftime("%Y-%m-%d")  
                mod_year = int(moddate[:4])
                mod_month = int(moddate[5:7])
                mod_day = int(moddate[8:10])
                moddate = pd.to_datetime(moddate)
            else:
                mod_year = int(moddate[:4])
                mod_month = int(moddate[4:6])
                mod_day = int(moddate[6:8])
                moddate = f"{mod_year:04d}-{mod_month:02d}-{mod_day:02d}"
                moddate = pd.to_datetime(moddate)

            mod_datetime = datetime(int(mod_year),int(mod_month),int(mod_day))

            # rule 9: today's date - mod date > 3 months
            if (today_datetime-mod_datetime).days > 90:
                num_of_alerts += 1
                Flag[8] = 1
                #Severity_Level[8] = 'LOW'
                Severity_Level[8] = 'LOW'
                Insight[8] = 'The file was last modified more than three months ago'

            # rule 11: today's date - mod date < 3 days
            if (today_datetime-mod_datetime).days < 3:
                num_of_alerts += 1
                Flag[10] = 1
                #Severity_Level[10] = 'LOW'
                Severity_Level[10] = 'HIGH'
                Insight[10] = 'The file was last modified within three days'



        # rule 11: creation date is blank
        if metadata['/CreationDate'] == '' :
            num_of_alerts += 1
            Flag[11] = 1
            #Severity_Level[11] = 'LOW'
            Severity_Level[11] = 'HIGH'
            Insight[11] = 'Creation date not detected in metadata'

        # rule 12: modification date is blank
        if metadata['/ModDate'] == '' :
            num_of_alerts += 1
            Flag[12] = 1
            Severity_Level[12] = 'LOW'
            Insight[12] = 'Modification date not detected in metadata'

        # rule 13: producer is in the list of image to pdf convertor
        convertors = ['Wondershare PDFelement','FM-PDF','TalkHelper','JPG to PDF','Atop','PDFlite','Framework Team','SuperGeek']
        for convertor in convertors:
            if convertor in metadata['/Producer']:
                num_of_alerts += 1
                Flag[13] = 1
                Severity_Level[13] = 'HIGH'
                Insight[13] = 'Image to pdf convertor was found in metadata'


        # rule = ['Producer_not_engine_or_scanner','Producer_editing_software','Producer_missing',
        #         'Creator_editing_software','Creator_missing','Author_editing_software',
        #         'Creation_dt_different_from_modification_dt','Created_more_than_3M',
        #         'Modified_more_than_3M','Created/Modified_within_last_3D','Creation_dt_missing',
        #         'Modification_dt_missing','Producer_image_to_PDF_converter','The original file is modified']
        
        rule = ['Producer_not_engine_or_scanner','Producer_editing_software','Producer_missing',
                'Creator_editing_software','Creator_missing','Author_editing_software',
                'Creation_dt_different_from_modification_dt','Created_more_than_3M',
                'Modified_more_than_3M','Created_within_last_3D','Modified_within_last_3D','Creation_dt_missing',
                'Modification_dt_missing','Producer_image_to_PDF_converter']
        

        #generate final report for metadata analysis
        df = pd.DataFrame(list(zip(rule, Flag, Severity_Level, Insight)), columns = ['Rule', 'Flag','Severity_Level','Insight'])
        # df.insert(0, 'Sr_no', range(1, len(df) + 1))
        # print(df)
        #generate json file for alerts
        df2 = df[df['Flag'] == 1][['Insight','Severity_Level']]
        df2['Module'] = 'Metadata'
        df2.columns = ['Alerts','Severity', 'Module']
        df2 = df2[['Module','Alerts', 'Severity']]
        final_report_insight = pd.concat([final_report_insight,df2])

        # excel_df.loc[len(excel_df.index)] = [df, '1B.Metadata_Report']

        return df, final_report_insight, cls.meta_error_list
    
    @classmethod
    def write_to_excel(cls, df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))  
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'

        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname, index=False)
            

if __name__ == '__main__':

    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    bank_names = ['Chase', 'Wells Fargo']
    bank_name = bank_names[1]
    final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
    fraud_report_file_path = 'test/report.xlsx'
    metadata, bank_name, df1 = MetadataAnalyzer.metadata_main(
        input_next_module, bank_name)
    df, final_report_insight = MetadataAnalyzer.metadata_rules(
        metadata, final_report_insight, fraud_report_file_path)

    MetadataAnalyzer.write_to_excel(
        df1, fraud_report_file_path, "a", '1A.Metadata_Raw_Output')
    MetadataAnalyzer.write_to_excel(
        df, fraud_report_file_path, "a", '1B.Metadata_Report')

