import pandas as pd
from PIL import Image
from PIL.ExifTags import TAGS

from doctr.io import DocumentFile
from doctr.models import ocr_predictor
model = ocr_predictor(det_arch = 'db_resnet50',reco_arch = 'crnn_vgg16_bn', pretrained = True)

from dfs.commons import constants
from PIL import Image, ImageDraw
import pytesseract
from fuzzywuzzy import process
from fuzzywuzzy import fuzz
import fuzzysearch
import cv2
import math
import fitz
import pandas as pd
import numpy as np
import re
import csv
import time
import os
import matplotlib.pyplot as plt
from openpyxl import Workbook, load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill
from spellchecker import SpellChecker
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake
import tempfile

class Metadata:
    meta_error_list = []
    @staticmethod
    def metadata(image_path):
        def get_exif_data(image_path):
            
            # with Image.open(image_path) as img:
            with read_from_data_lake(image_path) as img:
                if hasattr(img, '_getexif') and img._getexif() is not None:
                    exif_raw = img._getexif() 
                else:
                    exif_raw = {}
                return {TAGS.get(tag, tag): value for tag, value in exif_raw.items()}
        exif_data = get_exif_data(image_path)
        return exif_data
    
    @staticmethod
    def metadata_info(metadata_results):
        required_metadata_fields = [
            'Software', 
            'DateTime', 
            'ModifiedDate', 
            'DeviceMake', 
            'LensMake', 
            'MimeType',
            'ImageWidth', 
            'ImageLength'
        ]
        metadata_df = pd.DataFrame(required_metadata_fields, columns=['Metadata'])
        metadata_df['Values'] = ''
        for field in required_metadata_fields:
            if field in metadata_results:
                metadata_df.loc[metadata_df['Metadata'] == field, 'Values'] = metadata_results[field]
        metadata_df.loc[metadata_df['Metadata'] == 'Software', 'Metadata'] = 'Creator'
        image_width = metadata_df.loc[metadata_df['Metadata'] == 'ImageWidth', 'Values'].values[0]
        image_length = metadata_df.loc[metadata_df['Metadata'] == 'ImageLength', 'Values'].values[0]
        resolution_value = f'{image_width}/{image_length}'
        metadata_df = metadata_df[~metadata_df['Metadata'].isin(['ImageWidth', 'ImageLength'])]
        new_row = pd.DataFrame({'Metadata': ['Resolution'], 'Values': [resolution_value]})
        metadata_df = pd.concat([metadata_df, new_row], ignore_index=True)
        return metadata_df

    @staticmethod
    def editing_software(value):
        editing_softwares = ["GIMP", "Photoshop", "Paint"]
        for software in editing_softwares:
            if software.lower() in value.lower():
                return True
        return False
    
        # Function to get the boundary coordinates of each word detected through Doctr

    # os.makedirs(output_folder, exist_ok = True)
    # os.makedirs(excel_output_folder, exist_ok = True)
    # os.makedirs(final_output_folder, exist_ok = True)
    
    @staticmethod
    def doctr_check(image_path):

        # image = Image.open(image_path)
        image = read_from_data_lake(image_path)
        image = image.convert('RGB')
        width,height = image.size[:2]
        image_shape = [width, height]

        # doc = DocumentFile.from_images(image_path)
        img1 = read_from_data_lake(image_path)
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(image_path)[-1]) as temp_file:
            img1.save(temp_file, format=img1.format)
            temp_file_path = temp_file.name   
         
        doc = DocumentFile.from_images(temp_file_path)
        result = model(doc)
        output = result.export()
        word_count_area = 0
        word_count = 0

        # Calculate the word count area and word count
        for page in output['pages']:
            for block in page['blocks']:
                for line in block['lines']:
                    for word in line['words']:
                        # Extract coordinates and convert to absolute values
                        (x1, y1), (x2, y2) = word['geometry']
                        abs_x1 = int(x1 * image_shape[1])
                        abs_y1 = int(y1 * image_shape[0])
                        abs_x2 = int(x2 * image_shape[1])
                        abs_y2 = int(y2 * image_shape[0])

                        # Calculate the area of the word bounding box
                        word_area = (abs_x2 - abs_x1) * (abs_y2 - abs_y1)
                        word_count_area += word_area

                        # Count each word
                        word_count += len(word['value'].split())

        # Calculate the page area
        page_area = image_shape[0] * image_shape[1]
        ratio = word_count_area / page_area

        def convert_coordinates(geometry, page_dim):
            len_x = page_dim[1]
            len_y = page_dim[0]
            (x_min, y_min) = geometry[0]
            (x_max, y_max) = geometry[1]
            x_min = math.floor(x_min * len_x)
            x_max = math.ceil(x_max * len_x)
            y_min = math.floor(y_min * len_y)
            y_max = math.ceil(y_max * len_y)
            return [x_min, y_min, x_max,y_max]

        def get_coordinates(output, image_shape):
            page_dim = output['pages'][0]["dimensions"]
            text_coordinates = []
            left_crop = top_crop = right_crop = bottom_crop = False
            for obj1 in output['pages'][0]["blocks"]:
                for obj2 in obj1["lines"]:
                    for obj3 in obj2["words"]:                
                        converted_coordinates = convert_coordinates(
                                                   obj3["geometry"],page_dim
                                                  )
                        # print("{}: {}".format(converted_coordinates,
                        #                       obj3["value"]
                        #                       )
                        #      )
                        text_coordinates.append([converted_coordinates,obj3["value"]])
            return text_coordinates
        def get_line_word_count(text_coordinates):
            first_line_y = text_coordinates[0][0][1]
            last_line_y = text_coordinates[-1][0][1]
            first_line_words = [i[1] for i in text_coordinates if i[0][1] == first_line_y]
            last_line_words = [i[1] for i in text_coordinates if i[0][1] == last_line_y]

            if any(i[0][2] > 0.9 * width for i in text_coordinates if i[0][1] == first_line_y):
                first_line_corner_check  = True
            else:
                first_line_corner_check = False
            if any(i[0][2] > 0.9 * width for i in text_coordinates if i[0][1] == last_line_y):
                last_line_corner_check  = True
            else:
                last_line_corner_check = False
            return len(first_line_words), len(last_line_words), first_line_y, last_line_y, first_line_corner_check, last_line_corner_check

        spell=SpellChecker()
        text_coordinates = get_coordinates(output, image.size)
        first_line_word_count, last_line_word_count, first_line_y, last_line_y, first_line_corner_check, last_line_corner_check = get_line_word_count(text_coordinates)
        if first_line_corner_check and first_line_word_count < 3:
            text_coordinates = [i for i in text_coordinates if i[0][1] != first_line_y]
        if last_line_corner_check and last_line_word_count <3:
            text_coordinates = [i for i in text_coordinates if i[0][1] != last_line_y]

        if text_coordinates:
            top = min([i[0][1] for i in text_coordinates])
            left = min([i[0][0] for i in text_coordinates])
            bottom = max([i[0][3] for i in text_coordinates])
            right = max([i[0][2] for i in text_coordinates])
        else:
            top = 0
            bottom = image.size[1]
            left = 0
            right = image.size[0]

        doc_check = 0

        margin_diffs = [round(top/height,3), round(left/width,3), round(1-(bottom/height),3), round(1-(right/width),3)]
        count = sum(diff>0.02 for diff in margin_diffs)
        if (round(top/height,3) < 0.02) or (round(left/width,3) < 0.02) or (round(1-(bottom/height),3) < 0.02) or (round(1-(right/width),3) < 0.02):
            doc_check = 0
        else:
            doc_check = 1

        if doc_check == 0:

            if (round(top/height,3) < 0.02):
                edge_text = []
                spelling_check_true = []
                for i in text_coordinates:
                    if abs(i[0][1] - top) < 5:
                        edge_text.append(i[1])
                if len(edge_text) > 0:
                    for word in edge_text:
                        if word in spell:
                            spelling_check_true.append(word)
                    if len(edge_text) > 0:
                        if len(spelling_check_true)/len(edge_text) > 0.9:
                            doc_check = 1

            if (round(left/width,3) < 0.02):
                edge_text = []
                spelling_check_true = []
                for i in text_coordinates:
                    if abs(i[0][0] - left) < 5:
                        edge_text.append(i[1])
                if len(edge_text) > 0:
                    for word in edge_text:
                        if word in spell:
                            spelling_check_true.append(word)
                    if len(edge_text) > 0:
                        if len(spelling_check_true)/len(edge_text) > 0.9:
                            doc_check = 1


            if (round(bottom/height,3) < 0.02):
                edge_text = []
                spelling_check_true = []
                for i in text_coordinates:
                    if abs(i[0][3] - bottom) < 5:
                        edge_text.append(i[1])
                if len(edge_text) > 0:
                    for word in edge_text:
                        if word in spell:
                            spelling_check_true.append(word)
                    if len(edge_text) > 0:
                        if len(spelling_check_true)/len(edge_text) > 0.9:
                            doc_check = 1


            if (round(right/width,3) < 0.02):
                edge_text = []
                spelling_check_true = []
                for i in text_coordinates:
                    if abs(i[0][2] - right) < 5:
                        edge_text.append(i[1])
                if len(edge_text) > 0:
                    for word in edge_text:
                        if word in spell:
                            spelling_check_true.append(word)
                    if len(edge_text) > 0:
                        if len(spelling_check_true)/len(edge_text) > 0.9:
                            doc_check = 1


        # if doc_check:
        #     print("DB boundary is fully enclosed by the image boundary.")
        # else:
        #     print("DB boundary is not fully enclosed by the image boundary - less than the minimum permissible distance from the image boundary.")

        # draw = ImageDraw.Draw(image)
        margin = [round(top/height,3),round(left/width,3),round(1-(bottom/height),3),round(1-(right/width),3)]
        # print("Margin differences: ",round(top/height,3),round(left/width,3),round(1-(bottom/height),3),round(1-(right/width),3))
        # print("Count :", count)
        # draw.rectangle([left, top, right, bottom], outline="green", width=3)
        # print('DB Border Dimensions:', bottom-top, 'x', right-left)
        return image, count, [top,left,bottom,right], word_count, ratio, margin

    @staticmethod
    def detect_AB_border(image, percentage_threshold=0.1):
        # Convert image to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Get image dimensions
        h, w = gray.shape

        # Compute the sum of pixel values along rows and columns
        row_sums = np.sum(gray, axis=1)
        col_sums = np.sum(gray, axis=0)

        # Initialize border coordinates
        top, bottom, left, right = 0, h, 0, w

        # Detect top border
        for i in range(h - 1):
            if abs(row_sums[i] - row_sums[i + 1]) / row_sums[i] > percentage_threshold:
                top = i + 1
                break

        # Detect bottom border
        for i in range(h - 1, 0, -1):
            if abs(row_sums[i] - row_sums[i - 1]) / row_sums[i] > percentage_threshold:
                bottom = i
                break

        # Detect left border
        for j in range(w - 1):
            if abs(col_sums[j] - col_sums[j + 1]) / col_sums[j] > percentage_threshold:
                left = j + 1
                break

        # Detect right border
        for j in range(w - 1, 0, -1):
            if abs(col_sums[j] - col_sums[j - 1]) / col_sums[j] > percentage_threshold:
                right = j
                break

        return left, top, right, bottom

    @staticmethod
    def highlight_border(image, top, bottom, left, right):
        highlighted_image = image.copy()
        cv2.rectangle(highlighted_image, (left, top), (right, bottom), (0, 0, 255), 3)
        return highlighted_image

    @staticmethod
    def bg_complexity(image):
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        edges=cv2.Canny(gray,100,200)
        variance=np.var(edges)
        return variance
    
    @staticmethod
    def detect_cropped_image_using_doctr(image_path, image_shape, margin=10):
        # image = Image.open(image_path)
        image = read_from_data_lake(image_path)
        width,height = image.size[:2]
        image_shape = [width, height]
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(image_path)[-1]) as temp_file:
            image.save(temp_file, format=image.format)
            temp_file_path = temp_file.name   
         
        doc = DocumentFile.from_images(temp_file_path)
        # doc = DocumentFile.from_images(image_path)
        result = model(doc)
        output = result.export()


        # Extract text elements and bounding boxes
        text_data = output['pages'][0]["blocks"]

        left_crop = right_crop = top_crop = bottom_crop = False
        count=0
        aliases = []
        for block in text_data:
            for line in block["lines"]:
                for word in line["words"]:
                    geometry=word["geometry"]
                    #print(len(geometry))
                    if len(geometry)==2:
                        (x0,y0),(x1,y1)=geometry
                    #else:
                        #x0,y0,x1,y1=0,0,1,1
                    #(x0, y0, x1, y1) = word["geometry"]
                    x = int(x0 * image_shape[1])
                    y = int(y0 * image_shape[0])
                    w = int((x1 - x0) * image_shape[1])
                    h = int((y1 - y0) * image_shape[0])
                    #print(x,y,w,h)
                    # Check if text is within the margin from the edges
                    
                    if x <= margin and left_crop is False:
                        left_crop = True
                        aliases.append('LEFT')
                    if y <= margin and top_crop is False:
                        top_crop = True
                        aliases.append('TOP')
                    if x + w >= image_shape[1] - margin and right_crop is False:
                        right_crop = True
                        aliases.append('RIGHT')
                    if y + h >= image_shape[0] - margin and bottom_crop is False:
                        bottom_crop = True
                        aliases.append('BOTTOM')
                        
        doctr_crop = ""
        severity = "No Cropping Detected"
        if left_crop or right_crop or top_crop or bottom_crop:
            severity = "LOW"
            doctr_crop = "Cropped"
        elif (left_crop and right_crop) or (top_crop and bottom_crop):
            severity = "MEDIUM"
            doctr_crop = "Cropped"
        elif left_crop and right_crop and top_crop and bottom_crop:
            severity = "HIGH"
            doctr_crop = "Cropped"
        else:
            doctr_crop = "Not Cropped"
    
        return severity, aliases, doctr_crop
    
    @staticmethod
    def detect_cropped_image_Sobel(image_path, mild_threshold=30, moderate_threshold=60, severe_threshold=90):
        # Read the image
#         image = cv2.imread(image_path)
#         if image is None:
#             raise ValueError("Image not found or unable to read.")

#         # Convert to grayscale
#         gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        if constants.IS_S3_PATH:
            raw_image_data = read_from_data_lake(image_path, reader='cv2').getvalue()
        else:    
            raw_image_data = read_from_data_lake(image_path, reader='cv2')
            
        nparr = np.frombuffer(raw_image_data, np.uint8)
        bgr_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        gray = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
        

        # Calculate the gradients
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)

        # Calculate the magnitude of the gradients
        magnitude = np.sqrt(grad_x**2 + grad_y**2)

        # Calculate mean magnitude near the borders
        border_width = 10
        top_border = magnitude[:border_width, :]
        bottom_border = magnitude[-border_width:, :]
        left_border = magnitude[:, :border_width]
        right_border = magnitude[:, -border_width:]

        mean_top = np.mean(top_border)
        mean_bottom = np.mean(bottom_border)
        mean_left = np.mean(left_border)
        mean_right = np.mean(right_border)

        # Determine the severity of cropping
        max_mean = max(mean_top, mean_bottom, mean_left, mean_right)
        # print(max_mean)
        mean_values = {"TOP" : mean_top, "BOTTOM" : mean_bottom, "LEFT" : mean_left, "RIGHT": mean_right}
        aliases = [alias for alias, value in mean_values.items() if value > 30]
        sobel_crop = ""
        if not aliases :
            aliases = []
        if max_mean > severe_threshold:
            severity = "HIGH"
            sobel_crop = "Cropped"
        elif max_mean > moderate_threshold:
            severity = "MEDIUM"
            sobel_crop = "Cropped"
        elif max_mean > mild_threshold:
            severity = "LOW"
            sobel_crop = "Cropped"
        else:
            severity = "No Cropping Detected"
            sobel_crop = "Not Cropped"

        return severity, aliases, sobel_crop
    
    @classmethod
    def handle_cropping_detection(cls, image_path, variance):
        # image = Image.open(image_path)
        image = read_from_data_lake(image_path)
        width,height = image.size[:2]
        image_shape = [width, height]
        if variance < 4000:
            return cls.detect_cropped_image_Sobel(image_path)
        else:
            return cls.detect_cropped_image_using_doctr(image_path, image_shape)
   
    # @classmethod
    # def common_proc(cls, image_path):   
    #     result_S= cls.detect_cropped_image_Sobel(image_path)
    #     result = cls.detect_cropped_image_using_doctr(image_path, margin=100)
    #     if result_S == "Cropped" and result == "Cropped":
    #         print("Finally Cropped")
    #     if result_S == "Not Cropped" and result == "Not Cropped":
    #         print("Finally Not Cropped") 
    #     if result_S == " Not Cropped" and result == "Cr opped":
    #         print("Finally Not Cropped")
    #     if result_S == "Cropped" and result == " Not Cropped":
    #         if doc_check==1:
    #             print("Finally Not Cropped")
    #         else:
    #             print("Finally Cropped")
                
    @classmethod            
    def common_proc(cls, image_path):
        image = read_from_data_lake(image_path)
        # image = Image.open(image_path)
        width,height = image.size[:2]
        image_shape = [width, height]
        final_crop = ""
        _,m,result_S= cls.detect_cropped_image_Sobel(image_path)
        _,m,result = cls.detect_cropped_image_using_doctr(image_path, image_shape, margin=100)
        if result_S == "Cropped" and result == "Cropped":
            final_crop = "Cropped"
        if result_S == "Not Cropped" and result == "Not Cropped":
            final_crop = "Not Cropped" 
        if result_S == "Not Cropped" and result == "Cropped":
            final_crop = "Not Cropped"
        if result_S == "Cropped" and result == "Not Cropped":
            if doc_check==1:
                final_crop = "Not Cropped"
            else:
                final_crop = "Cropped"
        return final_crop
    
    @staticmethod
    def calculate_margin(doctr_coords, top, left, bottom, right):
        top_margin = abs(doctr_coords[0]-top)
        left_margin = abs(doctr_coords[1]-left)
        bottom_margin = abs(doctr_coords[2]-bottom)/bottom
        right_margin = abs(doctr_coords[3]-right)
        
        # print("Margin differences: ", top_margin, left_margin, bottom_margin, right_margin)
        margin= [top_margin, left_margin, bottom_margin, right_margin]
        count = sum(diff>10 for diff in margin)
        # print("Count :", count)
        return count, margin

    @staticmethod
    def create_excel_file(count, severity, final_crop):
        
        severity_four_corner = ""
        
        if count == 4:
            severity_four_corner = "No Alerts"
        elif count == 3:
            severity_four_corner = "LOW"
        elif count == 2:
            severity_four_corner = "MEDIUM"
        else:
            severity_four_corner = "HIGH"
            
        try:
            insight = f"{count}_Corners detected"
        except:
            insight = ""
            
        # if count == 4:
        #     insight = "Four corners detected"
        # else :
        #     insight = "Four corners are not detected"

        insight_crop = ""
        # if severity == "No Cropping Detected":
        #     insight_crop = "Image is not cropped"
        # else:
        #     insight_crop = "Image is cropped"

        # count_edges_crop = ""
        if severity == "HIGH":
            count_edges_crop = 4
        elif severity == "MEDIUM":
            count_edges_crop = 2
        elif severity == "LOW":
            count_edges_crop = 1
        else:
            count_edges_crop = 0
            
        try:
            insight_crop = f"{count_edges_crop}_Sides cropped"
        except:
            insight_crop = ""

           
        flag_four_corner = ""
        if count != 4:
            flag_four_corner = 1
        else: 
            flag_four_corner = 0

        flag_crop = ""
        if severity == "No Cropping Detected":
            severity = 'No Alerts'
            flag_crop = 0
        else:
            flag_crop = 1

        # excel_filename = f"{base}.xlsx"
        
        # insight_crop == final_crop
                
        df1 = pd.DataFrame({"Rule": ("Four Corners", "Image Cropping"), "Flag": (flag_four_corner, flag_crop), "Severity_Level": (severity_four_corner, severity), "Insight": (insight, insight_crop)})
        
        
        # df1.to_excel(excel_filename, index=False)
        # print(f'Excel file created as {excel_filename}')
        
        return df1, count_edges_crop 

#     def merge_excel_files(pdf_name):
#         final_excel_filename = os.path.join(final_output_folder, f"{pdf_name}.xlsx")
#         raw_output_files = []
#         report_files = []

#         for file in os.listdir(excel_output_folder):
#             if file.startswith(pdf_name) and file.endswith('.xlsx'):
#                 excel_path = os.path.join(excel_output_folder, file)
#                 if "page" in file :
#                     raw_output_files.append(excel_path)
#                     report_files.append(excel_path)
#         raw_output_data = []
#         report_data = []

        # def extract_data_from_sheet(sheet_path, sheet_name):
        #     df = pd.read_excel(sheet_path, sheet_name = sheet_name)
        #     return df
        # for file_path in raw_output_files:
        #     df = extract_data_from_sheet(file_path, "4 corner Raw Output")
        #     raw_output_data.append(df)
        #for file_path in report_files:
         #   df = extract_data_from_sheet(file_path, "4 corner Report")
          #  report_data.append(df)

        # combined_raw_df = pd.concat(raw_output_data, ignore_index = True)
        #combined_report_df = pd.concat(report_data, ignore_index = True)
        # combined_raw_df = combined_raw_df.sort_values(by = "Page Number").reset_index(drop = True)
        #combined_report_df = combined_report_df.sort_values(by = "Page Number").reset_index(drop = True)
        # combined_raw_df["Sr No."] =  range(1, len(combined_raw_df) +1)
        #combined_report_df["Sr No."] =  range(1, len(combined_report_df) +1)
        # wb_final = Workbook()
        # ws_raw = wb_final.active
        # ws_raw.title = "4 corner Raw Output"
        # raw_output_headers = ["Sr No.", "Document Type","Page Number", "Type", "Alert Description", "Coordinates", "Flag", "Severity level", "Insights", "Word Count", "Ratio", "Dimensions", "Image Area", "Margin"]
        # for col_num, header in enumerate(raw_output_headers, start = 1):
        #     ws_raw.cell(row=1, column = col_num, value = header)
        # for r in dataframe_to_rows(combined_raw_df, index = False, header = False):
        #     ws_raw.append(r)

        #ws_report = wb_final.create_sheet(title = "4 corner Report")
        #report_headers = ["Sr No.", "Page Number", "Type", "Flag","Severity level", "Insights"]
        #for col_num, header in enumerate(report_headers, start = 1):
            #ws_report.cell(row=1, column = col_num, value = header)
        #for r in dataframe_to_rows(combined_report_df, index = False, header = False):
            #ws_report.append(r)

        # wb_final.save(final_excel_filename)
        # print(f"Final Excel file created as {final_excel_filename}")

#     @classmethod
#     def process_pdfs(cls, folder_path, output_folder):
#         for filename in os.listdir(folder_path):
#             if filename.lower().endswith('.pdf'):
#                 pdf_path = os.path.join(folder_path, filename)
#                 pdf_name = os.path.splitext(filename)[0]
#                 pdf_output_folder = os.path.join(output_folder, pdf_name)
#                 os.makedirs(pdf_output_folder, exist_ok = True)
#                 excel_filename = os.path.join(excel_output_folder, f"{pdf_name}.xlsx")

#                 #Convert PDF pages to images
#                 pdf_document = fitz.open(pdf_path)
#                 for page_number in range(len(pdf_document)):
#                     page = pdf_document.load_page(page_number)
#                     pix = page.get_pixmap()
#                     image_path = os.path.join(pdf_output_folder, f"{pdf_name}_page_{page_number +1}.png")
#                     pix.save(image_path)


#                     pil_image, count, coordinates, word_count, ratio, margin = doctr_check(image_path)
#                     pil_image = pil_image.convert('RGB')
#                     open_cv_image = np.array(pil_image)
#                             # Convert RGB to BGR
#                     image = open_cv_image[:, :, ::-1].copy()
#                     top, bottom, left, right = cls.detect_AB_border(open_cv_image)

#             # Highlight the border
#                     highlighted_image = cls.highlight_border(image, top, bottom, left, right)
#                              # Get dimensions of the images
#                     highlighted_dim = highlighted_image.shape[:2]
#                     cropping_status = cls.detect_cropped_image_Sobel(image_path)
#                     img_dim = str([highlighted_dim[0], highlighted_dim[1]])
#                     img_area = highlighted_dim[0] * highlighted_dim[1]
#                     print(f'Image Dimensions: {highlighted_dim[0]} x {highlighted_dim[1]}')
#                     print('AB Border Dimensions:', bottom-top, 'x', right-left)

#                             # print(f'Trimmed Image Dimensions: {trimmed_dim[0]}x{trimmed_dim[1]}')

#                     new_filename = os.path.join(pdf_output_folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_AB-DB.jpg")

#                             # Display the image
#                     plt.figure(figsize=(10, 5))
#                     plt.title('Highlighted AB & DB Borders')
#                     plt.imshow(cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB))
#                     highlighted_image = cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB)
#                     cv2.imwrite(new_filename, highlighted_image)
#                     print(f"image saved as {new_filename}")

#                     plt.show()
#                     variance = cls.bg_complexity(np.array(pil_image))
#                     severity =  handle_cropping_detection(image_path, variance)
#                     create_excel_file(excel_output_folder, pdf_name, "PDF", page_number + 1, count, severity, coordinates, word_count, ratio, img_dim, img_area, margin)
#                 merge_excel_files(pdf_name)


#     @classmethod
#     def process_images(cls, folder_path, output_folder):
#         for filename in os.listdir(folder_path):
#             if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
#                 image_path = os.path.join(folder_path, filename)
#                 pil_image = Image.open(image_path)


#                 pil_image, count,coordinates, word_count, ratio, margin = cls.doctr_check(image_path)
#                 pil_image = pil_image.convert('RGB')
#                 open_cv_image = np.array(pil_image)
#                             # Convert RGB to BGR
#                 image = open_cv_image[:, :, ::-1].copy()
#                 top, bottom, left, right = cls.detect_AB_border(image)

#             # Highlight the border
#                 highlighted_image = cls.highlight_border(image, top, bottom, left, right)
#                              # Get dimensions of the images
#                 highlighted_dim = highlighted_image.shape[:2]
#                 img_dim = str([highlighted_dim[0], highlighted_dim[1]])
#                 img_area = highlighted_dim[0] * highlighted_dim[1]
#                 print(f'Image Dimensions: {highlighted_dim[0]} x {highlighted_dim[1]}')
#                 print('AB Border Dimensions:', bottom-top, 'x', right-left)
#                 base = os.path.splitext(os.path.basename(image_path))[0]
#                 new_filename = f"{output_folder}/{base}_AB-DB.jpg"

#                             # Display the image
#                 plt.figure(figsize=(10, 5))
#                 plt.title('Highlighted AB & DB Borders')
#                 plt.imshow(cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB))
#                 highlighted_image = cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB)
#                 cv2.imwrite(new_filename, highlighted_image)
#                 print(f"image saved as {new_filename}")

#                 plt.show()
#                 variance = cls.bg_complexity(np.array(pil_image))
#                 severity =  handle_cropping_detection(image_path, variance)
#                     #_, aliases = detect_cropped_image_Sobel(image_path)
#                 create_excel_file(excel_output_folder, os.path.splitext(filename)[0], "Image", 1, count, severity, coordinates, word_count, ratio, img_dim, img_area, margin)
#                 excel_filename = f"{os.path.splitext(filename)[0]}_page_1.xlsx"
#                 source_excel_path = os.path.join(excel_output_folder, excel_filename)
#                 final_path = os.path.join(final_output_folder, excel_filename)
#                 os.rename(source_excel_path, final_path)
#                 print(f"Excel file moved to {final_path}")
                
    @classmethod
    def process_images(cls, image_path):
        
        # pil_image = Image.open(image_path)
        # pil_image = read_from_data_lake(image_path)
        pil_image, count, DB_border_coor, word_count, ratio, margin = cls.doctr_check(image_path)
        # pil_image = pil_image.convert('RGB')
        open_cv_image = np.array(pil_image)
        
        # Convert RGB to BGR
        image = open_cv_image[:, :, ::-1].copy()
        left, top, right, bottom = cls.detect_AB_border(image)
        AB_border_coor = [left, top, right, bottom]

        # Highlight the border
        highlighted_image = cls.highlight_border(image, top, bottom, left, right)
        # Get dimensions of the images
        highlighted_dim = highlighted_image.shape[:2]
        # img_dim = str([highlighted_dim[0], highlighted_dim[1]])
        img_area = highlighted_dim[0] * highlighted_dim[1]
        if img_area > 1.6*((bottom-top)*(right-left)):
            count, margin = cls.calculate_margin(DB_border_coor, top, left, bottom, right)
        # print(f'Image Dimensions: {highlighted_dim[0]} x {highlighted_dim[1]}')
        # print('AB Border Dimensions:', bottom-top, 'x', right-left)
        # base = os.path.splitext(os.path.basename(image_path))[0]
        # new_filename = f"{base}_AB-DB.jpg"

        # Display the image
        # plt.figure(figsize=(10, 5))
        # plt.title('Highlighted AB & DB Borders')
        # plt.imshow(cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB))
        # highlighted_image = cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB)
        # cv2.imwrite(new_filename, highlighted_image)
        # print(f"image saved as {new_filename}")

        # plt.show()
        variance = cls.bg_complexity(np.array(pil_image))
        severity, sides, crop =  cls.handle_cropping_detection(image_path, variance)
            # _, aliases = detect_cropped_image_Sobel(image_path)
            
        final_crop = cls.common_proc(image_path)
        df, count_edges_crop = cls.create_excel_file(count, severity, final_crop)
        
        return df, count_edges_crop, count, DB_border_coor, sides, AB_border_coor
    
        # excel_filename = f"{os.path.splitext(filename)[0]}_page_1.xlsx"
        # source_excel_path = os.path.join(excel_output_folder, excel_filename)
        # final_path = os.path.join(final_output_folder, excel_filename)
        # os.rename(source_excel_path, final_path)
        # print(f"Excel file moved to {final_path}")


    # def main(folder_path, output_folder):
    #     # pdf_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
    #     image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg','.jpeg'))]
    #     # if pdf_files:
    #     #     process_pdfs(folder_path, output_folder)
    #     if image_files: 
    #         process_images(folder_path, output_folder)


    
    @classmethod
    def metadata_entry(cls, input_file_path, four_corner_run):
        metadata_results = cls.metadata(input_file_path)
        metadata_df = cls.metadata_info(metadata_results)
        
        if four_corner_run == 1:
            four_corner_df, count_edges_crop, count, DB_border_coor, sides, AB_border_coor = cls.process_images(input_file_path)
            new_rows = [{'Metadata': 'FourCorners', 'Values': f"{count}_Corners detected"},
                        {'Metadata': 'FourCornersCoor', 'Values': str(DB_border_coor)},
                        {'Metadata': 'ImageCroppedSides', 'Values': f"{count_edges_crop}_Sides cropped"},
                        {'Metadata': 'ImageCroppedSides', 'Values': sides}]
            four_corner_df2 = pd.DataFrame(new_rows)
        else:
            four_corner_df = pd.DataFrame()
            four_corner_df2 = pd.DataFrame()
            

        if len(metadata_df):
            editing_software = cls.editing_software(metadata_df.loc[metadata_df['Metadata'] == 'Creator', 'Values'].values[0])
            if editing_software:
                metadata_report = pd.DataFrame({
                    'Rule': ['Producer editing Software'],
                    'Flag': [1],
                    'Severity_Level': ['HIGH'],
                    'Insight': ['Editing Software as producer detected in metadata']
                })
            else:
                metadata_report = pd.DataFrame(columns=['Rule', 'Flag', 'Severity_Level', 'Insight'])
        else:
            metadata_report = pd.DataFrame(columns=['Rule', 'Flag', 'Severity_Level', 'Insight'])
            

        metadata_report = pd.concat([metadata_report, four_corner_df])
        


        metadata_df = pd.concat([metadata_df, four_corner_df2], ignore_index=True)

        return metadata_df, metadata_report, cls.meta_error_list #, DB_border_coor, AB_border_coor 

    
    
    
    
if __name__ == "__main__":

    import io

    def write_to_excel(df_list):
        excel_bytes_io = io.BytesIO()
        with pd.ExcelWriter(excel_bytes_io, engine='xlsxwriter') as writer:
            for df in df_list:
                pd.DataFrame(df["df"]).to_excel(writer, sheet_name=df["sheet_name"])

        excel_bytes = excel_bytes_io.getvalue()
    
    import os
    input_file_path = "Image_input_output/Demo_Input_Image.png"
    overlay_output_image_path = os.path.join("output", "images", "metadata")
    metadata_df = Metadata.metadata_entry(input_file_path)
    dataframes = [ {'df': metadata_df, 'sheet_name': 'Metadata'}]
    write_to_excel(dataframes)
    # print(metadata_df)


