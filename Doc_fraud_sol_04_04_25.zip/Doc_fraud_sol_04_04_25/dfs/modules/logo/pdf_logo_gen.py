import fitz 
import io
from PIL import Image
from PIL import ImageChops
import pandas as pd
import numpy as np
import os
import imagehash
import re
from pathlib import Path
from dfs.commons import constants



class LogoModule:
    logo_error_list = []
    @staticmethod
    def get_expected_value(bank_name):
        if bank_name == '':
            return ''
        #fileName = "Logo Repository.xlsx"    

        df = pd.read_excel(constants.LOGO_REPOSITORY_PATH_GEN ,sheet_name='coor_repo')
        df.set_index('Bank',inplace=True)
        df = df.fillna('')
        # df = logo_repo
        try:
            Expected_image_count = df.loc[bank_name]['Image_count'].tolist()
            Expected_image_area = df.loc[bank_name]['Image_area'].tolist()
            Expected_coordiante = list(df.loc[bank_name]['Logo_coordinate'])
            Expected_Value = [Expected_image_count,Expected_image_area,Expected_coordiante]
            return Expected_Value
        except:
            return ''


    # function to get coordinate
    '''def get_image_origins(pdf_file, page_index):

        #pdf_file_document = fitz.open(pdf_file)
        pdf_file_document = fitz.open(stream = pdf_file, filetype = "pdf")


        image_list = pdf_file_document.get_page_images(pno=page_index, full=True)
        image_bounding_boxes = []

        for image_index, image_item in enumerate(image_list):
            image_code_name = image_item[7]

            # The format of _image_bounding_box is (x_min, y_min, x_max, y_max) for each images inside the page.
            #image_rects = pdf_file_document[page_index].get_image_rects(image_code_name, transform=True)
            image_box = pdf_file_document[page_index].get_image_bbox(image_item, transform=True)

            if len(image_box) > 0:
                image_bounding_box = image_box[0]
                image_bounding_boxes.append(image_bounding_box)

        return image_bounding_boxes'''
    @staticmethod
    def get_image_origins(file_path,page_index):

        # pdf_file = fitz.open(stream = file_path, filetype="pdf")

        #for page_index in range(len(pdf_file)):
        pdf_file_document = fitz.open(file_path)
        # pdf_file_document = pdf_file
        
        image_list = pdf_file_document.get_page_images(pno=page_index, full=True)
        #print(image_list)
        image_bounding_boxes = []

        for image_index, image_item in enumerate(image_list):
            image_code_name = image_item[7]

            # The format of _image_bounding_box is (x_min, y_min, x_max, y_max) for each images inside the page.
            #image_rects = pdf_file_document[page_index].get_image_rects(image_code_name, transform=True)
            image_box = pdf_file_document[page_index].get_image_bbox(image_item, transform=True)
            #print(image_box)

            if len(image_box) > 0:
                if len(image_box) == 4:
                    image_bounding_box = image_box
                else:
                    image_bounding_box = image_box[0]
                image_bounding_boxes.append(image_bounding_box)
                #print(image_bounding_boxes)


        return image_bounding_boxes


    # In[4]:


    # function to get image
    @staticmethod
    def get_image(pdf_file, page_index,image_output_dir):

        # get the page itself
        page = pdf_file[page_index]    
        image_list = page.get_images()
        image_output = []

        # printing number of images found in this page

        '''if image_list:
            print(f"[+] Found a total of {len(image_list)} images in page {page_index}")
        else:
            print("[!] No images found on page", page_index)'''

        for image_index, img in enumerate(page.get_images(), start=1):

            # get the XREF of the image
            xref = img[0]

            # extract the image bytes
            base_image = pdf_file.extract_image(xref)
            image_bytes = base_image["image"]

            # get the image extension
            image_ext = base_image["ext"]

            # load it to PIL
            # dataBytesIO = io.BytesIO(image_bytes)
            #print(dataBytesIO)
            
            # load it to PIL
            image = Image.open(io.BytesIO(image_bytes))
            
            # save the path to the output
            # TODO: Remove post io update
            image_path = os.path.join(
                image_output_dir, f"image{page_index + 1}_{image_index}.{image_ext}")
            image.save(open(image_path, "wb"))
            image_output.append(image_path)



            '''print("\n")
            print("Intermediate_path inside logo module is ->>>", Intermediate_path)
            print("\n")
            import re
            print("\n")
            logo__images_path = re.sub('Intermediate', '', Intermediate_path)
            print("logo__images_path", logo__images_path)
            print("\n")'''
            # save the path to the output
            # save_location = path_logo
            '''save_location = logo__images_path +u_id+'_Images/Logo'
            #save_location = os.getcwd()+'/Output/'+u_id+'_Images/Logo'
            if not os.path.exists(save_location):
                os.makedirs(save_location) '''
            # ImageFileName = f"image{page_index+1}_{image_index}.{image_ext}"

            # image_path = save_location + ImageFileName

            #print(image_path)

            '''image.save(open(image_path, "wb"))
            bytes_obj_image = image.tobytes(output='png')'''

            # s3_data[3].put_object(Bucket= s3_data[2],Body=image_bytes, Key= image_path)
            # pix.save(save_location+'/'+ImageFileName)
            '''if image_ext != 'jb2':
                image_output.append(image_path)'''


            # image_output.append(image_path)


        return image_output


    # In[5]:

    @staticmethod
    def get_area(bbox):

        width = abs(bbox[2] - bbox[0])
        height = abs(bbox[3] - bbox[1])
        area = width*height
        
        return area
    
    # function 2: compare similarity between images based on perceptual hashing algorithms: scale the original image to 8*8 graysclae image 
    @staticmethod
    def get_similarity(image1, image2):

        hash1 = imagehash.average_hash(image1)
        hash2 = imagehash.average_hash(image2)

        return 1 - (hash1-hash2)/64  
    
    @staticmethod
    def get_imagesize(image1,image2):
        
        l1 = image1.size[0]
        h1 = image1.size[1]
        l2 = image2.size[0]
        h2 = image2.size[1]
        a1 = l1*h1
        a2 = l2*h2

        return abs(a2-a1)/a1 < 0.1

    # In[6]:

    @staticmethod
    def get_overlap(coor1, coor2):
        try:
            R1 = coor1[5:-1].split(', ')
            R1 = [float(r1) for r1 in R1]

            R2 = coor2[5:-1].split(', ')
            R2 = [float(r2) for r2 in R2]
        except:
            return 0
        


        # Co-ordinate system origin is assumed to be on top left corner of the screen.
        # coordinates of the area of intersection. 
        x1 = np.maximum(R1[0], R2[0]) ;     y1 = np.maximum(R1[1], R2[1])
        x2 = np.minimum(R1[2], R2[2]) ;     y2 = np.minimum(R1[3], R2[3])

        # Different Areas    
        area_of_intersection = (np.maximum(y2 - y1 , np.array(0.0))) * (np.maximum(x2 - x1 , np.array(0.0)))

        A1 = ( (R1[3] - R1[1] ) * (R1[2] - R1[0] ) )

        return area_of_intersection/A1


    # In[146]:


    # rule based logo module without repository
    @classmethod
    def without_repo(cls,file_path,image_output_dir):


        # open the file
        pdf_file = fitz.open(file_path)
        # pdf_file = fitz.open(stream = file_path, filetype = 'pdf')

        # create empty dataframe to store output
        original_page = []

        original_coor = []

        suspicious_page = []

        suspicious_coor = []

        image_similarity = []

        insights = []

        severity = []

        Page_num = []

        Image_num = []

        Coordinates = []

        # empty list to store dictionary for each page
        repo = []


        # iterate through all the pages in pdf file
        for page_index in range(len(pdf_file)):

            image_origins = cls.get_image_origins(file_path,page_index)
            #print(image_origins)
            #image_origins = get_image_origins(pdf_file, page_index)

            # check the number of images found on this page
            image_num = len(image_origins)
            '''print('image_num',image_num)
            print('range(image_num)',range(image_num))
            print('len(image_origins)',len(image_origins))'''



            # if there is image detected in one page
            if image_num > 0: 

                # get the logo image
                #image_output = get_image(pdf_file, page_index,u_id, Intermediate_path)
                image_output = cls.get_image(pdf_file, page_index,image_output_dir)

                #print('len(image_output)',len(image_output))
                # create dictionary
                res = {image_origins[i]: image_output[i] for i in range(image_num)}


                # create dataframe for output
                Page_num += [page_index]*image_num

                Image_num += range(1, image_num+1)

                Coordinates += [image_origins[i] for i in range(image_num)]          

            # if no image is detected on certain page    
            else:

                res = {}

            # store the dictionary in our repo
            repo.append(res)
            #print('repo',repo)

        #print('repo_final',repo)

        # df1 contains information regarding page number and image number and image coordinates for all pages
        df1 = pd.DataFrame(list(zip(Page_num, Image_num, Coordinates)), columns = ['Page_Num','Image_Num','Coor'])
        #print(df1)
        # define some functions that we will use later

        # function 1: get all the page number based on image coordinates
        def get_allpages(coor):
            df = df1[df1['Coor'] == coor]
            pages = []
            for i in range(len(df)):    
                pages.append(df['Page_Num'].iloc[i])
            return pages

        # function 2: compare similarity between images based on perceptual hashing algorithms: scale the original image to 8*8 graysclae image 
        
#         def get_similarity(image1, image2):

#             hash1 = imagehash.average_hash(image1)
#             hash2 = imagehash.average_hash(image2)

#             return 1 - (hash1-hash2)/64  

        # function 3: compare the difference between image sizes
#         def get_imagesize(image1,image2):

#             l1 = image1.size[0]
#             h1 = image1.size[1]
#             l2 = image2.size[0]
#             h2 = image2.size[1]
#             a1 = l1*h1
#             a2 = l2*h2

#             return abs(a2-a1)/a1 < 0.1

        # df2 contains information regarding same coordinates that appear on multiple pages
        df2 = df1.Coor.value_counts().reset_index(name="count").query("count > 1")



        df2['Pages'] = df2['Coor'].apply(get_allpages)  
        #print(df2)

        #print(df2)
        pdf_highlighting_coordinates = []
        # loop through every row in df2 (every coordinate that appears more than once in the document)
        for i in range(len(df2)):

            # get the coordinate that appears more than once
            coor1 = df2['Coor'].iloc[i]

            # get the corresponding page numbers
            page_numbers = df2['Pages'].iloc[i]

            # get the image from one of these pages, for calculating image size
            image_path1 = repo[page_numbers[0]][coor1]
            
            if 'jb2' not in image_path1:
                image1 = Image.open(image_path1)
                # file_stream_image_path1 = s3_data[0].get_object(Bucket = s3_data[2], Key = image_path1)['Body']
                # image1 = Image.open(file_stream_image_path1)
            # #image1 = Image.open(image_path1)

            # loop through all the images where the coordinate is not there    
            for page in range(len(pdf_file)):
                if page not in page_numbers:
                    # retrieve information for all the images on this page
                    temp = df1[df1['Page_Num'] == page]

                    # for every image 
                    for i in range(len(temp)):
                        # check its coordinates
                        coor2 = temp['Coor'].iloc[i]

                        # also open the image, for calculating image size
                        image_path2 = repo[page][coor2]
                        
                        if 'jb2' not in image_path2:
                            image2 = Image.open(image_path2)
                        #     file_stream_image_path2 = s3_data[0].get_object(Bucket = s3_data[2], Key = image_path2)['Body']
                        #     image2 = Image.open(file_stream_image_path2)
                          

                        # compare the coordinates and image size, make sure similarity of both is larger than 0.9


                        if cls.get_overlap(str(coor1), str(coor2)) >= 0.8 and cls.get_imagesize(image1,image2):

                            # if this kind of image is found, now we compare the image similarity 
                            simis = []

                            # compare the suspicious image with all the images that are located on coor1
                            # because they might be different, even though they are on the same coordinates (coor1)
                            for n in page_numbers:
                                image_path = repo[n][coor1]
                            
                                if 'jb2' not in image_path:
                                #     file_stream_image_path = s3_data[0].get_object(Bucket = s3_data[2], Key = image_path)['Body']
                                #     image = Image.open(file_stream_image_path)
                                    image = Image.open(image_path)
                                    simi = cls.get_similarity(image,image2)
                                    simis.append(simi)

                            # calculate the average similarity and save it for output    
                            avg_simi = sum(simis)/len(simis)

                            # append all the values needed for output
                            original_page.append(page_numbers)

                            original_coor.append(coor1)

                            suspicious_page.append(page)

                            suspicious_coor.append(coor2)

                            image_similarity.append(avg_simi)

                            insights.append('Suspicious image found')

                            severity.append('HIGH')

                            # draw bounding box on the suspicious image we found
                            Page = pdf_file[page]
                            pdf_highlighting_coordinates.append((page, coor2))
                            # Page.draw_rect(coor2,  color = (0, 1, 0), width = 2)



        # saving results
        '''Intermediate_path_logo = Intermediate_path + '/' + '2_logo_bbox.pdf'
        pdf_file.save(Intermediate_path_logo)'''

        # pdf_bytes = pdf_file.write()
        # s3_data[0].put_object(Bucket=s3_data[2],Body =pdf_bytes,  Key=path_intermediate + '2_logo_bbox.pdf')
        #pdf_file.save('Intermediate/2_logo_bbox.pdf')

        # df3 contains the final report for logo module
        df3 = pd.DataFrame(list(zip(original_page, original_coor, suspicious_page, suspicious_coor, image_similarity, insights, severity)), columns = ['Original_Page',' Original_Coor','Suspicious_Page','Suspicious_Coor','Image_Similarity','Insight','Severity_Level'])
        #print(df3)


        return df1, df3, pdf_highlighting_coordinates


    @staticmethod
    def is_within_threshold_percent(value,threshold,exp_value):
        return exp_value - threshold*exp_value <= value <= exp_value + threshold*exp_value
    @classmethod
    def check_threshold_range_area(cls,value, threshold,expected_value):
        result = [cls.is_within_threshold_percent(value,threshold,exp_value) for exp_value in expected_value]
        return any(x == True for x in result)
    @staticmethod
    def is_within_threshold(value,threshold,exp_value):
        return exp_value - threshold <= value <= exp_value + threshold
    @classmethod
    def check_threshold_range_coord(cls,value, threshold,expected_value):
        result = [cls.is_within_threshold(value,threshold,exp_value) for exp_value in expected_value]
        return any(x == True for x in result)

#     def get_similarity(image1, image2):

#         hash1 = imagehash.average_hash(image1)
#         hash2 = imagehash.average_hash(image2)

#         return 1 - (hash1-hash2)/64  

#     def get_overlap(coor1, coor2):
#         try:
#             R1 = coor1[5:-1].split(', ')
#             R1 = [float(r1) for r1 in R1]

#             R2 = coor2[5:-1].split(', ')
#             R2 = [float(r2) for r2 in R2]
#         except:
#             return 0

        # Co-ordinate system origin is assumed to be on top left corner of the screen.
        # coordinates of the area of intersection. 
#         x1 = np.maximum(R1[0], R2[0]) ;     y1 = np.maximum(R1[1], R2[1])
#         x2 = np.minimum(R1[2], R2[2]) ;     y2 = np.minimum(R1[3], R2[3])

#         # Different Areas    
#         area_of_intersection = (np.maximum(y2 - y1 , np.array(0.0))) * (np.maximum(x2 - x1 , np.array(0.0)))

#         A1 = ( (R1[3] - R1[1] ) * (R1[2] - R1[0] ) )

#         return area_of_intersection/A1

        

    # logo module with repository
    @classmethod
    def with_repo(cls,file_path, bank_name,path_intermediate,image_output_dir, logo_repo_dir):

    # with_repo(file_path,bank_name,u_id,Intermediate_path):
        # def checkPath(file_path,s3_data):
        #     result = s3_data[0].list_objects(Bucket=s3_data[2], Prefix=file_path )
        #     exists=False
        #     if 'Contents' in result:
        #         exists=True
        #     return exists

        '''print("with_repo -> file_path", file_path)
        print("\n")
        print("with_repo -> u_id", u_id)
        print("--------------------------------------------")'''


        expected_value = cls.get_expected_value(bank_name)

        logo_list = ['Image_Count','Image_Area','Logo_Coordinate']
        real_values = ['']*3

        # open the first page of the file
        pdf_file = fitz.open(file_path)
        
        # pdf_file = fitz.open(stream = file_path, filetype = 'pdf')

        for Page_Number_1 in range(pdf_file.page_count):
            page_1 = pdf_file.load_page(Page_Number_1) #load page
            text_1 = page_1.get_text()
            if text_1.strip():
                pdf_type = "Input PDF is text based"
                break
            elif page_1.get_pixmap():
                pdf_type = "Input PDF is image based"
                break

        page_index = 0    

        # get the coordinates of images
        #image_origins = get_image_origins(pdf_file, page_index)
        image_origins = cls.get_image_origins(file_path,page_index)

        # check the number of images found 
        image_num = len(image_origins)    
        real_values[0] = image_num

        # if there is at least one image detected in one page
        if image_num > 0: 

            # calculate the total area of images
            areas = [cls.get_area(image_origins[i]) for i in range(image_num)]        
            total_area = sum(areas)    

            # get the logo images and store them
            #image_output = get_image(pdf_file, page_index,u_id, Intermediate_path)
            # image_output = cls.get_image(pdf_file, page_index,u_id,path_logo,s3_data)
            image_output = cls.get_image(pdf_file, page_index,image_output_dir)

            # create dictionary for coordinates and images
            res = {image_origins[i]: image_output[i] for i in range(image_num)}

        # if no image is detected    
        else:            
            total_area = 0  
            res = ''

        real_values[1] = total_area

        df1 = pd.DataFrame(list(zip(logo_list, real_values)), columns = ['Feature', 'Real_Value'])
        df1['Expected_Value'] = expected_value
        #df1['Expected_Value'] = df1['Expected_Value'].apply(lambda x: [str(x)])
        Match = ['']*3
        Rule = ['Image_Count_Same','Total_Area_Same','Logo_Coor_Same','Logo_Image_Same']
        Flag = [0]*4
        Insight = ['Image count not matching','Total area of images not matching','Logo coordinates not matching','Logo images not matching']
        Severity = ['Medium','Medium','High','High']
        
        pdf_highlighting_coordinates = []
        #print(df1)
        #print(df1['Real_Value'].iloc[0])
        #print (df1['Expected_Value'].iloc[0],df1['Real_Value'].iloc[0])
        # Image_count logic
        if df1['Expected_Value'].iloc[0] != '':
            #print(df1['Expected_Value'].iloc[0],df1['Real_Value'].iloc[0])
            #df1['Expected_Value'].iloc[i] = float(df1['Expected_Value'].iloc[i][0])
            if df1['Real_Value'].iloc[0] in df1['Expected_Value'].iloc[0]:
                Match[0] = 'Yes'
                Flag[0] = 0
            else:
                Match[0] = 'No'
                Flag[0] = 1
        # image_area logic
        if df1['Expected_Value'].iloc[1] != '':
            #print(df1['Expected_Value'].iloc[1],df1['Real_Value'].iloc[1])
            #df1['Expected_Value'].iloc[i] = float(df1['Expected_Value'].iloc[i][0])

            if cls.check_threshold_range_area(df1['Real_Value'].iloc[1],0.1,df1['Expected_Value'].iloc[1]):
            #if df1['Real_Value'].iloc[1] in df1['Expected_Value'].iloc[0]:
                Match[1] = 'Yes'
                Flag[1] = 0
            else:
                Match[1] = 'No'
                Flag[1] = 1



        # check if any image coordiante matches the repo 
        expected_coor = df1['Expected_Value'].iloc[2]   
        #print(expected_coor)
        #print(res)

        #res = {expected_coor[i]: image_output[i] for i in range(image_num)}
        # if expected coordinate is in the repo and there is image detected from first page
        if expected_coor != '' and res !='':
            #For i in range(
            # get the expected image
            
            #--------------------new logic lines
            logo_repo_dir = constants.LOGO_REPO_PATH_GEN
            files = os.listdir(logo_repo_dir)
            list_1 = [re.search(r'\d+', file).group() for file in files if file.lower().endswith((".jpg", ".png", ".jpeg")) and bank_name.lower() in file.lower()]


            # list_1 =[]
            # s3_object_iterator_logo = s3_data[3].objects.filter(Prefix= path + f"Logo_Repo/")
            # for s3_object_logo in s3_object_iterator_logo:
            #     s3_object_key0_logo = s3_object_logo.key
            #     s3_object_key1_logo = Path(s3_object_key0_logo).name
            #     s3_object_key1_logo = s3_object_key1_logo.replace('.jpeg','')
            #     s3_object_key1_logo = s3_object_key1_logo.replace('.png','')
            #     if bank_name in s3_object_key1_logo :
            #         s3_object_key1_logo = s3_object_key1_logo.replace(bank_name ,'')
            #         s3_object_key1_logo = s3_object_key1_logo.replace('_' ,'')
            #         list_1.append(s3_object_key1_logo)

            #loop_length = int(max(list_1))
            expected_image = []
            #print(list_1)
            #print(len(list_1)-1)

            #for j in range(len(list_1)-1):
            for j in range(int(max(list_1))+1): 
                #print (j)
#                 image_path_png = path + f"Logo_Repo/{bank_name}_{j}.png"
#                 #print(image_path_png)
#                 image_path_jpeg = path + f"Logo_Repo/{bank_name}_{j}.jpeg"
#                 #print(image_path_jpeg)
                
#                 expected_image = Image.open(os.path.join(
#                     logo_repo_dir, f"{bank_name}_{j}.png"))
#                 #print(checkPath(image_path_jpeg,s3_data))
#                 if checkPath(image_path_png,s3_data) == True: 
#                     obj_png = s3_data[0].get_object(Bucket = s3_data[2], Key = image_path_png)
#                     file_stream_png = obj_png['Body']
#                 if checkPath(image_path_jpeg,s3_data) == True: 
#                     obj_jpeg = s3_data[0].get_object(Bucket = s3_data[2], Key = image_path_jpeg)
#                     file_stream_jpeg = obj_jpeg['Body']
                #print(file_stream_png)`
                #print(file_stream_jpeg)
                #print(expected_image)

                try:
                    expected_image.append(Image.open(os.path.join(logo_repo_dir, f"{bank_name}_{j}.png")))
                    # expected_image.append(Image.open(file_stream_png))
                    #print(file_stream_png)
                except:
                    expected_image.append(Image.open(os.path.join(logo_repo_dir, f"{bank_name}_{j}.jpeg")))
                    # expected_image.append(Image.open(file_stream_jpeg))
                    #print(file_stream_jpeg)
            #print(expected_image)




            for key in res.keys(): 
                print(key)
                # if matching coordinates found
                for i in range(len(expected_coor)) :
                    key_coord_list = str(key)[5:-1].split(', ')
                    key_coord_list = [float(r1) for r1 in key_coord_list]
                    # print(key_coord_list)
                    # print(expected_coor)
                    expected_coord_list = expected_coor[i][5:-1].split(', ')
                    expected_coord_list = [float(r1) for r1 in expected_coord_list]
                    # print(expected_coord_list)
                    # print(key_coord_list[0])
                    # print(expected_coord_list[0])


                    if str(expected_coor[i]) == str(key):
                        flag_list =[]   
                        df1['Real_Value'].iloc[2] = str(key)
                        Match[2] = 'Yes'
                        if 'jb2' not in res[key]:
                        #     file_stream_res = s3_data[0].get_object(Bucket = s3_data[2], Key = res[key])['Body']
                            # real_image = Image.open(file_stream_res)
                            #real_image.show()
                            real_image = Image.open(res[key])
                            # compare the images
                            for j in range(len(expected_image)):
                                #expected_image[j].show()
                                flag_list.append(cls.get_similarity(expected_image[j], real_image))
                            #print(flag_list)

                            if all(f < 0.95 for f in flag_list):
                                Flag[3] = 1
                                Page = pdf_file[0]
                                pdf_highlighting_coordinates.append((0, key))
                                # Page.draw_rect(key,  color = (0, 1, 0), width = 2)

                    elif  cls.is_within_threshold(key_coord_list[0],5,expected_coord_list[0]) and cls.is_within_threshold(key_coord_list[1],5,expected_coord_list[1]):
                        flag_list =[]   
                        df1['Real_Value'].iloc[2] = str(key)
                        Match[2] = 'Yes'
                        if 'jb2' not in res[key]:
                            # file_stream_res = s3_data[0].get_object(Bucket = s3_data[2], Key = res[key])['Body']
                            # real_image = Image.open(file_stream_res)
                            #real_image.show()
                            real_image = Image.open(res[key])
                            # compare the images
                            for j in range(len(expected_image)):
                                #expected_image[j].show()
                                flag_list.append(cls.get_similarity(expected_image[j], real_image))
                            #print(flag_list)

                            if all(f < 0.95 for f in flag_list):
                                Flag[3] = 1
                                Page = pdf_file[0]
                                pdf_highlighting_coordinates.append((0, key))
                                # Page.draw_rect(key,  color = (0, 1, 0), width = 2)



            # if no matching coordinates found        
            if Match[-1] == '':
                Match[2] = 'No'
                Flag[2] = Flag[3] = 1

                # compare all the images with expected image
                for key in res.keys():
                    if 'jb2' not in res[key]:
                        # file_stream_res1 = s3_data[0].get_object(Bucket = s3_data[2], Key = res[key])['Body']
                        # real_image = Image.open(file_stream_res1)
                        real_image = Image.open(res[key])
                        # if matching image is found
                        #print(real_image.size)
                        #print([expected_image[x].size for x in range(len(expected_image))])
                        if real_image.size in [expected_image[x].size for x in range(len(expected_image))] :
                            flag_list =[]
                            for j in range(len(expected_image)):
                                #expected_image[j].show()
                                flag_list.append(cls.get_similarity(expected_image[j], real_image))
                            #print(flag_list)
                            if all(f < 2 for f in flag_list):
                            #if get_similarity(expected_image, real_image) < 0.95:
                                Flag[3] = 0
                                df1['Real_Value'].iloc[2] = str(key)
                                percentage = max([cls.get_overlap(str(key),expected_coor[x]) for x in range(len(expected_coor))])
                                #print(percentage)
                                Insight[-2] = f"Detected logo coordinate is overlapping with true coordinate with percentage of {percentage*100}%"
                                Page = pdf_file[0]
                                pdf_highlighting_coordinates.append((0, key))
                                # Page.draw_rect(key,  color = (0, 1, 0), width = 2)

            # area greater than 400k and image_num >10 are not considered
            if total_area >400000 or image_num >10 or pdf_type == "Input PDF is image based" :
                Match[0] = ''
                Flag[0] = 0
                Match[1] = ''
                Flag[1] = 0
                Match[2] = ''
                Flag[2] = 0
                Flag[3] = 0



        '''Intermediate_path_logo = Intermediate_path + '/' + '2_logo_bbox.pdf'
        pdf_file.save(Intermediate_path_logo)'''

        # pdf_bytes = pdf_file.write()
        # s3_data[0].put_object(Bucket=s3_data[2],Body =pdf_bytes,  Key=path_intermediate + '2_logo_bbox.pdf')
        #pdf_file.save('Intermediate/2_logo_bbox.pdf')
        df1['Match'] = Match         
        Insight  = [Insight[i] if Flag[i] == 1 else '' for i in range(len(Flag))]
        Severity  = [Severity[i] if Flag[i] == 1 else '' for i in range(len(Flag))]
        df2 = pd.DataFrame(list(zip(Rule, Flag, Severity, Insight)), columns = ['Rule', 'Flag','Severity_Level','Insight'])                  


        return df1,df2,pdf_highlighting_coordinates



    # In[90]:

    @classmethod
    def main_logo(cls,file_path, bank_name,image_output_dir):
        #(file_path, bank_name, u_id, final_report_insight, Intermediate_path)
        logo_repo_dir = constants.LOGO_REPO_PATH_GEN
        print("Main_logo running")
        if cls.get_expected_value(bank_name) == '':
            df1, df2, pdf_highlighting_coordinates = cls.without_repo(file_path, image_output_dir)
        else:
            df1, df2,pdf_highlighting_coordinates = cls.with_repo(file_path, bank_name, image_output_dir, logo_repo_dir)
            
        return df1, df2,pdf_highlighting_coordinates
    
    @classmethod
    def return_final_report(cls, df, final_report_insight):

        df3 = df[['Insight','Severity_Level']]
        df3['Module'] = 'Logo'
        df3.columns = ['Alerts','Severity', 'Module']
        df3 = df3[['Module','Alerts', 'Severity']]
        final_report_insight = pd.concat([final_report_insight,df3])
        
        return final_report_insight, cls.logo_error_list

            
    @classmethod
    def write_to_excel(cls, df, fraud_report_file_path, mode, sheetname):
        df.insert(0, 'Sr_no', range(1, len(df) + 1))
        mode = 'a'
        if not os.path.exists(fraud_report_file_path):
            mode = 'w'
        with pd.ExcelWriter(fraud_report_file_path, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name=sheetname, index=False)
    
    @classmethod
    def save_highlighted_pdf(cls, pdf_file, highlighted_pdf_file_path, pdf_highlighting_coordinates):
        doc = fitz.open(pdf_file)
        for page, coord in pdf_highlighting_coordinates:
            doc[page].draw_rect(coord, color=(0, 1, 0), width=2)

        doc.save(highlighted_pdf_file_path)
    
if __name__ == '__main__':
    input_next_module = 'document_fraud_detection/Wells_Fargo_Input.pdf'
    bank_names = ['Chase', 'Wells Fargo']
    bank_name = bank_names[1]
    final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
    fraud_report_file_path = 'test/report.xlsx'
    logo_output_pdf_path = "test/pdf_files/logo_output.pdf"
    image_logo_dir = "test/images/logo"
    os.makedirs(image_logo_dir, exist_ok=True)
    os.makedirs("test/pdf_files/", exist_ok=True)

    df1, df2, pdf_highlighting_coordinates = LogoModule.main_logo(
        input_next_module, bank_name, image_logo_dir)
    LogoModule.save_highlighted_pdf(
        input_next_module, logo_output_pdf_path, pdf_highlighting_coordinates)
    final_report_insight = LogoModule.return_final_report(
        df2, final_report_insight)

    mode = 'a'
    if not os.path.exists(fraud_report_file_path):
        mode = 'w'

    LogoModule.write_to_excel(
        df1, fraud_report_file_path, mode, '2A.Logo_Raw_Output')
    LogoModule.write_to_excel(
        df2, fraud_report_file_path, 'a', '2B.Logo_Report')