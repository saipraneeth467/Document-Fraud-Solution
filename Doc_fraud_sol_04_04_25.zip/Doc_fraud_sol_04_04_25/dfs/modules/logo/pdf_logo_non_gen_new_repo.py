# IMPORTING REQUIRED LIBRARIES

import os
import io
import re
import fitz
import imagehash
import numpy as np
import pandas as pd
from PIL import ImageChops, Image
from dfs.commons import constants
from dfs.commons.ioutils.datastore_utils import read_from_data_lake, write_to_data_lake, list_dir_files

class LogoModule:
    logo_error_list = []

    @staticmethod
    # Function to fetch expected logo coordinates corresponding to Bank name
    def get_expected_value(bank_name, logo_repo):
            
        df = logo_repo     
        if bank_name == '' or (bank_name not in df.index):
            return ''              
        try:
            # display(df)
            Expected_image_area = df.loc[df.index == bank_name, 'Image_area'].tolist()
            df['Logo_coordinate'] = df['Logo_coordinate'].apply(lambda x: list(map(float, x.strip("[]").split(", "))))
            # Expected_coordiante = df.loc[bank_name]['Logo_coordinate'].tolist()
            Expected_coordinate = df.loc[df.index == bank_name, 'Logo_coordinate'].tolist()
            expected_Value = [Expected_image_area,Expected_coordinate]
            return expected_Value
        except:
            print('bank_name not found')
            return ''

    # Function to fetch coordinates of all images present in the ceratin page of the PDF.
    @classmethod
    def get_image_origins(cls,file_path, page_index):
        try:
            pdf_file = fitz.open(stream=file_path, filetype="pdf")
        except:
            cls.logo_error_list.append("Logo: Unable to read file")
            print('logo_error_list-------',cls.logo_error_list)
            return cls.logo_error_list

        pdf_file_document = pdf_file
        page = pdf_file_document[page_index] 
        image_list = pdf_file_document.get_page_images(pno=page_index, full=True)
        image_bounding_boxes = []
        page_width = page.rect.width
        
        for _, image_item in enumerate(image_list):
            image_box = page.get_image_bbox(image_item, transform=True)
            if len(image_box) > 0:
                if len(image_box) == 4:
                    image_bounding_box = image_box
                else:
                    image_bounding_box = image_box[0]
                image_bb_area = 0
                image_bounding_boxes.append(image_bounding_box)
                    
        return image_bounding_boxes

    # Saving all images of particular page of PDF
    @classmethod
    def get_imagedetails(cls,pdf_file, page_index, save_location_path):
        try:
            page = pdf_file[page_index]
        except:
            cls.logo_error_list.append("Logo: Unable to read file")
            print('logo_error_list-------',cls.logo_error_list)
            return cls.logo_error_list

        image_output = []
        for image_index, img in enumerate(page.get_images(), start=1):
            xref = img[0]
            base_image = pdf_file.extract_image(xref)
            image_bytes = base_image["image"]
            image_ext = base_image["ext"]
            image_file_name = f"image{page_index+1}_{image_index}.{image_ext}"
            image_path = save_location_path + image_file_name
            # write_to_data_lake(image_bytes, image_path)
            image_output.append([image_bytes,image_file_name])
        return image_output
    
    @staticmethod
    def valid_image_check(origin, page_width, page_height):
        x0, y0, x1, y1 = origin
        width, height = x1 - x0, y1 - y0
        valid_check = False
        if width >= 25 and height >= 25 and width <= 0.37 * page_width and height <= 0.4 * page_height:
            if y0 <= 0.3*page_height or y1>= 0.7*page_height:
                valid_check = True
        return valid_check    

    # To compare similarity between images based on perceptual hashing algorithms: 
    # Scale the original image to 8*8 graysclae image 
    
    @staticmethod
    def convert_to_pil(image):
        """Ensure the image is in PIL format."""
        if isinstance(image, bytes):  # If image is in bytes
            return Image.open(io.BytesIO(image))
        elif isinstance(image, Image.Image):  # If already a PIL image
            return image
        else:
            raise ValueError("Unsupported image format")
    
    @classmethod
    def get_similarity(cls,image1, image2):   
        try:
            image1 = cls.convert_to_pil(image1)
            image2 = cls.convert_to_pil(image2)
            hash1 = imagehash.average_hash(image1)
            hash2 = imagehash.average_hash(image2)
            return 1 - (hash1-hash2)/64
        except:
            return 0

    # Calculating Overlap area of 2 images
    @staticmethod
    def get_overlap(coor1, coor2):
        try:
            r1 = list(coor1)
            r2 = list(coor2)
        except:
            return 0

        # Co-ordinate system origin is assumed to be on top left corner of the screen.
        # coordinates of the area of intersection.
        x1, y1 = np.maximum(r1[0], r2[0]), np.maximum(r1[1], r2[1])
        x2, y2 = np.minimum(r1[2], r2[2]), np.minimum(r1[3], r2[3])

        # Different Areas
        area_of_intersection = (np.maximum(y2 - y1, np.array(0.0))) * (np.maximum(x2 - x1, np.array(0.0)))
        a1 = ((r1[3] - r1[1]) * (r1[2] - r1[0]))
        return area_of_intersection/a1
    
    @staticmethod
    def get_height_overlap(coor1, coor2):
        try:
            r1, r2 = list(coor1), list(coor2)
        except:
            return 0
        
        coor1_y1, coor2_y1 = r1[1], r2[1]
        height_img1 = abs(r1[3] - r1[1])
        return abs(coor1_y1 - coor2_y1) / height_img1
    
    # function : Compare the difference between image sizes
    @classmethod
    def get_imagesize(cls, image1, image2):
        image1 = cls.convert_to_pil(image1)
        image2 = cls.convert_to_pil(image2)
        w1, h1 = image1.size[0], image1.size[1]
        w2, h2 = image2.size[0], image2.size[1]
        a1 = w1*h1
        a2 = w2*h2
        return abs(a2-a1)/a1
    
    @classmethod
    def without_repo(cls, file_path, logo_output_path, expected_value_repo):

        pdf_file = fitz.open(stream=file_path, filetype='pdf')
        # create empty dataframe to store output
        original_coor = []
        suspicious_page = []
        suspicious_coor = []
        insights = []
        flag =[]
        severity = []
        page_num = []
        image_nums = []
        coordinates = []
        highlighting_coords = []
        repo = []
        expected_coor = [] if expected_value_repo == "" else [tuple(i) for i in expected_value_repo[1]]
        
        # iterate through all the pages in pdf file
        for page_index in range(len(pdf_file)):
            page = pdf_file[page_index]
            page_width = page.rect.width
            page_height = page.rect.height

            #Getting the coordinates of all images present in that page.
            image_origins = cls.get_image_origins(file_path, page_index)
            image_num = len(image_origins)
            
            # Creating a dict to store valid images coor and image_path
            res = {}
            # if there is image detected in page
            if image_num > 0:
                valid_images = {}
                for image_num, origin in enumerate(image_origins):
                    # Images that satisfy the conditions are only valid for logo comparison
                    if cls.valid_image_check(origin, page_width, page_height):
                        valid_images[image_num] = tuple([round(float(i),2) for i in origin])
                
                if valid_images:
                    image_output = cls.get_imagedetails(pdf_file, page_index, logo_output_path)
                    # create dictionary
                    res = {valid_images[i]: image_output[i] for i in list(valid_images.keys())}
                    # create dataframe for output
                    page_num += [page_index]*len(valid_images)
                    image_nums += range(1, len(valid_images)+1)
                    coordinates += [valid_images[i] for i in list(valid_images.keys())]

            # store the dictionary in our repo
            repo.append(res)
            
        # function: To get all the page number based on image coordinates
        def get_allpages(coor):
            df = df1[df1['Coor'] == coor]
            pages = []
            for i in range(len(df)):
                pages.append(df['Page_Num'].iloc[i])
            return pages

        # df1 contains information regarding page number and image number and image coordinates for all pages
        df1 = pd.DataFrame(list(zip(page_num, image_nums, coordinates)), columns=[
                           'Page_Num', 'Image_Num', 'Coor'])
        
        # print("Unsupervised Logo Repo")
        # display(df1)

        # df2 contains information regarding same coordinates that appear on multiple pages
        df2 = df1.Coor.value_counts().reset_index(name="count").query("count > 1")
        df2['Pages'] = df2['Coor'].apply(get_allpages)
        
        # loop through every row in df2 (every coordinate that appears more than once in the document)
        for i in range(len(df2)):
            # get the coordinate that appears more than once
            coor1 = df2['Coor'].iloc[i]
            # get the corresponding page numbers
            page_numbers = df2['Pages'].iloc[i]
            # get the image from one of these pages, for calculating image size
            image_details1 = repo[page_numbers[0]][coor1]

            if 'jb2' not in image_details1[1] and 'jpx' not in image_details1[1]:
                image1 = image_details1

            # loop through all the images where the coordinate is not there
            for page in range(len(pdf_file)):
                if page not in page_numbers:
                    # retrieve information for all the images on this page
                    temp = df1[df1['Page_Num'] == page]
                    # for every image
                    for i in range(len(temp)):
                        # check its coordinates
                        coor2 = temp['Coor'].iloc[i]
                        # also open the image, for calculating image size
                        image_details2 = repo[page][coor2]
                         
                        if 'jb2' not in image_details2[1] and 'jpx' not in image_details2[1]:
                            image2 = image_details2

                        # Checking for Logo size and Location consistency based on height and similarity of images
                        if cls.get_height_overlap(coor1, coor2) <= 1 and cls.get_imagesize(image1[0], image2[0]) < 0.4 and  cls.get_similarity(image1[0], image2[0]) >= 0.7 and (coor2 not in expected_coor) and ((page,coor2) not in highlighting_coords):
                            
                            #Saving the flagged image, and genuine image, that is used for comparison
                            write_to_data_lake(image1[0], logo_output_path + f"legit_" + image1[1])
                            write_to_data_lake(image2[0], logo_output_path + f"flagged_" + image2[1])

                            # append all the values needed for output
                            original_coor.append(coor1)
                            suspicious_page.append(page+1)
                            suspicious_coor.append(coor2)
                            insights.append('Logo Location and Size inconsistency')
                            flag.append(1)
                            severity.append('HIGH')
                            highlighting_coords.append((page, coor2))
                            break
                        
                        # Check for different logo present at same location
                        if cls.get_overlap(coor1, coor2) >= 0.7 and cls.get_similarity(image1[0], image2[0]) <= 0.6 and ((page,coor2) not in highlighting_coords):
                            
                            #Saving the flagged image, and genuine image, that is used for comparison
                            write_to_data_lake(image1[0], logo_output_path + f"legit_" + image1[1])
                            write_to_data_lake(image2[0], logo_output_path + f"flagged_" + image2[1])

                            # append all the values needed for output
                            original_coor.append(coor1)
                            suspicious_page.append(page+1)
                            suspicious_coor.append(coor2)
                            insights.append('Different Logo at same location')
                            flag.append(1)
                            severity.append('HIGH')
                            highlighting_coords.append((page, coor2))
                            break
                            
        #df3 contains raw info about logo consistency
        Feature_rule = ["Logo Inconsistency"]*len(suspicious_coor)
        df3 = pd.DataFrame(list(zip(suspicious_page,Feature_rule, suspicious_coor, original_coor)), columns=[
                           'Page_Num', 'Feature', 'Real_Value', 'Expected_Value'])

        rule = ["Logo Inconsistency across pages"]*len(suspicious_coor)
        # df4 contains the final report for logo module
        df4 = pd.DataFrame(list(zip(rule, flag, insights, severity)), columns=[
                           'Rule','Flag', 'Insight', 'Severity_Level'])
        
        return df3, df4, highlighting_coords

    @staticmethod
    def highlight_pdf(input_filename, highlighting_coords, logo_output_pdf):
        pdf_file = read_from_data_lake(input_filename)

        for t in highlighting_coords:
            Page = pdf_file[t[0]]
            Page.draw_rect(t[1],  color=(0, 1, 0), width=2)

        pdf_bytes = pdf_file.write()
        write_to_data_lake(pdf_bytes, logo_output_pdf)
        
    # Getting area based on the image coordinates
    @staticmethod
    def get_area(bbox):
        bbox = [round(i,2) for i in bbox]
        width, height = abs(bbox[2] - bbox[0]), abs(bbox[3] - bbox[1])
        area = width*height
        return area
        
    @classmethod
    def check_threshold_range_area(cls,coor_real,threshold,coor_exp):
        
        real_area = (coor_real[2] - coor_real[0]) * (coor_real[3] - coor_real[1])
        expected_area = (coor_exp[2] - coor_exp[0]) * (coor_exp[3] - coor_exp[1])       
        
        try:
            if cls.get_height_overlap(coor_real, coor_exp) <= 1:
                return expected_area - threshold*expected_area <= real_area <= expected_area + threshold*expected_area
            else:
                return 0
        except:
            cls.logo_error_list.append("Logo: Input values are non numeric")
            print('logo_error_list-------',cls.logo_error_list)
            return cls.logo_error_list
        
    @classmethod
    def is_within_threshold(cls,value,threshold,exp_value):
        try:
            return exp_value - threshold <= value <= exp_value + threshold
        except:
            cls.logo_error_list.append("Logo: Input values are non numeric")
            print('logo_error_list-------',cls.logo_error_list)
            return cls.logo_error_list
        
    # logo module with repository
    @classmethod
    def with_repo(cls, file_path, bank_name, logo_output_path, expected_value):
        
        highlighting_coords = []
        logo_output = []
        flag = []
        rule = []
        insights = []
        severity = []
        
        pdf_file = fitz.open(stream=file_path, filetype='pdf')
        
        # iterate through all the pages in pdf file
        for page_index in range(len(pdf_file)):
            page = pdf_file[page_index]
            page_width = page.rect.width
            page_height = page.rect.height

            #Getting the coordinates of all images present in that page.
            image_origins = cls.get_image_origins(file_path, page_index)
            image_num = len(image_origins)
            
            # Creating a dict to store valid images coor and image_path
            res = {}
            # if there is image detected in page
            if image_num > 0:
                valid_images = {}
                for image_num, origin in enumerate(image_origins):

                    # Images that satisfy the conditions are only valid for logo comparison
                    if cls.valid_image_check(origin, page_width, page_height):
                        valid_images[image_num] = tuple([round(float(i),2) for i in origin])
                
                if valid_images:
                    image_output = cls.get_imagedetails(pdf_file, page_index, logo_output_path)
                    # create dictionary
                    res = {valid_images[i]: image_output[i] for i in list(valid_images.keys())}
            
            # check if any image coordiante matches the repo
            expected_coor = expected_value[1]

            # if expected coordinate is in the repo and there is image detected from first page
            if expected_coor != '' and res != '':  
                # get the list of expected image corresponds to the bank name
                try:
                    if constants.IS_S3_PATH:
                        files = list_dir_files(constants.LOGO_REPO_PATH)
                        list_1 = [re.search(r'\d+',file.replace(constants.LOGO_REPO_PATH,'')).group() for file in files if file.lower().endswith((".jpg", ".png", ".jpeg")) and bank_name.lower() in file.lower()]

                    else:
                        files = os.listdir(constants.LOGO_REPO_PATH)
                        list_1 = [re.search(r'\d+', file).group() for file in files if file.lower().endswith((".jpg", ".png", ".jpeg")) and bank_name.lower() in file.lower()]
                except:
                    pass

                expected_image = []
                for j in range(int(max(list_1))+1):
                    try:
                        image_path_png = f"{constants.LOGO_REPO_PATH}{bank_name}_{j}.png"
                    except:
                        cls.logo_error_list.append("Logo: Bank Name image file not present")
                        print('logo_error_list-------',cls.logo_error_list)
                        return ''

                    try:
                        image_path_jpeg = f"{constants.LOGO_REPO_PATH}{bank_name}_{j}.jpeg"    
                    except:
                        cls.logo_error_list.append("Logo: Bank Name image file not present")
                        print('logo_error_list-------',cls.logo_error_list)
                        return ''
                    
                    try:
                        expected_image.append(read_from_data_lake(image_path_png))
                    except:
                        expected_image.append(read_from_data_lake(image_path_jpeg))    

                match = 0
                
                for key in res.keys():
                    area = round(cls.get_area(list(key)),4)
                    
                    # if matching coordinates found
                    for i in range(len(expected_coor)) :
                        key_coord_list = list(key)    
                        expected_coord_list = [float(n) for n in expected_coor[i]]
                        
                        if list(expected_coor[i]) == list(key):
                            match = 1
                            flag_list = []   
                            if 'jb2' not in res[key][1] and 'jpx' not in res[key][1]:
                                real_image = res[key]
                                # compare the images
                                for j in range(len(expected_image)):
                                    flag_list.append(cls.get_similarity(expected_image[j], real_image[0]))  
                                if all(f < 0.95 for f in flag_list):
                                    logo_output.append([page_index+1, "Logo Image similarity", min(flag_list)*100, "Greater than 95% similairty"])
                                    rule.append("Logo_image_match")
                                    flag.append(1)
                                    insights.append("Different Logo present at expected logo location.")
                                    severity.append("HIGH")
                                    highlighting_coords.append((page_index, list(key)))
                                    break

                        elif cls.get_height_overlap(key_coord_list, expected_coord_list) <= 1 and (list(key) not in expected_coor) and (cls.check_threshold_range_area(key_coord_list, 0.2, expected_coord_list)):
                            match = 1
                            flag_list =[]  
                            image_size_flag_list = []
                            if 'jb2' not in res[key][1] and 'jpx' not in res[key][1]:
                                real_image = res[key]
                                # compare the images
                                for j in range(len(expected_image)):
                                    flag_list.append(cls.get_similarity(expected_image[j], real_image[0]))
                                    
                                if any(f >= 0.7 for f in flag_list):
                                    logo_output.append([page_index+1, "Logo coordinate", list(key), expected_coor[i]])
                                    rule.append("Logo_coor_match")
                                    flag.append(1)
                                    insights.append("Logo coordinates are not matching. [With repo]")
                                    severity.append("HIGH")
                                    highlighting_coords.append((page_index, list(key)))
                                    break
                                    
                        elif (cls.check_threshold_range_area(key_coord_list, 0.4, expected_coord_list)) and (float(area) not in [float(a) for a in expected_value[0]]):
                            match = 1
                            flag_list = []
                            real_image = res[key]
                            # compare the images
                            for j in range(len(expected_image)):
                                #expected_image[j].show()
                                flag_list.append(cls.get_similarity(expected_image[j], real_image[0]))
                            
                            if any(f >= 0.7 for f in flag_list):
                                logo_output.append([page_index+1, "Logo Image area", area, expected_value[0]])
                                rule.append("Logo_area_match")
                                flag.append(1)
                                insights.append("Logo Image area not matching. [With repo]")
                                severity.append("MEDIUM")
                                highlighting_coords.append((page_index, list(key)))
                                break

                # if no matching coordinates found
                if match == 0:
                    # compare all the images with expected image
                    for key in res.keys():
                        if 'jb2' not in res[key][1] and 'jpx' not in res[key][1]:
                            real_image = res[key]
                            real_image_size = Image.open(io.BytesIO(real_image[0])).size
                            if real_image is not None and real_image_size in [expected_image[x].size for x in range(len(expected_image))]:
                                flag_list =[]
                                for j in range(len(expected_image)):
                                    flag_list.append(cls.get_similarity(expected_image[j], real_image[0]))

                                if any(f > 0.9 for f in flag_list):
                                    logo_output.append([page_index+1, "Logo coordinate", list(key), expected_value[1]])
                                    rule.append("Logo_coor_match")
                                    flag.append(1)
                                    insights.append(f"Detected logo coordinate at different location")
                                    severity.append("HIGH")
                                    highlighting_coords.append((page_index, list(key)))
        
        df1 = pd.DataFrame(logo_output, columns=[
                           'Page_Num', 'Feature', 'Real_Value', 'Expected_Value'])

         # df2 contains the final report for logo module
        df2 = pd.DataFrame(list(zip(rule, flag, insights, severity)), columns=[
                           'Rule','Flag', 'Insight', 'Severity_Level'])

        return df1, df2, highlighting_coords

    @classmethod
    def main_logo(cls, file_path, bank_name, logo_output_path, logo_repo, final_report_insight, excel_df):

        """If the file not present in Repo. Then run without_repo code"""
        logo_repo_value_expected = cls.get_expected_value(bank_name, logo_repo)
        if logo_repo_value_expected == "":
            df1, df2, highlight_coords = cls.without_repo(
                file_path, logo_output_path, logo_repo_value_expected)
        else:
            """If the bank name & file present in Repo. Then run with_repo code"""
            df1, df2, highlight_coords = cls.with_repo(
                file_path, bank_name, logo_output_path, logo_repo_value_expected)
            
            if len(df1) == 0:
                """If with_repo could not find any fraud, run without_repo code"""
                df1_2, df2_2, highlight_coords_2 = cls.without_repo(
                    file_path, logo_output_path, logo_repo_value_expected)

                # Concate the results from both approaches
                df1 = pd.concat([df1, df1_2], ignore_index=True)
                df2 = pd.concat([df2, df2_2], ignore_index=True)
                highlight_coords = highlight_coords + highlight_coords_2

        if len(highlight_coords)>0:
            display(df1)
            display(df2)
        else:
            print("No logo alerts detected in this PDF.")
            print()
        
        excel_df.loc[len(excel_df.index)] = [df1, '2A.Logo_Raw_Output']
        excel_df.loc[len(excel_df.index)] = [df2, '2B.Logo_Report']
        
        df3 = df2[['Insight', 'Severity_Level']]
        df3['Module'] = 'Logo'
        df3.columns = ['Alerts', 'Severity', 'Module']
        df3 = df3[['Module', 'Alerts', 'Severity']]
        final_report_insight = pd.concat([final_report_insight, df3])
        return final_report_insight, excel_df, highlight_coords

    @classmethod
    def logo_module_entry(cls, input_next_module, bank_names, pdf_filename_file, logo_output_path):
        final_report_insight = pd.DataFrame(columns=['Alerts', 'Severity'])
        excel_df = pd.DataFrame(columns=['tabs_df', 'tab_name'])
        bank_name = bank_names
        
        doc = read_from_data_lake(input_next_module)

        for page in doc:
            page.set_rotation(0)
            page.wrap_contents()
        pdf_final = doc.write()
        
        try:
            logo_repo = read_from_data_lake(constants.LOGO_REPOSITORY_PATH, sheet_name='repo')
            logo_repo.set_index('Bank', inplace=True)
            logo_repo = logo_repo.fillna('')
            
        except:
            cls.logo_error_list.append("Logo: Logo Repository excel is not present at path")
            print('logo_error_list-------',cls.logo_error_list)
            logo_repo = pd.DataFrame(columns=['Bank', 'Logo_coordinate', 'Image_arae'])
            logo_repo.set_index('Bank',inplace = True)

        final_report_insight, excel_df, highlight_coords = cls.main_logo(
            pdf_final, bank_name, logo_output_path, logo_repo, final_report_insight, excel_df)

        return final_report_insight, excel_df, highlight_coords, cls.logo_error_list

if __name__ == "__main__":
    import os
    from dfs.commons import constants
    input_next_module = 'core_v2/Wells Fargo Tampered Input.pdf'
    logo_output_path = 'output/Images/Logo/'
    path_intermediate = 'output/Intermediate/'
    
    os.makedirs(os.path.dirname(logo_output_path), exist_ok=True)
    os.makedirs(os.path.dirname(path_intermediate), exist_ok=True)

    logo_output_pdf = os.path.join(path_intermediate, "logo_output.pdf")

    bank_names = ['wells fargo']
    pdf_filename_file = "wells fargo input.pdf"

    final_report_insight, excel_df, highlight_coords = LogoModule.logo_module_entry(
        input_next_module, bank_names, pdf_filename_file, logo_output_path)
    LogoModule.highlight_pdf(
        input_next_module, highlight_coords, logo_output_pdf)
    print(excel_df)
