import os
from pkg_resources import resource_filename, Requirement, VersionConflict, DistributionNotFound
from dfs.commons import constants

def get_file_path(file_path):
    try:
        pkg_file_path = resource_filename(
            Requirement.parse("dfs==1.0.0"),
            file_path
        )
        return pkg_file_path
    except (VersionConflict, DistributionNotFound):
        return file_path


METADATA_REPOSITORY_PATH = get_file_path(
    'dfs/commons/config_files/Metadata repository with file tag_1.xlsx')
FONT_REPOSITORY_PATH = get_file_path(
    'dfs/commons/config_files/Font repository with file tag_2.xlsx')
# LOGO_REPOSITORY_PATH = get_file_path(
#     'dfs/commons/config_files/Logo repository with file tag v2.xlsx')
LOGO_REPOSITORY_PATH = get_file_path(
    '/home/cai/anlsts_exl_isc_minerva_poc_64_b31bb0a5_Sol_26/Saurabh/Amex_POC/test_logo_pdfs/Final_logo_repo.xlsx')


OVERLAY_REPOSITORY_PATH = get_file_path(
    'dfs/commons/config_files/Overlay_suppressions_v3.xlsx')
# LOGO_REPO_PATH = get_file_path(
#     'dfs/commons/config_files/logo_repo_v2/')

LOGO_REPO_PATH = get_file_path(
    '/home/cai/anlsts_exl_isc_minerva_poc_64_b31bb0a5_Sol_26/Saurabh/Amex_POC/test_logo_pdfs/logo_output/')

SUPPRESION_EXCEL_PATH = get_file_path(
    'dfs/commons/config_files/supression_excel_new.xlsx')

METADATA_REPOSITORY_PATH_GEN = get_file_path(
    'dfs/commons/config_files/Metadata Repository.xlsx')
FONT_REPOSITORY_PATH_GEN = get_file_path(
    'dfs/commons/config_files/Font_Repository.xlsx')
LOGO_REPOSITORY_PATH_GEN = get_file_path(
    'dfs/commons/config_files/Logo Repository.xlsx')
LOGO_REPO_PATH_GEN = get_file_path(
    'dfs/commons/config_files/logo_repo')
BANK_REPOSITORY_PATH_GEN = get_file_path(
    'dfs/commons/config_files/Bank Name Repository.xlsx')
OVERLAY_REPOSITORY_PATH_GEN = get_file_path(
    'dfs/commons/config_files/Overlay_suppressions_v3.xlsx')

# METADATA_REPOSITORY_PATH = os.path.join("document_fraud_dev" ,"test",'repo','Metadata repository with file tag_1.xlsx')
# FONT_REPOSITORY_PATH = os.path.join("document_fraud_dev" ,"test",'repo', 'Font repository with file tag_2.xlsx')
# LOGO_REPOSITORY_PATH = os.path.join("document_fraud_dev" ,"test",'repo' ,'Logo repository with file tag.xlsx')
# OVERLAY_REPOSITORY_PATH = os.path.join("document_fraud_dev" ,"test",'repo' ,'Overlay_suppressions_v3.xlsx')
# SUPPRESION_EXCEL_PATH = os.path.join("document_fraud_dev" ,"test",'repo', 'supression_excel_new.xlsx')
# LOGO_REPO_PATH = os.path.join("document_fraud_dev" ,"test",'repo' ,'logo_repo')


path = 'absa_data/poc_data/test_data/Lana203160/'

# METADATA_REPOSITORY_PATH = os.path.join(path + 'Metadata repository with file tag_1.xlsx')
# FONT_REPOSITORY_PATH = os.path.join(path + 'Font repository with file tag_2.xlsx')
# LOGO_REPOSITORY_PATH = os.path.join(path + 'Logo repository with file tag v2.xlsx')
# OVERLAY_REPOSITORY_PATH = os.path.join(path + 'Overlay_suppressions_v3.xlsx')
# SUPPRESION_EXCEL_PATH = os.path.join(path + 'supression_excel_new.xlsx')
# LOGO_REPO_PATH = os.path.join(path + 'logo_repo/')