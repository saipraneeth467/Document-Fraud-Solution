import os
from datastore.s3.utils import s3_client_instance
from dfs.commons import constants


def download_file_from_s3(input_file_path, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    s3_client = s3_client_instance()
    s3_client.download_file_from_bucket(
        s3_bucket=constants.S3_BUCKET,
        object_key_name=input_file_path,
        target_file_path=output_path
    )


def upload_file_to_s3(file_path, output_object_path):
    s3_client = s3_client_instance()
    s3_client.upload_file_to_bucket(
        s3_bucket=constants.S3_BUCKET,
        input_file=file_path,
        output_object_name=output_object_path
    )


def upload_dir_to_s3(output_dir, output_s3_dir):
    s3_client = s3_client_instance()
    for root, _, files in os.walk(output_dir):
        for f in files:
            cur_file = os.path.join(root, f)
            rel_path = os.path.relpath(cur_file, start=output_dir)
            s3_client.upload_file_to_bucket(
                s3_bucket=constants.S3_BUCKET,
                input_file=cur_file,
                output_object_name=os.path.join(output_s3_dir, rel_path)
            )
