import os
import json
import fitz
from io import BytesIO
from PIL import Image
import pandas as pd
from dfs.commons import constants
import PyPDF2
import time

try:
    from datastore.s3.client import S3Client
except (ImportError, ModuleNotFoundError) as e:
    S3Client = None

# ner_load_time = time.time()
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
# Load the BERT-based NER model
bert_model_name = "dbmdz/bert-large-cased-finetuned-conll03-english"
bert_tokenizer = AutoTokenizer.from_pretrained(bert_model_name)
bert_model = AutoModelForTokenClassification.from_pretrained(bert_model_name)
bert_ner = pipeline("ner", model=bert_model, tokenizer=bert_tokenizer)
# Ner_model_load_time = time.time()-ner_load_time
# print('Ner_model_load_time',Ner_model_load_time)

def read_data(input_file_path, **kwargs):
    """Method to read pandas data file"""
    ext = os.path.splitext(input_file_path)[-1]
    assert ext.lower() in [".pdf", ".xlsx", ".json", ".png", ".jpg", ".jpeg",".bmp",".tiff", ".HEIC", ".gif"]

    if ext.lower() == ".pdf":
        if "reader" in kwargs and kwargs["reader"] == "pypdf":
            return PyPDF2.PdfReader(input_file_path)
        return fitz.open(input_file_path)

    elif ext.lower() == ".xlsx":
        if "sheet_name" in kwargs:
            return pd.read_excel(input_file_path, sheet_name=kwargs["sheet_name"])
        if "formating" in kwargs:
            return pd.ExcelFile(input_file_path)

        return pd.read_excel(input_file_path)

    elif ext.lower() == ".json":
        try:
            with open(input_file_path, "r") as file:
                return json.load(file)
        except Exception:
            raise Exception("Invalid JSON file")
            
    elif ext.lower() == '.png' or ext.lower() == '.jpg' or ext.lower() == '.jpeg' or ext.lower() == '.bmp' or ext.lower() == '.tiff' or ext.lower() == '.gif':
        with open(input_file_path, 'rb') as f:
            file_stream_image_path1 = f.read()
        if 'reader' in kwargs and kwargs['reader'] == 'cv2':
            return file_stream_image_path1
        return Image.open(BytesIO(file_stream_image_path1))


def read_from_data_lake(input_file_path, **kwargs):
    """Method to read dataframes files from data lake"""
    # print(input_file_path)
    ext = os.path.splitext(input_file_path)[-1]
    
    assert ext.lower() in [".pdf", ".xlsx", ".json", ".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".gif"]
    if not constants.IS_S3_PATH or kwargs.get("local"):
        return read_data(input_file_path, **kwargs)
    assert constants.S3_BUCKET is not None, "bucket_name not provided."
    assert S3Client is not None, "datastore module not found"
    client = S3Client()

    if ext.lower() == ".pdf":
        if "reader" in kwargs and kwargs["reader"] == "pypdf":
            return PyPDF2.PdfReader(
                client.read_file_as_bytes(constants.S3_BUCKET, input_file_path)
            )
        return fitz.open(
            stream=client.read_file_as_bytes(constants.S3_BUCKET, input_file_path),
            filetype="pdf",
        )

    elif ext.lower() == ".xlsx":
        if "sheet_name" in kwargs:
            return pd.read_excel(
                client.read_file_as_bytes(constants.S3_BUCKET, input_file_path),
                **kwargs,
            )
        if "formating" in kwargs:
            return pd.ExcelFile(
                client.read_file_as_bytes(constants.S3_BUCKET, input_file_path)
            )

        return pd.read_excel(
            client.read_file_as_bytes(constants.S3_BUCKET, input_file_path), **kwargs
        )

    elif ext.lower() == ".json":
        try:
            return json.load(
                client.read_file_as_bytes(constants.S3_BUCKET, input_file_path)
            )
        except Exception:
            raise Exception("Invalid JSON file")
            
    elif ext.lower() == '.png' or ext.lower() == '.jpg' or ext.lower() == '.jpeg' or ext.lower() == '.bmp' or ext.lower() == '.tiff' or ext.lower() == '.gif':
        if 'reader' in kwargs and kwargs['reader'] == 'cv2':
            return client.read_file_as_bytes(constants.S3_BUCKET, input_file_path)
        return Image.open(client.read_file_as_bytes(constants.S3_BUCKET, input_file_path))
    
    # elif ext == '.png' or ext == '.jpg' or ext == '.jpeg':
    #     if 
    #     if 'reader' in kwargs and kwargs['reader'] == 'cv2':
    #         return client.read_file_as_bytes(constants.S3_BUCKET, input_file_path)
    #     return Image.open(client.read_file_as_bytes(constants.S3_BUCKET, input_file_path))
    
    

def write_pandas_data(bytes_data, output_file_path):
    """Method to write pandas data to output file"""
    os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
    with open(output_file_path, 'wb') as f:
        f.write(bytes_data)
    

def write_to_data_lake(bytes_data, output_file_path):
    """Method to write dataframes to datalake/local file system"""
    if not constants.IS_S3_PATH:
        return write_pandas_data(bytes_data, output_file_path)
    
    assert constants.S3_BUCKET is not None, "bucket_name not provided."
    assert S3Client is not None, "datastore module not found"
    client = S3Client()
    client.upload_file_as_bytes(constants.S3_BUCKET, bytes_data, output_file_path)

def list_dir_files(file_path):
    assert constants.S3_BUCKET is not None, "bucket_name not provided."
    assert S3Client is not None, "datastore module not found"
    client = S3Client()
    return client.list_bucket_contents(constants.S3_BUCKET, prefix=file_path)


