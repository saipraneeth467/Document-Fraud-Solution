#!/usr/bin/env python
# coding: utf-8
import gc
from dfs.commons.ioutils.multiprocessing import MyPool
import time

class Parallelize(object):
    @staticmethod
    def mapped_fn_call_debug(fn, inp_args):
        fn_name = str(fn.__name__)
        x = fn(*inp_args)
        # Debug to generate customer_fn_mapping.yaml => start
        var_list = list(set(x[0].columns.values) - {'Customer_ID'})
        default_value = x[1]
        mapping = {
            fn_name:
                {
                    "default": default_value,
                    "variables": var_list,
                }
        }
        return x[0]
        # Debug to generate customer_fn_mapping.yaml => end

    @staticmethod
    def mapped_fn_call(fn, inp_args):
        x = fn(*inp_args) # columns and dtypes
        return x

    # @timeit
    @classmethod
    def run_parallelize(cls, fn_mappings, num_cores=16, strategy='parallel'):  # change to parallel
        mp_array = []
        time_lst = []
        if strategy == "parallel":
            with MyPool(processes=min(len(fn_mappings), num_cores)) as task_pool:
                start_time = time.time()
                mp_array = task_pool.starmap(cls.mapped_fn_call, fn_mappings)
                end_time = time.time()
                time_tst.append(end_time - start_time)
            gc.collect()
        elif strategy == "sequential":
            for name, fn, inp_args in fn_mappings:
                print(f"Module: {name}")
                print("="*20)
                print()
                start_time = time.time()
                ret = cls.mapped_fn_call(fn, inp_args)
                mp_array.append(ret)
                time_taken = time.time() - start_time
                print(f"{name}_Module Time Taken: {time_taken}")
                time_lst.append(time_taken)
                print("="*50)
                print()
        return mp_array, time_lst