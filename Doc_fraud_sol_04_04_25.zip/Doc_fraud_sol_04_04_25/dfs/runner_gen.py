from sys import argv
import os
import argparse
from dfs.core.pdf_gen import main as runner_main

parser = argparse.ArgumentParser(description='Optional app description')

parser.add_argument('--mode', choices=["parallel", "sequential"],
                    default="sequential",
                    help="Specify the mode (parallel or sequential). Default is sequential.")

parser.add_argument(
    "--input_file",
    help="Input file path",
)

parser.add_argument(
    "--output_path",
    help="Output file path",
)

args = parser.parse_args()


def is_valid_pdf_path(file_path):
    if os.path.isfile(file_path):
        return True
    else:
        raise Exception("Not a valid file path")


def main():
    args = parser.parse_args()
    input_norm_path = os.path.normpath(args.input_file)
    output_norm_path = os.path.normpath(args.output_path)
    # try:
    is_valid_pdf_path(input_norm_path)
    runner_main(input_norm_path, output_norm_path, args.mode)
    # except:
        # print("Not a valid file")

if __name__ == '__main__':
    main()
