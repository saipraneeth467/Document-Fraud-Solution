import os
import boto3
import logging
from io import BytesIO
from botocore.client import Config

logger = logging.getLogger(__name__)


class BaseDataStore:
    """Class to connect with object storage"""

    def __init__(self, **kwargs):
        self.client = None
        self.access_key = None
        self.secret_key = None
        self.session_token = None
        self.host = None
        self.is_secure = None
        self.region = 'us-east-1'

    def get_s3_client(self):
        """Method to return s3 client"""
        config = Config(signature_version='s3v4', region_name=self.region)
        self.is_secure = True
        session = boto3.session.Session()
        client = session.client('s3', aws_access_key_id=self.access_key, aws_secret_access_key=self.secret_key,
                              endpoint_url=self.host, use_ssl=self.is_secure, region_name=self.region,
                              config=config, aws_session_token=self.session_token
                              )
        return client

    def create_s3_bucket(self, bucket_name):
        """Method to create s3 bucket"""
        bucket = self.client.create_bucket(Bucket=bucket_name)
        return bucket

    def list_buckets(self):
        """Method to fetch buckets"""
        data = self.client.list_buckets()
        buckets = []
        for bucket in data.get('Buckets', []):
            buckets.append(bucket['Name'])
        return buckets

    def list_bucket_contents(self, s3_bucket, prefix=''):
        """Method to fetch bucket contents"""
        data = self.client.list_objects(Bucket=s3_bucket, Prefix=prefix)
        keys = []
        for key in data.get('Contents', []):
            keys.append(key['Key'])
        return keys

    def upload_file_to_bucket(self, s3_bucket, input_file, output_object_name, kms_key_id=None):
        """Method to upload file to s3 bucket"""
        logger.info(f"DATA UPLOAD DEBUG: {s3_bucket}, {input_file}, {output_object_name}")
        if kms_key_id is not None:
            self.client.upload_file(Filename=input_file, Bucket=s3_bucket, Key=output_object_name,
                                    ExtraArgs={'ServerSideEncryption': 'aws:kms', 'SSEKMSKeyId': kms_key_id})
        else:
            self.client.upload_file(Filename=input_file, Bucket=s3_bucket, Key=output_object_name)

    def download_file_from_bucket(self, s3_bucket, object_key_name, target_file_path):
        """Method to download file from bucket"""
        logger.info(f"DATA DOWNLOAD DEBUG: {s3_bucket}, {object_key_name}, {target_file_path}")
        os.makedirs(os.path.dirname(target_file_path), exist_ok=True)
        self.client.download_file(Filename=target_file_path, Bucket=s3_bucket, Key=object_key_name)

    def delete_dir_from_bucket(self, s3_bucket, prefix):
        """Method to delete directory from bucket."""
        logger.info(f"DATA DELETE DEBUG: {s3_bucket}, {prefix}")
        keys = self.list_bucket_contents(s3_bucket, prefix)
        for key in keys:
            self.client.delete_object(Bucket=s3_bucket, Key=key)

    def copy_file_object(self, input_s3_bucket, input_object_key, output_s3_bucket, output_object_key):
        """Method to copy file object"""
        logger.info(f"FILE OBJECT COPY DEBUG: {input_s3_bucket} ,{input_object_key}, {output_s3_bucket}, "
                    f"{output_object_key}")
        copy_source = {
            'Bucket': input_s3_bucket,
            'Key': input_object_key
        }
        self.client.copy(copy_source, output_s3_bucket, output_object_key)

    def read_file_as_bytes(self, s3_bucket, object_key_name):
        """Method to download file from bucket"""
        logger.info(f"DATA READ FILE DEBUG: {s3_bucket}, {object_key_name}")
        bytes_data = self.client.get_object(Key=object_key_name, Bucket=s3_bucket)['Body'].read()
        return BytesIO(bytes_data)

    def upload_file_as_bytes(self, s3_bucket, input_data, object_key_name):
        """Method to upload file as bytes"""
        logger.info(f"DATA UPLOAD DEBUG: {s3_bucket}, {object_key_name}")
        with BytesIO(input_data) as f:
            self.client.upload_fileobj(f, s3_bucket, object_key_name)
        # self.client.upload_fileobj(input_data, s3_bucket, object_key_name)
