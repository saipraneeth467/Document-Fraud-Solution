"""Utils file for S3 related operations"""
from datastore.s3.client import S3Client
from dfs.commons import constants


def s3_client_instance():
    s3_client = S3Client(
        aws_access_key_id=constants.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=constants.AWS_SECRET_ACCESS_KEY,
        region=constants.REGION
    )
    return s3_client
