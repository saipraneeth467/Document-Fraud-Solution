import logging

from datastore.base_classes.base_data_store import BaseDataStore
from dfs.commons import constants


logger = logging.getLogger(__name__)


class S3Client(BaseDataStore):
    """Class to connect with S3 object storage"""

    def __init__(self, aws_access_key_id=constants.AWS_ACCESS_KEY_ID, aws_secret_access_key=constants.AWS_SECRET_ACCESS_KEY, region=constants.REGION):
        """Constructor to create s3 client instance using aws credentials or id token from idp or authentication to idp
        using password grant type"""
        super().__init__()
        self._aws_access_key_id = aws_access_key_id
        self._aws_secret_access_key = aws_secret_access_key
        self.region = region
        self.access_key, self.secret_key = self._aws_access_key_id, self._aws_secret_access_key

        self.client = self.get_s3_client()
